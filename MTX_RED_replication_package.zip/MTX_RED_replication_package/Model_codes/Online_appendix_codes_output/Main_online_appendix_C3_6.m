% ================================================== TRANSITION PATH App. C.3.6 MAIN FILE ==================================================== %
% Load SS workspace
benchmark_ss_output_filename = online_appendix_path + "Raw_output_online_appendix\Output_appendix_C2_C3.mat"; load(benchmark_ss_output_filename); 

% Toggles
save_output_toggle = 1;
save_initialization_toggle = 1 ; % Set to 1 if you want to redo initialization for PE exercises

% --- Number of periods of transition path: 
T_tp = 27; % 5 years per period  
transition_path_residual = 10^-3; % stopping condition for the transition path
max_tp_iter = 30;

% Start and end SS equilibria: 
Start_policy_vec_index = 1;
End_policy_vec_index_set = [2 3];
Benchmark_policy_vec_index_set = [2 3];

% ======================== BEGIN Solving Transition Path 
tstart_main_code = tic; 
flag_initialize_shortcut = 0;
for End_policy_aux = 1:size(End_policy_vec_index_set,2)
    disp(['Begin Exercise Loop: ' num2str(End_policy_vec_index_set(End_policy_aux))]); disp(datetime);

    % ======================== BEGIN INITIALIZATION ======================== %
    % Description of this step: 
    % Initialization varies depending on whether this is a GE or a PE transition path
    % GE transition paths initialize setting everything after period 1 to the final SS values.
    % Then, in GE exercises, the code finds a fixed point given lags and leads as constraints.
    % PE transition paths initialize setting everything the transition path to the relevant GE transition path values
    % Then, in PE exercises, one of the Agg endogenous states is set to baseline value and the TP is solved (choices given aggregates).
    
    %  ---> Define start/end index, benchmark index (for PE is different than End_policy_index)  
    
    % Set final steady-state policy vec index
    End_policy_vec_index       = End_policy_vec_index_set(End_policy_aux); % this is the final steady state for the counterfactual of interest. It can be the same SS as the initial SS.
    % Set initial steady-state policy vec index
    Benchmark_policy_vec_index = Benchmark_policy_vec_index_set(End_policy_aux);
    % Make a vector of policy_vec_index values where the first element is the initial SS and the rest are the end SS. 
    % Use this to select exogenous policy parameters
    Transition_vec_temp        = ones(1,T_tp)*End_policy_vec_index;
    Transition_vec_temp(1)     = Start_policy_vec_index;
    % ---> Itialization and output filenames
    initializing_tp_filename        = [online_appendix_path 'Raw_output_online_appendix\TP_GE_objects_initializing_' num2str(Start_policy_vec_index) '_' num2str(Benchmark_policy_vec_index) '.mat'];
    transition_path_output_filename = [online_appendix_path 'Raw_output_online_appendix\Output_appendix_TP_C3_6_' num2str(Start_policy_vec_index) '_' num2str(End_policy_vec_index)];

    % ---> Itialization method depends on whether it is a GE exercise and whether there exists a relevant initialization file. 
    if End_policy_vec_index~=Benchmark_policy_vec_index && any(size(dir(initializing_tp_filename),1))  % ---> PE exercises: if there is an initialization file for benchmark exercise initialize with it and overwrite PE object with Start_policy_vec_index value
        
        % Load counterfactual TP GE objects to initialize TP. This makes all TP variables equal to the GE solution of bnchmrk 
        load(initializing_tp_filename); 
        % Replace initialization of objects incorporating PE toggles by setting relevant object to start_policy_vec_index values 
        for tpathi = 1:T_tp
            index_relevant_ss = Transition_vec_temp(tpathi); 
            
            % Re-evaluate policy mats using baseline median income
            subsidy_chic            = Policy_pars_mat_inputs_t(1,tpathi);  
            rationing_rate          = Policy_pars_mat_inputs_t(2,tpathi);  
            yp_cutoff               = Policy_pars_mat_inputs_t(3,tpathi); 
            subsidy_b0              = Policy_pars_mat_inputs_t(4,tpathi); 
            subsidy_b1              = Policy_pars_mat_inputs_t(5,tpathi); 
            transfer_proportion1    = Policy_pars_mat_inputs_t(6,tpathi); 
            transfer_proportion2    = Policy_pars_mat_inputs_t(7,tpathi); 
            refund_threshold        = Policy_pars_mat_inputs_t(8,tpathi); 
            phaseout_threshold      = Policy_pars_mat_inputs_t(9,tpathi);

            % Aggregate endogenous states - if PE, resets to initial values over entire transition:
            if GE_toggle_mat(index_relevant_ss,1) == 0
                skill_dist_t(:,tpathi) = skill_dist_t(:,Start_policy_vec_index);                
            end
            if GE_toggle_mat(index_relevant_ss,2) == 0
                Vkid_t(:,tpathi)             = Vkid_t(:,Start_policy_vec_index);
            end
            if GE_toggle_mat(index_relevant_ss,3) == 0
                lambda_y_t(:,tpathi)         = GE_objects_t(5,Start_policy_vec_index);  
            end

            % Other GE objects: 
            if GE_toggle_mat(index_relevant_ss,4) == 0
                pn_t(tpathi)               = GE_objects_t(2,Start_policy_vec_index);
            end
            if GE_toggle_mat(index_relevant_ss,5) == 0
                % Scaling parameters
                yp50_t(tpathi)             = GE_objects_t(4,Start_policy_vec_index);  
                cutoffpctiley_t(tpathi)    = GE_objects_t(6,Start_policy_vec_index);  
                % Re-evaluate policy mats using baseline median income and y eligibility threshold for CCDF 
                [EITC_policy_mat_t(:,:,tpathi)] = EITC_policy(yp50_t(tpathi)/US_yp50,j_a,J);   
                [CTC_policy_mat_t(:,:,tpathi)]  = CTC_policy(yp50_t(tpathi)/US_yp50,j_a,J,transfer_proportion1,transfer_proportion2,refund_threshold,phaseout_threshold);
                [TANF_policy_mat_t(:,:,tpathi)] = TANF_policy(0,yp50_t(tpathi)/US_yp50,J);  
                [CCDF_policy_mat_t(:,:,tpathi)] = CCDF_policy(yp50_t(tpathi),cutoffpctiley_t(tpathi),2,subsidy_chic,rationing_rate,subsidy_b0,subsidy_b1);    
            end
            if GE_toggle_mat(index_relevant_ss,6) == 0
                pension_lvl_t(:,tpathi)    = pension_lvl_policy_mat(:,Start_policy_vec_index);
            end
            %GE_quantities_t(:,tpathi)  = GE_quantities_policy_mat(:,index_relevant_ss); % [n_hours q_hours h_hours rho_thetay]' --> does not get updated in TP code
            %GE_objects_t(:,tpathi)     = GE_objects_policy_mat(:,index_relevant_ss); % [GDP pn thetan yp50 lambda_y cutoffpctiley] --> does not get updated in TP code
            %GDP_t_vec(tpathi)          = GE_objects_t(1,tpathi); % --> gets updated in TP code

            % For objects that get updated as choices use the final SS value - thus continuation value is consistent with final SS in PE decompositions
            % Consumer problem solution objects
            V_opt_t(:,:,tpathi)            = V_opt_policy_mat(:,:,index_relevant_ss);
            V_opt_realized_t(:,:,tpathi)   = V_opt_realized_policy_mat(:,:,index_relevant_ss);
            ccdf_app_opt_t(:,:,tpathi)     = ccdf_app_opt_policy_mat(:,:,index_relevant_ss);
            thetaa_opt_t(:,:,tpathi)       = thetaa_policy_mat(:,:,index_relevant_ss); 
            theta_opt_t(:,:,tpathi)        = theta_opt_policy_mat(:,:,index_relevant_ss); 
            ccdf_fc_opt_t(:,:,tpathi)      = ccdf_fc_opt_policy_mat(:,:,index_relevant_ss);
            n_opt_t(:,:,tpathi)            = n_opt_policy_mat(:,:,index_relevant_ss);
            q_opt_t(:,:,tpathi)            = q_opt_policy_mat(:,:,index_relevant_ss);
            h_opt_t(:,:,tpathi)            = h_opt_policy_mat(:,:,index_relevant_ss);
            c_opt_t(:,:,tpathi)            = c_opt_policy_mat(:,:,index_relevant_ss);
            y_opt_t(:,:,tpathi)            = y_opt_policy_mat(:,:,index_relevant_ss);
            yd_opt_t(:,:,tpathi)           = yd_opt_policy_mat(:,:,index_relevant_ss);
            tax_credtransf_opt_t(:,:,tpathi) = tax_credits_transf_opt_policy_mat(:,:,index_relevant_ss);
            CCDF_received_opt_t(:,:,tpathi)  = gov_cc_expense_opt_policy_mat(:,:,index_relevant_ss);
            EITC_received_opt_t(:,:,tpathi)  = EITC_received_opt_policy_mat(:,:,index_relevant_ss);
            CTC_received_opt_t(:,:,tpathi)   = CTC_received_opt_policy_mat(:,:,index_relevant_ss);
            TANF_received_opt_t(:,:,tpathi)  = TANF_received_opt_policy_mat(:,:,index_relevant_ss);

        end % end tpathi

        % In the final period overwrite using the solution from the SS code. Needs to be consistent with the TP code. 
        % Aggregate endogenous states
        Omega_dist_t(:,:,T_tp)     = Omega_dist_policy_mat(:,:,index_relevant_ss);
        Vkid_t(:,T_tp)             = Vkid_policy_mat(:,index_relevant_ss);
        skill_dist_t(:,T_tp)       = skill_dist_policy_mat(:,index_relevant_ss); 
        lambda_y_t(:,T_tp)         = GE_objects_policy_mat(5,index_relevant_ss);  

        % Other GE objects: 
        pension_lvl_t(:,T_tp)    = pension_lvl_policy_mat(:,index_relevant_ss);
        pn_t(T_tp)               = GE_objects_policy_mat(2,index_relevant_ss);
        yp50_t(T_tp)             = GE_objects_policy_mat(4,index_relevant_ss);  
        cutoffpctiley_t(T_tp)    = GE_objects_policy_mat(6,index_relevant_ss);  
        GE_quantities_t(:,T_tp)  = GE_quantities_policy_mat(:,index_relevant_ss); % [n_hours q_hours h_hours rho_thetay]' 
        GE_objects_t(:,T_tp)     = GE_objects_policy_mat(:,index_relevant_ss); % [GDP pn thetan yp50 lambda_y cutoffpctiley]
        GDP_t_vec(T_tp)          = GE_objects_policy_mat(1,index_relevant_ss);

        % Policy arrays
        Policy_toggle_t(T_tp,:)     = Policy_toggle_mat(index_relevant_ss,:);
        EITC_policy_mat_t(:,:,T_tp) = EITC_opt_policy_mat(:,:,index_relevant_ss); 
        CTC_policy_mat_t(:,:,T_tp)  = CTC_opt_policy_mat(:,:,index_relevant_ss);
        TANF_policy_mat_t(:,:,T_tp) = TANF_opt_policy_mat(:,:,index_relevant_ss);  
        CCDF_policy_mat_t(:,:,T_tp) = CCDF_opt_policy_mat(:,:,index_relevant_ss);    
        Policy_pars_mat_inputs_t(:,T_tp)  = Policy_pars_mat_inputs(index_relevant_ss,:)';  
        Policy_pars_mat_outputs_t(:,T_tp) = Policy_pars_mat_outputs(index_relevant_ss,:)';           

        % Initialize Omega_dist_t; allows for changes in likelihood of receipt to affect it, uses PE adult skill distributions:
        for tpathi = 1:T_tp
            Omega_dist_aux = zeros(n_types,J);
            for type_index = 1:n_types 
                theta_index  = type_mat(type_index,1);
                thetak_index = type_mat(type_index,2); 
                cc_r_index   = type_mat(type_index,3); 
                cc_fc_index  = type_mat(type_index,4);  
                for age = 1:J  
                    if cc_r_index == 1 % incorporate application choices into distribution over ccdf application/receipt/no app distribution
                        probccstatus = (ccdf_app_opt_t(type_index,1,max(tpathi-age+1,1))== 1); % did not apply 
                    elseif cc_r_index == 2
                        probccstatus = rationing_rate*(ccdf_app_opt_t(type_index,1,max(tpathi-age+1,1)) == 2); % prob. did not receive || applied
                    else  
                        probccstatus = (1-rationing_rate)*(ccdf_app_opt_t(type_index,1,max(tpathi-age+1,1)) == 2); % prob. did receive || applied  
                    end
                    probkid    = thetak_dist(theta_index,thetak_index);
                    probparent = skill_dist_t(theta_index,max(tpathi- age + 1 - j_a ,1)); 
                    probage    = 1/J;
                    probfc     = chi_c_eps_dist(cc_fc_index);
                    Omega_dist_aux(type_index,age) = probfc*probccstatus*probkid*probparent*probage;
                end
            end 
            Omega_dist_t(:,:,tpathi) = Omega_dist_aux;   
        end
    elseif End_policy_vec_index~=Benchmark_policy_vec_index 

        disp('There is no initialization file'); disp(datetime); 
    
    else % --- Otherwise, load counterfactual SS workspace and initialize all TP objects:
        
        % Initialize all objects 
        for tpathi = 1:T_tp
            index_relevant_ss     = Transition_vec_temp(tpathi); 
       
            % Aggregate endogenous states:
            Omega_dist_t(:,:,tpathi)     = Omega_dist_policy_mat(:,:,index_relevant_ss);
            Vkid_t(:,tpathi)             = Vkid_policy_mat(:,index_relevant_ss);
            skill_dist_t(:,tpathi)       = skill_dist_policy_mat(:,index_relevant_ss); 
            lambda_y_t(:,tpathi)         = GE_objects_policy_mat(5,index_relevant_ss);  
    
            % Other GE objects: 
            pension_lvl_t(:,tpathi)    = pension_lvl_policy_mat(:,index_relevant_ss);
            pn_t(tpathi)               = GE_objects_policy_mat(2,index_relevant_ss);
            yp50_t(tpathi)             = GE_objects_policy_mat(4,index_relevant_ss);  
            cutoffpctiley_t(tpathi)    = GE_objects_policy_mat(6,index_relevant_ss);  
            GE_quantities_t(:,tpathi)  = GE_quantities_policy_mat(:,index_relevant_ss); % [n_hours q_hours h_hours rho_thetay]' 
            GE_objects_t(:,tpathi)     = GE_objects_policy_mat(:,index_relevant_ss); % [GDP pn thetan yp50 lambda_y cutoffpctiley]
            GDP_t_vec(tpathi)          = GE_objects_policy_mat(1,index_relevant_ss);
    
            % Policy arrays
            Policy_toggle_t(tpathi,:)     = Policy_toggle_mat(index_relevant_ss,:);
            EITC_policy_mat_t(:,:,tpathi) = EITC_opt_policy_mat(:,:,index_relevant_ss); 
            CTC_policy_mat_t(:,:,tpathi)  = CTC_opt_policy_mat(:,:,index_relevant_ss);
            TANF_policy_mat_t(:,:,tpathi) = TANF_opt_policy_mat(:,:,index_relevant_ss);  
            CCDF_policy_mat_t(:,:,tpathi) = CCDF_opt_policy_mat(:,:,index_relevant_ss);    
            Policy_pars_mat_inputs_t(:,tpathi)  = Policy_pars_mat_inputs(index_relevant_ss,:)';  
            Policy_pars_mat_outputs_t(:,tpathi) = Policy_pars_mat_outputs(index_relevant_ss,:)';   
    
            % Consumer problem solution objects
            V_opt_t(:,:,tpathi)            = V_opt_policy_mat(:,:,index_relevant_ss);
            V_opt_realized_t(:,1,tpathi)   = V1_realized_policy_mat(:,index_relevant_ss); 
            V_opt_realized_t(:,2:J,tpathi) = V_opt_policy_mat(:,2:end,index_relevant_ss);
            ccdf_app_opt_t(:,:,tpathi)     = ccdf_app_opt_policy_mat(:,:,index_relevant_ss);
            thetaa_opt_t(:,:,tpathi)       = thetaa_policy_mat(:,:,index_relevant_ss); 
            theta_opt_t(:,:,tpathi)        = theta_opt_policy_mat(:,:,index_relevant_ss); 
            ccdf_fc_opt_t(:,:,tpathi)      = ccdf_fc_opt_policy_mat(:,:,index_relevant_ss);
            n_opt_t(:,:,tpathi)            = n_opt_policy_mat(:,:,index_relevant_ss);
            q_opt_t(:,:,tpathi)            = q_opt_policy_mat(:,:,index_relevant_ss);
            h_opt_t(:,:,tpathi)            = h_opt_policy_mat(:,:,index_relevant_ss);
            c_opt_t(:,:,tpathi)            = c_opt_policy_mat(:,:,index_relevant_ss);
            y_opt_t(:,:,tpathi)            = y_opt_policy_mat(:,:,index_relevant_ss);
            yd_opt_t(:,:,tpathi)           = yd_opt_policy_mat(:,:,index_relevant_ss);
            tax_credtransf_opt_t(:,:,tpathi) = tax_credits_transf_opt_policy_mat(:,:,index_relevant_ss);
            CCDF_received_opt_t(:,:,tpathi)  = gov_cc_expense_opt_policy_mat(:,:,index_relevant_ss);
            EITC_received_opt_t(:,:,tpathi)  = EITC_received_opt_policy_mat(:,:,index_relevant_ss);
            CTC_received_opt_t(:,:,tpathi)   = CTC_received_opt_policy_mat(:,:,index_relevant_ss);
            TANF_received_opt_t(:,:,tpathi)  = TANF_received_opt_policy_mat(:,:,index_relevant_ss);
        end
    
    end 
   
    % --- Set fixed values from baseline: 
    thetan = GE_objects_t(3,Start_policy_vec_index);
    w = 1 ;
    
    % --- Fixed parameter values 
    par_fixed_vec       = [J, j_a, j_r, n_types, n_bins_ccsub_fc, n_ccsub_types, n_childcare, n_theta, n_thetak, n_h, upsilon, beta, Frisch, chi, nu, gamma, OECD_child, chi_u, share_pension_taxed, beta1_wagegrowth, beta2_wagegrowth, beta3_wagegrowth];
    par_calibration_vec = [b, lambda_I, psi, chi_c, initial_corr_par, varlogthetak, pension_rep_rate];
    % ======================== END INITIALIZATION ======================== %
    
    % ======================== BEGIN Transition path loop  ======================== %
    disp('Begin TP loop ' ); disp(datetime);
    TSTART_total_sol = tic;
    TP_iteration_count = 1;
    res_t = ones(1,T_tp-2);
    
    while max(abs(res_t))>transition_path_residual && TP_iteration_count<=max_tp_iter
        TSTART_TP_iteration_loop = tic;        
        % Initialize objects solved for in this iteration of TP solution:
        EITC_toggle = Policy_toggle_vec(1); 
        CTC_toggle  = Policy_toggle_vec(2); 
        TANF_toggle = Policy_toggle_vec(3); 
        CCDF_toggle = Policy_toggle_vec(4); 
        
        V_opt_t_aux  = NaN(n_types,J,T_tp);
        h_opt_t_aux  = NaN(n_types,J,T_tp);
        c_opt_t_aux  = NaN(n_types,J,T_tp);
        y_opt_t_aux  = NaN(n_types,J,T_tp);
        yd_opt_t_aux = NaN(n_types,J,T_tp);
        n_opt_t_aux  = NaN(n_types,J,T_tp);
        q_opt_t_aux  = NaN(n_types,J,T_tp);
        theta_opt_t_aux      = NaN(n_types,J,T_tp);
        ccdf_fc_opt_t_aux    = NaN(n_types,J,T_tp);
        tax_credtransf_t_aux = NaN(n_types,J,T_tp);
        thetaa_opt_t_aux     = NaN(n_types,J,T_tp);
        
        CCDF_received_opt_t_aux  = NaN(n_types,J,T_tp);  
        EITC_received_opt_t_aux  = NaN(n_types,J,T_tp);
        CTC_received_opt_t_aux   = NaN(n_types,J,T_tp);
        TANF_received_opt_t_aux  = NaN(n_types,J,T_tp);
    
        % ======================== BEGIN Equilibrium at t=tpathi, given guess of path of Agg. End. States.
        for tpathi = T_tp-1:-1:2 % T_tp and 1 are final and initial steady-states respectively.
            TSTART_tpathi_loop = tic;

            Policy_toggle_vec = Policy_toggle_t(tpathi,:);  

            % Policy attributes that depend on tpathi 
            pn_t_loop = pn_t(tpathi);
            lambda_y_t_loop = lambda_y_t(tpathi);
            pension_lvl_t_loop = pension_lvl_t(:,tpathi);

            par_GE_vec = [thetan, pn_t_loop, w, tau_c, tau_y, lambda_y_t_loop];
            subsidy_chic            = Policy_pars_mat_inputs_t(1,tpathi);  
            rationing_rate          = Policy_pars_mat_inputs_t(2,tpathi);  
            yp_cutoff               = Policy_pars_mat_inputs_t(3,tpathi); 
            subsidy_b0              = Policy_pars_mat_inputs_t(4,tpathi); 
            subsidy_b1              = Policy_pars_mat_inputs_t(5,tpathi); 
            transfer_proportion1    = Policy_pars_mat_inputs_t(6,tpathi); 
            transfer_proportion2    = Policy_pars_mat_inputs_t(7,tpathi); 
            refund_threshold        = Policy_pars_mat_inputs_t(8,tpathi); 
            phaseout_threshold      = Policy_pars_mat_inputs_t(9,tpathi); 
    
            % Depend on tpathi
            EITC_policy_mat = EITC_policy_mat_t(:,:,tpathi);  
            CTC_policy_mat  = CTC_policy_mat_t(:,:,tpathi);
            TANF_policy_mat = TANF_policy_mat_t(:,:,tpathi);  
            CCDF_policy_mat = CCDF_policy_mat_t(:,:,tpathi);
            Vkid_t_loop     = Vkid_t(:,tpathi);           

            % === BEGIN Consumer life cycle 
            parfor type_index = 1:n_types % should be a parfor
            
                theta_index  = type_mat(type_index,1); 
                thetak_index = type_mat(type_index,2);
                cc_a_r_index = type_mat(type_index,3);
                cc_fc_index  = type_mat(type_index,4); 
                
                thetak       = thetak_grid(thetak_index);  
                chi_c_epsval = chi_c_eps_grid(cc_fc_index);
                
                V_profile        = -10^(8)*ones(J,T_tp-2); 
                n_profile        = zeros(J,T_tp-2); 
                q_profile        = zeros(J,T_tp-2); 
                h_profile        = zeros(J,T_tp-2); 
                y_profile        = zeros(J,T_tp-2); 
                yd_profile       = zeros(J,T_tp-2); 
                c_profile        = zeros(J,T_tp-2); 
                thetaa_profile   = zeros(J,T_tp-2); 
                tax_paid_profile = zeros(J,T_tp-2); 
                EITC_profile     = zeros(J,T_tp-2); 
                CTC_profile      = zeros(J,T_tp-2); 
                TANF_profile     = zeros(J,T_tp-2);  
                Vbest_temp       = zeros(2,T_tp-2);       
                thetaindex_profile         = zeros(J,T_tp-2); 
                tax_credits_transf_profile = zeros(J,T_tp-2); 
                gov_cc_expense_profile     = zeros(J,T_tp-2); 
                ccdf_fc_profile            = zeros(J,T_tp-2);
          
                for age = J:-1:1
                    % Only depend on age
                    theta  = theta_profile_grid(theta_index,age); % NOTE!!! scales for wages and parenting productivity          
                    y_grid = w*theta*h_grid;
                    CE_scale = 1 + OECD_child*(age<=j_a);
            
                    if age == J       
                        h_profile(age,tpathi)                  = 0;
                        y_profile(age,tpathi)                  = 0;
                        yd_profile(age,tpathi)                 = (1-share_pension_taxed)*pension_lvl_t_loop(type_index) + lambda_y_t_loop*(share_pension_taxed*pension_lvl_t_loop(type_index))^(1-tau_y);
                        c_profile(age,tpathi)                  = yd_profile(age,tpathi)/(1+tau_c);  
                        thetaa_profile(age,tpathi)             = theta_profile_grid(theta_index,age);
                        tax_paid_profile(age,tpathi)           = pension_lvl_t_loop(type_index) - yd_profile(age,tpathi);
                        tax_credits_transf_profile(age,tpathi) = yd_profile(age,tpathi); 
                        EITC_profile(age,tpathi)               = 0;
                        CTC_profile(age,tpathi)                = 0;
                        TANF_profile(age,tpathi)               = 0;
                        ccdf_fc_profile(age,tpathi)            = 0;
                        V_profile(age,tpathi)                  = log(yd_profile(age,tpathi)/((1+tau_c)*CE_scale)) - psi*(0.^(1+(1/Frisch)))./(1+(1/Frisch)); 
                    elseif age >=j_r       
                        h_profile(age,tpathi)                  = 0;
                        y_profile(age,tpathi)                  = 0;
                        yd_profile(age,tpathi)                 = (1-share_pension_taxed)*pension_lvl_t_loop(type_index) + lambda_y_t_loop*(share_pension_taxed*pension_lvl_t_loop(type_index))^(1-tau_y);
                        c_profile(age,tpathi)                  = yd_profile(age,tpathi)/(1+tau_c);  
                        thetaa_profile(age,tpathi)             = theta_profile_grid(theta_index,age);
                        tax_paid_profile(age,tpathi)           = pension_lvl_t_loop(type_index) - yd_profile(age,tpathi);
                        tax_credits_transf_profile(age,tpathi) = yd_profile(age,tpathi); 
                        EITC_profile(age,tpathi)               = 0;
                        CTC_profile(age,tpathi)                = 0;
                        TANF_profile(age,tpathi)               = 0;
                        ccdf_fc_profile(age,tpathi)            = 0;
                        V_profile(age,tpathi)                  = log(yd_profile(age,tpathi)/((1+tau_c)*CE_scale)) - psi*(0.^(1+(1/Frisch)))./(1+(1/Frisch)) + beta*V_opt_realized_t(type_index,age+1,tpathi+1);                 
                    elseif age>1    
                        [yd_grid,EITC_grid,CTC_grid,TANF_grid]  = Tax_function(Policy_toggle_vec,EITC_policy_mat,CTC_policy_mat,TANF_policy_mat,tau_y,lambda_y_t_loop,y_grid,age); 
                        V_grid     = log(yd_grid/((1+tau_c)*CE_scale)) - psi*(h_grid.^(1+(1/Frisch)))./(1+(1/Frisch)) + beta*V_opt_realized_t(type_index,age+1,tpathi+1); 
                        [~,argmax] = max(V_grid); % best labor choice. 
                        h_profile(age,tpathi)                  = h_grid(argmax);
                        y_profile(age,tpathi)                  = w*theta*h_grid(argmax);
                        yd_profile(age,tpathi)                 = yd_grid(argmax);
                        c_profile(age,tpathi)                  = yd_grid(argmax)/(1+tau_c);
                        thetaa_profile(age,tpathi)             = theta_profile_grid(theta_index,age);
                        tax_paid_profile(age,tpathi)           = w*theta*h_grid(argmax) - yd_grid(argmax);
                        tax_credits_transf_profile(age,tpathi) = yd_profile(age,tpathi) - lambda_y_t_loop*y_profile(age,tpathi)^(1-tau_y);
                        EITC_profile(age,tpathi)               = EITC_grid(argmax);
                        CTC_profile(age,tpathi)                = CTC_grid(argmax);
                        TANF_profile(age,tpathi)               = TANF_grid(argmax);
                        ccdf_fc_profile(age,tpathi)            = 0;
                        V_profile(age,tpathi)                  = V_grid(argmax); 
                    else % age == 1  
                        [q_condopt,n_condopt,thetaindex_condopt,c_condopt,yd_condopt,V_condopt] = ParentConditionalMax_Speedy(par_calibration_vec,par_GE_vec,par_fixed_vec,Policy_toggle_vec,EITC_policy_mat,CTC_policy_mat,TANF_policy_mat,CCDF_policy_mat,theta_grid,theta_profile_grid(theta_index,age),thetak,age,CE_scale,h_grid,Vkid_t_loop,V_opt_realized_t(type_index,age+1,tpathi+1),cc_a_r_index,chi_c_epsval);
                        [~,EITC_grid,CTC_grid,TANF_grid] = Tax_function(Policy_toggle_vec,EITC_policy_mat,CTC_policy_mat,TANF_policy_mat,tau_y,lambda_y_t_loop,y_grid,age); 
                        [~,argmax] = max(V_condopt);  % best labor choice. 
                        h_profile(age,tpathi)                  = h_grid(argmax);
                        y_profile(age,tpathi)                  = y_grid(argmax);  
                        yd_profile(age,tpathi)                 = yd_condopt(argmax);
                        c_profile(age,tpathi)                  = c_condopt(argmax);
                        thetaa_profile(age,tpathi)             = theta_profile_grid(theta_index,age);
                        n_profile(age,tpathi)                  = n_condopt(argmax); 
                        q_profile(age,tpathi)                  = q_condopt(argmax); 
                        thetaindex_profile(age,tpathi)         = thetaindex_condopt(argmax); 
                        tax_paid_profile(age,tpathi)           = y_profile(age,tpathi) - yd_profile(age,tpathi);
                        tax_credits_transf_profile(age,tpathi) = yd_profile(age,tpathi) - lambda_y_t_loop*y_profile(age,tpathi)^(1-tau_y);
                        EITC_profile(age,tpathi)               = EITC_grid(argmax);
                        CTC_profile(age,tpathi)                = CTC_grid(argmax);
                        TANF_profile(age,tpathi)               = TANF_grid(argmax); 
                        CCDF_eligible                          = (CCDF_toggle ==2 && y_profile(age,tpathi)<CCDF_policy_mat(1) && h_profile(age,tpathi)>0);
                        tau_aux                                = CCDF_policy_mat(2) + (y_profile(age,tpathi)./CCDF_policy_mat(5)).*CCDF_policy_mat(3) + (y_profile(age,tpathi)./CCDF_policy_mat(5)).^(2).*CCDF_policy_mat(4); % literal subsidy rate (bounded by 0 in next step)
                        tau_CCDF                               = CCDF_eligible.*max(tau_aux,0);
                        gov_cc_expense_profile(age,tpathi)     = CCDF_eligible.*((cc_a_r_index==3).*tau_CCDF*n_profile(age,tpathi)*pn_t_loop) + (cc_a_r_index==2 || cc_a_r_index==3).*chi_c*min(chi_c_epsval,CCDF_policy_mat(7)); %CCDF_eligible.*((cc_a_r_index==3).*tau_CCDF*n_profile(age)*pn_t_loop + (cc_a_r_index==2 || cc_a_r_index==3).*chi_c_epsval*chi_c*(1-CCDF_policy_mat(7)));
                        ccdf_fc_profile(age,tpathi)            = (cc_a_r_index==2 || cc_a_r_index==3).*chi_c_epsval*chi_c;
                        V_profile(age,tpathi)                  = V_condopt(argmax);  
                    end % end age conditional
                end % end age loop
            
                h_opt_t_aux(type_index,:,tpathi)          = h_profile(:,tpathi); % the tpathi index value starts at 2 in values, first element is blank.
                c_opt_t_aux(type_index,:,tpathi)          = c_profile(:,tpathi);
                thetaa_opt_t_aux(type_index,:,tpathi)     = thetaa_profile(:,tpathi);
                y_opt_t_aux(type_index,:,tpathi)          = y_profile(:,tpathi); 
                yd_opt_t_aux(type_index,:,tpathi)         = yd_profile(:,tpathi);
                n_opt_t_aux(type_index,:,tpathi)          = n_profile(:,tpathi); 
                q_opt_t_aux(type_index,:,tpathi)          = q_profile(:,tpathi); 
                theta_opt_t_aux(type_index,:,tpathi)      = thetaindex_profile(:,tpathi); 
                ccdf_fc_opt_t_aux(type_index,:,tpathi)    = ccdf_fc_profile(:,tpathi);   
                V_opt_t_aux(type_index,:,tpathi)          = V_profile(:,tpathi);  
                
                tax_credtransf_t_aux(type_index,:,tpathi)    = tax_credits_transf_profile(:,tpathi);
                CCDF_received_opt_t_aux(type_index,:,tpathi) = gov_cc_expense_profile(:,tpathi);   
                EITC_received_opt_t_aux(type_index,:,tpathi) = EITC_profile(:,tpathi); 
                CTC_received_opt_t_aux(type_index,:,tpathi)  = CTC_profile(:,tpathi); 
                TANF_received_opt_t_aux(type_index,:,tpathi) = TANF_profile(:,tpathi); 
                        
            end % end type parfor loop 
        
            % Optimal choice of applying for CC at each period of transition except initial and final period
            options_temp = zeros(n_theta,n_thetak,n_ccsub_types,n_bins_ccsub_fc);
            for type_index = 1:n_types
                theta_index  = type_mat(type_index,1); 
                thetak_index = type_mat(type_index,2);
                cc_a_r_index = type_mat(type_index,3);
                cc_fc_index  = type_mat(type_index,4);
                options_temp(theta_index,thetak_index,cc_a_r_index,cc_fc_index) = V_opt_t_aux(type_index,1,tpathi);
            end
            ccdf_app_opt_aux   = zeros(n_theta,n_bins_ccsub_fc); 
            V_opt_realized_aux = zeros(n_theta,n_bins_ccsub_fc); 
            EV_noapp_aux       = zeros(n_theta,n_bins_ccsub_fc); 
            EV_app_aux         = zeros(n_theta,n_bins_ccsub_fc);
            for theta_index = 1:n_theta 
                for cc_fc_index = 1:n_bins_ccsub_fc
                    EV_noapp = sum(thetak_dist(theta_index,:).*options_temp(theta_index,:,1,cc_fc_index)); % don't apply
                    EV_app = (1-CCDF_policy_mat(6))*sum(thetak_dist(theta_index,:).*options_temp(theta_index,:,2,cc_fc_index)) + CCDF_policy_mat(6)*sum(thetak_dist(theta_index,:).*options_temp(theta_index,:,3,cc_fc_index));
                    if EV_app-EV_noapp>10^-8
                        argmax = 2; maxval = EV_app;
                    else
                        argmax = 1; maxval = EV_noapp;
                    end 
                    ccdf_app_opt_aux(theta_index,cc_fc_index) = argmax;
                    V_opt_realized_aux(theta_index,cc_fc_index) = maxval;
                    EV_noapp_aux(theta_index,cc_fc_index) = EV_noapp;
                    EV_app_aux(theta_index,cc_fc_index) = EV_app;
                end 
            end 
            for type_index = 1:n_types
                theta_index  = type_mat(type_index,1); 
                thetak_index = type_mat(type_index,2);
                cc_a_r_index = type_mat(type_index,3);
                cc_fc_index  = type_mat(type_index,4);
        
                ccdf_app_opt_t(type_index,1,tpathi)       = ccdf_app_opt_aux(theta_index,cc_fc_index);
                V_opt_realized_t(type_index,1,tpathi)     = V_opt_realized_aux(theta_index,cc_fc_index);
                V_opt_realized_t(type_index,2:end,tpathi) = V_opt_t_aux(type_index,2:end,tpathi);  
            end 
            % === END Consumer life cycle
            disp(['Tpathi index finished: ' num2str(tpathi)]);
        end % end transition path period loop
          
        % Update objects across transition path periods: these are all of the choices at any age for all of the types at each period on the transition path between the chosen starting and ending steady-state.
        h_opt_t(:,:,2:T_tp-1)          = h_opt_t_aux(:,:,2:T_tp-1);
        c_opt_t(:,:,2:T_tp-1)          = c_opt_t_aux(:,:,2:T_tp-1);
        y_opt_t(:,:,2:T_tp-1)          = y_opt_t_aux(:,:,2:T_tp-1); 
        yd_opt_t(:,:,2:T_tp-1)         = yd_opt_t_aux(:,:,2:T_tp-1);
        n_opt_t(:,:,2:T_tp-1)          = n_opt_t_aux(:,:,2:T_tp-1); 
        q_opt_t(:,:,2:T_tp-1)          = q_opt_t_aux(:,:,2:T_tp-1); 
        thetaa_opt_t(:,:,2:T_tp-1)     = thetaa_opt_t_aux(:,:,2:T_tp-1); 
        theta_opt_t(:,:,2:T_tp-1)      = theta_opt_t_aux(:,:,2:T_tp-1); 
        ccdf_fc_opt_t(:,:,2:T_tp-1)    = ccdf_fc_opt_t_aux(:,:,2:T_tp-1);
        tax_credtransf_opt_t(:,:,2:T_tp-1) = tax_credtransf_t_aux(:,:,2:T_tp-1);
        CCDF_received_opt_t(:,:,2:T_tp-1)  = CCDF_received_opt_t_aux(:,:,2:T_tp-1);   
        EITC_received_opt_t(:,:,2:T_tp-1)  = EITC_received_opt_t_aux(:,:,2:T_tp-1);  
        CTC_received_opt_t(:,:,2:T_tp-1)   = CTC_received_opt_t_aux(:,:,2:T_tp-1); 
        TANF_received_opt_t(:,:,2:T_tp-1)  = TANF_received_opt_t_aux(:,:,2:T_tp-1); 
        V_opt_t(:,:,2:T_tp-1)              = V_opt_t_aux(:,:,2:T_tp-1);  
        
        disp(['Time for all tpathi and type loop in minutes: ' toc(TSTART_TP_iteration_loop)/60]);
        
        % ======================== BEGIN Updating GE aggregate endogenous states in each t of transition
        TSTART_GE = tic;
        for tpathi = T_tp:-1:1           
            if tpathi>1 && tpathi<T_tp    
                % --- Updating other proportional GE objects 
                pn_t(tpathi) = pn_ratio_adjusted*sum(skill_dist_t(:,max(tpathi-j_a,1)).*theta_grid(:)); 

                % --- Updating proportional EITC, CTC, and TANF policy parameters using ex. pars and population income distribution: ratios always update; scaling factor is what might be held fixed
                subsidy_chic            = Policy_pars_mat_outputs_t(1,tpathi);  
                rationing_rate          = Policy_pars_mat_outputs_t(2,tpathi);  
                yp_cutoff               = Policy_pars_mat_outputs_t(3,tpathi); 
                subsidy_b0              = Policy_pars_mat_outputs_t(4,tpathi); 
                subsidy_b1              = Policy_pars_mat_outputs_t(5,tpathi); 
                transfer_proportion1    = Policy_pars_mat_outputs_t(6,tpathi); 
                transfer_proportion2    = Policy_pars_mat_outputs_t(7,tpathi); 
                refund_threshold        = Policy_pars_mat_outputs_t(8,tpathi); 
                phaseout_threshold      = Policy_pars_mat_outputs_t(9,tpathi); 
                
                % --- Updating proportional CCDF parameters with parent income distribution
                age_cutoff_distribution_lb = 1; % Note: census definition of income which is income from earnings and pensions, pretax not how it's coded in the lifecycle problem.
                age_cutoff_distribution_ub = j_r-1; % Don't put this above j_r-1
                income_dist                = []; y_aux = [];  Omega_aux = []; 
                y_aux = y_opt_t(:,age_cutoff_distribution_lb:age_cutoff_distribution_ub,tpathi); 
                Omega_aux = Omega_dist_t(:,age_cutoff_distribution_lb:age_cutoff_distribution_ub,tpathi); 
                Omega_aux = Omega_aux./sum(Omega_aux(:));            
                income_dist      = [y_aux(:) Omega_aux(:)]; % population income distribution
                income_dist      = sortrows(income_dist,1);
                income_dist(:,3) = cumsum(income_dist(:,2));
                [~,p50_arg]      = min(abs(income_dist(:,3)-0.50));
                yp50             = income_dist(p50_arg,1);    
                yp50_t(tpathi)   = yp50;
                [EITC_policy_mat_t(:,:,tpathi)] = EITC_policy(yp50/US_yp50,j_a,J); % evaluated at str = 2 and mean_inc_norm = yp50/68700
                [CTC_policy_mat_t(:,:,tpathi)]  = CTC_policy(yp50/US_yp50,j_a,J,transfer_proportion1,transfer_proportion2,refund_threshold,phaseout_threshold);
                [TANF_policy_mat_t(:,:,tpathi)] = TANF_policy(0,yp50/US_yp50,J);  
            
                % --- Updating proportional CCDF parameters using parenting families income distribution:
                age_cutoff_distribution_lb = 1;  
                age_cutoff_distribution_ub = 2;  
                income_dist                = []; y_aux = [];  Omega_aux = []; 
                y_aux = y_opt_t(:,age_cutoff_distribution_lb:age_cutoff_distribution_ub,tpathi); 
                Omega_aux = Omega_dist_t(:,age_cutoff_distribution_lb:age_cutoff_distribution_ub,tpathi); 
                Omega_aux = Omega_aux./sum(Omega_aux(:));            
                income_dist       = [y_aux(:) Omega_aux(:)]; % population income distribution
                income_dist       = sortrows(income_dist,1);
                income_dist(:,3)  = cumsum(income_dist(:,2));
                [~,parent_arg]    = min(abs(income_dist(:,3) - yp_cutoff)); % can toggle on an income cutoff
                cutoffpctiley_t(tpathi)     = income_dist(parent_arg,1); 
                [CCDF_policy_mat_t(:,:,tpathi)] = CCDF_policy(yp50,cutoffpctiley_t(tpathi),CCDF_toggle,subsidy_chic,rationing_rate,subsidy_b0,subsidy_b1); 
                
                % Pension level using last 5 years of working life, type-specific: 
                age_cutoff_distribution_lb = 3; 
                age_cutoff_distribution_ub = j_r-1;    
                pension_ave_temp = zeros(n_types,age_cutoff_distribution_ub-age_cutoff_distribution_lb+1);
                for pension_index = 1:size(pension_ave_temp,2) % 7 periods, 35 years
                    pension_ave_temp(:,pension_index) = y_opt_t(:,j_r-pension_index,max(tpathi-pension_index,1)); 
                end
                pension_lvl_t(:,tpathi)    = pension_rep_rate*sum(pension_ave_temp,2)/size(pension_ave_temp,2);% type-specific average income over 35 years before retirement

                % --- Construct updates aggregate objects
                % Update skill_dist_t (kid skill outcomes in tpathi)
                % and construct Vkid auxiliary object: unlike Omega_dist_t, here no loop over age  
                skill_dist_update = zeros(1,n_theta); 
                Vkid_temp         = -10^(8)*ones(n_theta,n_thetak,n_ccsub_types,n_bins_ccsub_fc);
                for type_index = 1:n_types
                    theta_index  = type_mat(type_index,1);
                    thetak_index = type_mat(type_index,2); 
                    cc_r_index   = type_mat(type_index,3); 
                    cc_fc_index  = type_mat(type_index,4);  
                    
                    if cc_r_index == 1
                        probccstatus = (ccdf_app_opt_t(type_index,1,tpathi)== 1); % did not apply 
                    elseif cc_r_index == 2
                        probccstatus = (1-CCDF_policy_mat_t(1,6,tpathi))*(ccdf_app_opt_t(type_index,1,tpathi) == 2); % applied, did not receive
                    else  
                        probccstatus = CCDF_policy_mat_t(1,6,tpathi)*(ccdf_app_opt_t(type_index,1,tpathi) == 2); % applied + received   
                    end
                    probfc     = chi_c_eps_dist(cc_fc_index);
                    probkid    = thetak_dist(theta_index,thetak_index);
                    probparent = skill_dist_t(theta_index,max(tpathi - j_a ,1)); % for parent, so always adults age j = 1 in period tpathi
                    
                    skill_dist_update(theta_opt_t(type_index,1,tpathi)) = skill_dist_update(theta_opt_t(type_index,1,tpathi)) + probfc*probccstatus*probparent*probkid;
                    Vkid_temp(theta_index,thetak_index,cc_r_index,cc_fc_index) = V_opt_t(type_index,1,min(tpathi+j_a,T_tp))*probkid*probccstatus*probfc; 
                end
                
                % Update Vkid_t:  
                Vkid_update = zeros(1,n_theta);
                for theta_index = 1:n_theta
                    Vkid_update(theta_index) = sum(Vkid_temp(theta_index,:,:,:),'all');
                end 
    
                % Update Omega_dist_t:
                % Update the tpathi I value of the joint distribution; use the outcomes of CC receipt from the period when the age j person of type type_index was parenting,
                % in tpathi this period was tpathi - age + 1. So if age = 1 in tpathi, then the period of the transition whose choices you use is tpathi.
                Omega_dist_aux = zeros(n_types,J);
                for type_index = 1:n_types 
                    theta_index  = type_mat(type_index,1);
                    thetak_index = type_mat(type_index,2); 
                    cc_r_index   = type_mat(type_index,3); 
                    cc_fc_index  = type_mat(type_index,4);  
                    for age = 1:J  
                        if cc_r_index == 1 % incorporate application choices into distribution over ccdf application/receipt/no app distribution
                            probccstatus = (ccdf_app_opt_t(type_index,1,max(tpathi-age+1,1))== 1); % did not apply 
                        elseif cc_r_index == 2
                            probccstatus = (1-CCDF_policy_mat_t(1,6,max(tpathi-age+1,1)))*(ccdf_app_opt_t(type_index,1,max(tpathi-age+1,1)) == 2); % prob. did not receive || applied
                        else  
                            probccstatus = CCDF_policy_mat_t(1,6,max(tpathi-age+1,1))*(ccdf_app_opt_t(type_index,1,max(tpathi-age+1,1)) == 2); % prob. did receive || applied  
                        end
                        probkid    = thetak_dist(theta_index,thetak_index);
                        probparent = skill_dist_t(theta_index,max(tpathi- age + 1 - j_a ,1)); 
                        probage    = 1/J;
                        probfc     = chi_c_eps_dist(cc_fc_index);
                        Omega_dist_aux(type_index,age) = probfc*probccstatus*probkid*probparent*probage;
                    end
                end 
                Omega_dist_t(:,:,tpathi) = Omega_dist_aux;
         
                % Updating lambda_y_t
                GDP_t_vec(tpathi) = sum(y_opt_t(:,:,tpathi).*Omega_dist_t(:,:,tpathi),'all');
                tau_c_rev   = tau_c*sum(c_opt_t(:,:,tpathi).*Omega_dist_t(:,:,tpathi),'all');
                GT          = sum((CCDF_received_opt_t(:,:,tpathi)+tax_credtransf_opt_t(:,:,tpathi)).*Omega_dist_t(:,:,tpathi),'all');
                tau_y_denom = sum(y_opt_t(:,:,tpathi).^(1-tau_y).*Omega_dist_t(:,:,tpathi),'all');
                if ThetaG*GDP_t_vec(tpathi) + GT > tau_c_rev                    
                    lambda_y_update = (GDP_t_vec(tpathi) + tau_c_rev - GT - ThetaG*GDP_t_vec(tpathi))/tau_y_denom;  
                else
                    lambda_y_update = 1;
                end
    
                % --- Construct GE residual
                if min(GE_toggle_mat(End_policy_vec_index,:)) == 1 % Only update aggregates for GE loops.
                    res_vec(1) = max(abs(skill_dist_t(:,tpathi) - skill_dist_update(:)));
                    res_vec(2) = max(abs(Vkid_t(:,tpathi) - Vkid_update(:))); 
                    res_vec(3) = abs(lambda_y_t(tpathi) - lambda_y_update);
                else 
                    res_vec = zeros(1,3);
                end
                res_vec_t(:,tpathi-1) = res_vec(:);
                res_t(tpathi-1) = max(abs(res_vec(:)));
                skill_dist_update_t(:,tpathi) = skill_dist_update(:);
                Vkid_update_t(:,tpathi)       = Vkid_update(:);
                lambda_y_update_t(tpathi)     = lambda_y_update;
            else
                skill_dist_update_t(:,tpathi) = skill_dist_t(:,tpathi);
                Vkid_update_t(:,tpathi)       = Vkid_t(:,tpathi);
                lambda_y_update_t(tpathi)     = lambda_y_t(tpathi);
            end
            % Resource and budget constraints for each tpathi: 
            RC_t(tpathi) = (1-ThetaG)*GDP_t_vec(tpathi) - sum(Omega_dist_t(:,:,tpathi).*(ccdf_fc_opt_t(:,:,tpathi) + c_opt_t(:,:,tpathi) + pn_t(tpathi)*n_opt_t(:,:,tpathi)),'all') ;
            bc_t(:,:,tpathi) = ccdf_fc_opt_t(:,:,tpathi) + c_opt_t(:,:,tpathi)*(1+tau_c) + pn_t(tpathi)*n_opt_t(:,:,tpathi) - CCDF_received_opt_t(:,:,tpathi) - yd_opt_t(:,:,tpathi);
            disptext = ['R.C.   = ',   num2str((1-ThetaG).*GDP_t_vec(tpathi) - sum(Omega_dist_t(:,:,tpathi).*(ccdf_fc_opt_t(:,:,tpathi)  + c_opt_t(:,:,tpathi)  + pn_t(tpathi).*n_opt_t(:,:,tpathi) ),'all'))  ]; disp(disptext); % resource constraint
            disptext = ['B.C.s. = ',  num2str((max(abs(Omega_dist_t(:,:,tpathi).*bc_t(:,:,tpathi)),[],'all'))) ]; disp(disptext); % individual budget constraints
        end % end updating transition path values

        % --- Updating GE objects only if will do another iteration
        if min(GE_toggle_mat(End_policy_vec_index,:)) == 1                  
            if max(abs(res_t(:)))>transition_path_residual && TP_iteration_count+1<=max_tp_iter
                update_rate = 0.8; 
                skill_dist_t(:,2:T_tp-1) = update_rate*skill_dist_update_t(:,2:T_tp-1) + (1-update_rate)*skill_dist_t(:,2:T_tp-1);
                Vkid_t(:,2:T_tp-1)       = update_rate*Vkid_update_t(:,2:T_tp-1) + (1-update_rate)*Vkid_t(:,2:T_tp-1);
                lambda_y_t(2:T_tp-1)     = update_rate*lambda_y_update_t(2:T_tp-1) + (1-update_rate)*lambda_y_t(2:T_tp-1);                
            end
        end
        disp('-----------------------------------------------------------');
        disp(['Transition from ' num2str(Start_policy_vec_index) ' to ' num2str(End_policy_vec_index) ', Mins: ' num2str(toc(TSTART_GE)/60)]);          
        disp(datetime)
        disp(['Time for GE TP loop in seconds: ' num2str(toc(TSTART_GE))]);
        disptext = ['Transition path loop # : ',  num2str(TP_iteration_count)]; disp(disptext);
        disptext = ['Θ grid = ', '[' num2str(theta_grid,'%0.3f ') ']']; disp(disptext);
        disptext = ['λ_y    = ', '[' num2str(lambda_y_t(:)','%0.3f ') ']']; disp(disptext);
        disp(['Transition path residuals: ' num2str(max(abs(res_t(:)))) ' , [' num2str(res_t) ']' ]);
        disp(['Vector of residuals      : ' num2str(max(abs(res_vec_t),[],1)) ]);
        % === END Updating GE aggregate endogenous states in each t of transition
        disp('-----------------------------------------------------------');
        TP_iteration_count = TP_iteration_count + 1;
        disp(num2str(GDP_t_vec))
        disp('-----------------------------------------------------------');
        figure(1); plot(GDP_t_vec); 
    
    end % end transition path outer loop   
    % ======================== END Transition path loop 

    % ======================== BEGIN printing and saving output
    diary on 
    disp('===================================================');
    disp(datetime)
    disp(['End of transition from ' num2str(Start_policy_vec_index) ' to ' num2str(End_policy_vec_index) ', Solution algorithm mins: ' num2str(toc(TSTART_GE)/60) ]);  
    disp(datetime)
    disptext = ['Transition path period #, loop # : ', num2str(tpathi) ', ' num2str(TP_iteration_count)]; disp(disptext);
    disptext = ['Θ grid = ', '[' num2str(theta_grid,'%0.3f ') ']']; disp(disptext);
    disptext = ['μ(Θ)   = ', '[' num2str(skill_dist_t(:,tpathi)','%0.3f ') ']']; disp(disptext);
    disptext = ['Vk(Θ)  = ', '[' num2str(Vkid_t(:,tpathi)', '%0.3f ') ']']; disp(disptext);
    disp(['Transition path residuals: ' num2str(max(abs(res_t))) ' , [' num2str(res_t) ']' ]);
    disp(['Vector of residuals      : ' num2str(res_vec) ]);
    diary on; disp(['Time in seconds for this TP loop of main file = ' num2str(toc(tstart_main_code))] ); diary off;
    disp('===================================================');
    diary off
    
    % -- Saving output and initialization file
    % Save workspace as TP output
    if save_output_toggle == 1
        save(transition_path_output_filename);
    end
    % Save select variables as initialization input for PE decomposition exercises
    if save_initialization_toggle == 1 && End_policy_vec_index == Benchmark_policy_vec_index
       save(initializing_tp_filename,'initializing_tp_filename' ,'Omega_dist_t' ,'Vkid_t' ,'skill_dist_t' ,'lambda_y_t','pension_lvl_t' ,'pn_t' ,'yp50_t' ,'cutoffpctiley_t' ,'GE_quantities_t' ,'GE_objects_t' ,'GDP_t_vec' ,'V_opt_t' ,'V_opt_realized_t' ,'ccdf_app_opt_t' ,'thetaa_opt_t' ,'theta_opt_t' ,'ccdf_fc_opt_t','yd_opt_t' ,'y_opt_t' ,'n_opt_t' ,'q_opt_t' ,'h_opt_t' ,'c_opt_t' ,'tax_credtransf_opt_t' ,'CCDF_received_opt_t' ,'EITC_received_opt_t' ,'CTC_received_opt_t' ,'TANF_received_opt_t' ,'Policy_toggle_t' ,'EITC_policy_mat_t' ,'CTC_policy_mat_t' ,'TANF_policy_mat_t' ,'CCDF_policy_mat_t' ,'Policy_pars_mat_inputs_t' ,'Policy_pars_mat_outputs_t');
    end
    % ======================== END printing and saving output
end
% ======================== END Solving Transition Path 

diary on; 
disp('===================================================');
disp(['Time in seconds for this main file = ' num2str(toc(tstart_main_code))] ); 
disp('===================================================');
diary off;