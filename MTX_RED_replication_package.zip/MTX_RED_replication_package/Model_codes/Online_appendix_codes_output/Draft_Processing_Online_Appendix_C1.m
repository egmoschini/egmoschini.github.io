%% Calibration comparative statics: plus or minus 20 percent
for Policy_vec_index = 1:15
    filename_temp = strcat('Raw_output_online_appendix\Output_appendix_C1', num2str(Policy_vec_index), '.mat'); 
    load([online_appendix_path filename_temp]);
    CalCompStat_Parameters_policy_mat_C1(:,Policy_vec_index) =[psi lambda_I b chi_c_fraction varlogthetak initial_corr_par pension_rep_rate];
    CalCompStat_Results_policy_mat_C1(:,Policy_vec_index) = ModelMoment_values_iter;
    CalCompStat_Targets_policy_mat_C1(:,Policy_vec_index) = DataMoment_values_iter;
    CalCompStat_Targets_policy_mat_C1(7,Policy_vec_index) = 0.01*CalCompStat_Targets_policy_mat_C1(7,Policy_vec_index); 
end
filename = [online_appendix_path 'Processed_output_online_appendix\Array_CompStats_C1.mat'];
clearvars -EXCEPT filename CalCompStat_Parameters_policy_mat_C1 CalCompStat_Results_policy_mat_C1 CalCompStat_Targets_policy_mat_C1
save(filename); 
