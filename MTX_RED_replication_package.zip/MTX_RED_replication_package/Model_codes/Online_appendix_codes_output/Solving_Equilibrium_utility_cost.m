%% == Begin: Re-initialize model environment primitives that only adjust their value in baseline equilibrium: 
if Policy_vec_index == 1
    % --- Re-initialize proportional GE objects for the baseline calibration loop: 
    thetan      = 1;               % --> proportional to average theta, fixed in counterfactuals and calibrated in baseline 
    chi_c       = chi_c_fraction*0.4;  % --> proportional to median income, calibrated in baseline
    pn_ratio_adjusted = 0.1617;         % --> proportional to after-tax and subsidy ratio of prices, fixed in counterfactuals and calibrated in baseline  
    
    % --- Guess of adult skill distribution for better itialization of thetak_dist.
    theta_grid_temp = linspace(lb_level^(1/density_grid_par_thetaa),(ub_proportion*ub_thetak)^(1/density_grid_par_thetaa),n_theta).^density_grid_par_thetaa; % temporary theta_grid lb implied is always 0 but never chosen. 
    p_diff  = [];
    p_diff = lognpdf(theta_grid_temp,0,varlogthetak^0.5); % --> evaluate cdf at mu of log(Θk) and calibration value varlogthetak
    skill_dist_temp = p_diff./sum(p_diff(:)); % --> skill distribution

    % --- Re-initialize conditional distribution over child skill endowment, thetak_dist -- thetak_dist = ones(n_theta,n_thetak)./n_thetak; 
    mulogk_continuous_iter = 0.1;
    thetak_dist = NaN(n_theta,n_thetak); logthetak_mat=NaN(n_theta,n_thetak); averaging_mat=NaN(n_theta,n_thetak);
    iter = 1;
    while iter<calibrating_iter_max_temp
        for j = 1:n_theta  
            mu     = mulogk_continuous_iter + initial_corr_par*(theta_grid_temp(j) - sum(theta_grid_temp.*skill_dist_temp));   % mean of conditional distribution of log(Θk)  
            p_diff = lognpdf(thetak_grid,mu,varlogthetak^0.5); % --> evaluate cdf at mu of log(Θk) and calibration value varlogthetak
            thetak_dist(j,:) = p_diff./sum(p_diff(:)); 
            logthetak_mat(j,:) = log(thetak_grid);
            averaging_mat(j,:) = thetak_dist(j,:).*skill_dist_temp(j);
        end 
        mulogk_continuous_iter = mulogk_continuous_iter*(abs(sum(averaging_mat(:).*exp(logthetak_mat(:)),'all')))^(-1);
        iter = iter+1;
    end 

    % --- Re-initialize adult skill grid bounds which held fixed in policy counterfactuals; 
    % Depend on initial skill grid bounds and calibrated λ_I and Θn
    res = 1; ub_theta = 1; 
    while abs(res)>10^-4
        auxI            = (gamma*ub_theta^(1-1/nu) + (1-gamma)*(thetan)^(1-1/nu))^(nu/(nu-1)); 
        ub_theta_update = lambda_I*((1-upsilon)*(thetak_grid(end))^(1-1/chi) + upsilon*(auxI)^(1-1/chi))^(chi/(chi-1));
        res             = ub_theta_update-ub_theta; 
        ub_theta        = ub_theta_update;  
    end 
    theta_grid = linspace(lb_level^(1/density_grid_par_thetaa),(ub_proportion*ub_theta)^(1/density_grid_par_thetaa),n_theta).^density_grid_par_thetaa; % lb implied is always 0 but never chosen. 
end 
% == End: Re-initialize Objects that only adjust in baseline

%% == Begin: Re-initialize GE objects and proportional GE objects that adjust in counterfactuals 
% Initializations only occur when the GE object is endogenized; otherwise
% held fixed at the previous Policy experiment's solution.
if min(GE_toggle_mat(Policy_vec_index,:)) == 1 % if it is fully GE, re-initialize
    
    % --- Re-initialize adult skill distribution skill_dist
    p_diff      = []; 
    p_diff      = lognpdf(theta_grid,0,varlogthetak^0.5); % evaluate cdf at mu of log(Θk) and calibration value varlogthetak^0.5
    skill_dist  = p_diff./sum(p_diff(:)); % skill distribution
    
    % --- Re-initialize Vkid 
    Vkid       = -45 + 30*theta_grid.^(0.1); % --> expected lifetime utility, adjusts for all equilibria
    % --- Re-initialize lambda_y 
    lambda_y   = 0.7783; % --> balances government budget constraint, adjusts for all equilibria

    % --- Re-initialize proportional GE objects that adjust in counterfactuals
    pn          = 0.2000; % --> proportional to average wage, adjusts for all equilibria
    pension_lvl = 0.3710*ones(n_types,1); % --> proportional to average pretax income for adults in 35 years before retirement.
    yp50        = 0.4;
    cutoffpctiley = 0.3*yp50;
else % Otherwise, set the relevant objects to their counterfactual or baseline values for the PE decomposition.
    Counterfactual_index = PE_decomp_reference_mat(Policy_vec_index);
    Baseline_index = 1;
    % -- GE_toggle_mat key: 1 ==> [skill_dist adjusts, Vkid adjusts, lambda_y adjusts, pn adjusts, yp50_policy_scaling adjusts, pension_lvl adjusts]  
    % If set to 2, PE is new equilibrium not old
    if min(GE_toggle_mat(Policy_vec_index,:)) == 0
        skill_dist = (1-GE_toggle_mat(Policy_vec_index,1))*skill_dist_policy_mat(:,Baseline_index)' + GE_toggle_mat(Policy_vec_index,1)*skill_dist_policy_mat(:,Counterfactual_index)'; 
        Vkid       = (1-GE_toggle_mat(Policy_vec_index,2))*Vkid_policy_mat(:,Baseline_index)'       + GE_toggle_mat(Policy_vec_index,2)*Vkid_policy_mat(:,Counterfactual_index)';
        lambda_y   = (1-GE_toggle_mat(Policy_vec_index,3))*GE_objects_policy_mat(5,Baseline_index)  + GE_toggle_mat(Policy_vec_index,3)*GE_objects_policy_mat(5,Counterfactual_index);
        pn         = (1-GE_toggle_mat(Policy_vec_index,4))*GE_objects_policy_mat(2,Baseline_index)  + GE_toggle_mat(Policy_vec_index,4)*GE_objects_policy_mat(2,Counterfactual_index);
        yp50       = (1-GE_toggle_mat(Policy_vec_index,5))*GE_objects_policy_mat(4,Baseline_index)  + GE_toggle_mat(Policy_vec_index,5)*GE_objects_policy_mat(4,Counterfactual_index);
        cutoffpctiley = (1-GE_toggle_mat(Policy_vec_index,5))*GE_objects_policy_mat(6,Baseline_index)  + GE_toggle_mat(Policy_vec_index,5)*GE_objects_policy_mat(6,Counterfactual_index);
        pension_lvl = (1-GE_toggle_mat(Policy_vec_index,6))*pension_lvl_policy_mat(:,Baseline_index)  + GE_toggle_mat(Policy_vec_index,6)*pension_lvl_policy_mat(:,Counterfactual_index);
    else
        skill_dist = skill_dist_policy_mat(:,Counterfactual_index)'; 
        Vkid       = Vkid_policy_mat(:,Counterfactual_index)';
        lambda_y   = GE_objects_policy_mat(5,Counterfactual_index);
        pn         = GE_objects_policy_mat(2,Counterfactual_index);
        yp50       = GE_objects_policy_mat(4,Counterfactual_index);
        cutoffpctiley = GE_objects_policy_mat(6,Counterfactual_index);
        pension_lvl = pension_lvl_policy_mat(:,Counterfactual_index);
    end
end

% --- Re-initialize policy values: EITC, CTC, TANF, and CCDF
[EITC_policy_mat] = EITC_policy(yp50/US_yp50,j_a,J);
[CTC_policy_mat]  = CTC_policy(yp50/US_yp50,j_a,J,transfer_proportion1,transfer_proportion2,refund_threshold,phaseout_threshold);
[TANF_policy_mat] = TANF_policy(0,yp50/US_yp50,J);  
[CCDF_policy_mat] = CCDF_policy(yp50,cutoffpctiley,CCDF_toggle,subsidy_chiu,rationing_rate,subsidy_b0,subsidy_b1);

% --- Re-initialize joint distribution
Omega_dist = zeros(n_types,J);
for type_index = 1:n_types
        theta_index  = type_mat(type_index,1);
        thetak_index = type_mat(type_index,2); 
        cc_r_index   = type_mat(type_index,3); 
        cc_fc_index  = type_mat(type_index,4); 
    for age = 1:J 
        if cc_r_index == 1
            probccstatus = 1; % did not apply         
        else  
            probccstatus = 0; % applied + received   
        end
        probkid    = thetak_dist(theta_index,thetak_index);
        probparent = skill_dist(theta_index);
        probage    = 1/J;
        probfc     = chi_c_eps_dist(cc_fc_index);
        Omega_dist(type_index,age) = probfc*probccstatus*probkid*probparent*probage;
    end
end
% == END: Re-initialize GE objects and proportional GE objects that adjust in counterfactuals


% initializing loop:
res_vec            = ones(1,3);
GE_iteration_count = 1;
index_biggest_res  = 1;
GEstart            = tic;

while max(res_vec)>res_GE_cutoff && GE_iteration_count<Cutoff_GE_iteration_count  
    GEloopstart         = tic;
    disp(['Residual GE: ' num2str(res_vec) ' Iteration GE, policy , cal: ' num2str(GE_iteration_count) ' , ' num2str(Policy_vec_index) ' , ' num2str(calibration_iter_count)  ]);

    % --- Updating parameter values 
    par_fixed_vec       = [J, j_a, j_r, n_types, n_bins_ccsub_fc, n_ccsub_types, n_childcare, n_theta, n_thetak, n_h, upsilon, beta, Frisch, chi, nu, gamma, OECD_child, chi_c, share_pension_taxed, beta1_wagegrowth, beta2_wagegrowth, beta3_wagegrowth];
    par_GE_vec          = [thetan, pn, w, tau_c, tau_y, lambda_y];
    par_calibration_vec = [b, lambda_I, psi, chi_u, initial_corr_par, varlogthetak, pension_rep_rate];
    
    % --- Consumer life cycle
    [V_opt,V_opt_realized,theta_opt,n_opt,q_opt,h_opt,c_opt,thetaa_opt,y_opt,yd_opt,ccdf_app_opt,ccdf_fc_opt,gov_cc_expense_opt,tax_credits_transf_opt,taxes_paid_opt,EITC_received_opt,CTC_received_opt,TANF_received_opt] = Lifecycle_utility_cost(Policy_toggle_vec,par_calibration_vec,par_GE_vec,par_fixed_vec,pension_lvl,EITC_policy_mat,CTC_policy_mat,TANF_policy_mat,CCDF_policy_mat,type_mat,theta_grid,thetak_grid,h_grid,chi_u_eps_grid,thetak_dist,Vkid);

    % --- Checking Vkid, skill dist, and income distribution for kinks/non monotonicity etc.
    apply_temp = []; eligibility_temp = [];  ls_temp = []; y_temp = [];
    for type_index = 1:n_types
        theta_index  = type_mat(type_index,1);
        thetak_index = type_mat(type_index,2); 
        cc_r_index   = type_mat(type_index,3);  
        cc_fc_index  = type_mat(type_index,4); 
        apply_temp(theta_index,thetak_index,cc_r_index,cc_fc_index)  = ccdf_app_opt(type_index,1);
        eligibility_temp(theta_index,thetak_index,cc_r_index,cc_fc_index) =  (y_opt(type_index,1)>0).*(y_opt(type_index,1)<CCDF_policy_mat(1,1));   
        ls_temp(theta_index,thetak_index,cc_r_index,cc_fc_index) = h_opt(type_index,1);
        y_temp(theta_index,thetak_index,cc_r_index,cc_fc_index) = y_opt(type_index,1);
    end
    apply = []; eligibility = [];  ls = []; income_parents= [];
    for theta_index = 1:n_theta 
        for thetak_index = 1:n_thetak
            for cc_fc_index = 1:n_bins_ccsub_fc
                if apply_temp(theta_index,thetak_index,1,cc_fc_index) == 1
                    cc_r_index_opt = 1;
                elseif apply_temp(theta_index,thetak_index,1,cc_fc_index) == 2
                    cc_r_index_opt = 3;
                end
            apply_aux(cc_fc_index) = chi_c_eps_dist(cc_fc_index).*cc_r_index_opt;
            eligibility_aux(cc_fc_index) = chi_c_eps_dist(cc_fc_index).*eligibility_temp(theta_index,thetak_index,cc_r_index_opt,cc_fc_index);
            ls_aux(cc_fc_index) = chi_c_eps_dist(cc_fc_index).*ls_temp(theta_index,thetak_index,cc_r_index_opt,cc_fc_index);
            income_aux(cc_fc_index) = chi_c_eps_dist(cc_fc_index).*y_temp(theta_index,thetak_index,cc_r_index_opt,cc_fc_index);
            end
            apply(theta_index,thetak_index) = sum(apply_aux);
            eligibility(theta_index,thetak_index) = sum(eligibility_aux);
            ls(theta_index,thetak_index) = sum(ls_aux);
            income_parents(theta_index,thetak_index) = sum(income_aux);
        end
    end
       
    % --- Updating GE aggregate endogenous states
    skill_dist_update = zeros(1,n_theta); 
    Vkid_temp         = 10^(8)*ones(n_theta,n_thetak,n_ccsub_types,n_bins_ccsub_fc);
    for type_index = 1:n_types
        theta_index  = type_mat(type_index,1);
        thetak_index = type_mat(type_index,2); 
        cc_r_index   = type_mat(type_index,3); 
        cc_fc_index  = type_mat(type_index,4);  
        
        if cc_r_index == 1
            probccstatus = (ccdf_app_opt(type_index,1) == 1); % did not apply 
        elseif cc_r_index == 2
            probccstatus = (1-CCDF_policy_mat(6))*(ccdf_app_opt(type_index,1) == 2); % applied, did not receive
        else  
            probccstatus = CCDF_policy_mat(6)*(ccdf_app_opt(type_index,1) == 2); % applied + received   
        end
        probfc = chi_c_eps_dist(cc_fc_index);

        skill_dist_update(theta_opt(type_index,1)) = skill_dist_update(theta_opt(type_index,1)) + probfc*probccstatus*skill_dist(theta_index)*thetak_dist(theta_index,thetak_index);
        Vkid_temp(theta_index,thetak_index,cc_r_index,cc_fc_index) = V_opt(type_index,1)*thetak_dist(theta_index,thetak_index)*probccstatus*probfc; 
    end

    Vkid_update = zeros(1,n_theta);
    for theta_index = 1:n_theta
        Vkid_update(theta_index) = sum(Vkid_temp(theta_index,:,:,:),'all');
    end

    % --- Conditional distribution over child skill assuming log(Θk) ~ N(mulogk,varlogthetak^0.5)  
    if Policy_vec_index == 1 % only calibrate the properties of this grid in the baseline 
        mulogk_continuous_iter = 0.1;
        thetak_dist = NaN(n_theta,n_thetak); logthetak_mat=NaN(n_theta,n_thetak); averaging_mat=NaN(n_theta,n_thetak);
        iter = 1;
        while iter<calibrating_iter_max_temp
            for j = 1:n_theta  
                mu     = mulogk_continuous_iter + initial_corr_par*(theta_grid(j) - sum(theta_grid.*skill_dist));   % conditional mean of distribution of log(Θk) given Θa(j)  
                p_diff = lognpdf(thetak_grid,mu,varlogthetak^0.5); % --> evaluate pdf at mu of log(Θk) and calibration value varlogthetak
                thetak_dist(j,:)   = p_diff./sum(p_diff(:)); 
                logthetak_mat(j,:) = log(thetak_grid);
                averaging_mat(j,:) = thetak_dist(j,:).*skill_dist_temp(j);
            end 
            mulogk_continuous_iter = mulogk_continuous_iter*(abs(sum(averaging_mat(:).*exp(logthetak_mat(:)),'all'))/1)^(-1);
            iter = iter+1;
        end      
    end

    % --- Updating joint distribution; construct with skill_dist_update if GE
    Omega_dist = zeros(n_types,J);
    parfor type_index = 1:n_types 
        theta_index  = type_mat(type_index,1);
        thetak_index = type_mat(type_index,2); 
        cc_r_index   = type_mat(type_index,3); 
        cc_fc_index  = type_mat(type_index,4);  
        for age = 1:J  
            if cc_r_index == 1 % incorporate application choices into distribution over ccdf application/receipt/no app distribution
                probccstatus = (ccdf_app_opt(type_index,age) == 1); % did not apply 
            elseif cc_r_index == 2
                probccstatus = (1-CCDF_policy_mat(6))*(ccdf_app_opt(type_index,age) == 2); % prob. did not receive || applied
            else  
                probccstatus = CCDF_policy_mat(6)*(ccdf_app_opt(type_index,age) == 2); % prob. did receive || applied  
            end
            probkid    = thetak_dist(theta_index,thetak_index);
            probparent = skill_dist(theta_index);
            probage    = 1/J;
            probfc     = chi_c_eps_dist(cc_fc_index);
            Omega_dist(type_index,age) = probfc*probccstatus*probkid*probparent*probage;
        end
    end 

    % --- Government budget constraint
    GDP         = sum(y_opt(:).*Omega_dist(:));
    tau_c_rev   = tau_c*sum(c_opt(:).*Omega_dist(:));  
    GT          = sum((gov_cc_expense_opt(:)+tax_credits_transf_opt(:)).*Omega_dist(:)); % contains pensions
    tau_y_denom = sum(y_opt(:).^(1-tau_y).*Omega_dist(:));
    if ThetaG*GDP + GT > tau_c_rev
        lambda_y_update = (GDP + tau_c_rev - GT - ThetaG*GDP)/tau_y_denom;  
    else
        lambda_y_update = 1;
    end

    % --- GE residuals
    if min(GE_toggle_mat(Policy_vec_index,:))==1 
        res_vec(1) = max(abs(skill_dist - skill_dist_update));
        res_vec(2) = max(abs(Vkid - Vkid_update));  
        res_vec(3) = abs(lambda_y - lambda_y_update);

        % --- GE updating rate for current iteration
        if GE_iteration_count <10
            update_rate = 0.8;
        elseif GE_iteration_count <15 
            update_rate = 0.3;
        elseif GE_iteration_count <25 
            update_rate = 0.1;
        elseif GE_iteration_count <60 
            update_rate = 0.05;
        else 
            update_rate = 0.01;
        end

       % --- Updating GE objects: 
       % only if will do another loop. Otherwise, set them consistent with the current output.
        if max(res_vec)>res_GE_cutoff && GE_iteration_count+1<Cutoff_GE_iteration_count
            skill_dist = update_rate*skill_dist_update + (1-update_rate)*skill_dist;
            Vkid       = update_rate*Vkid_update + (1-update_rate)*Vkid;
            lambda_y   = update_rate*lambda_y_update + (1-update_rate)*lambda_y;
        end
 
    else
        res_vec = zeros(1,3);
    end

    % --- Updating other proportional GE objects. Note: keep conditional statement because pn updates differently in counterfactuals. 
    if Policy_vec_index == 1  
        % --- CC productivity thetan, pn, and pn ratio adjusted:
        par_weights        = Omega_dist(:,1)/sum(Omega_dist(:,1),'all');
        temp_indep         = y_opt(:,1)/CCDF_policy_mat(5);
        subsidy_correction = (CCDF_toggle ==2).*(y_opt(:,1)<CCDF_policy_mat(1)).*(max(CCDF_policy_mat(2) + (y_opt(:,1)./CCDF_policy_mat(5)).*CCDF_policy_mat(3),0));
        subsidy_correction = subsidy_correction.*(subsidy_correction>0).*(gov_cc_expense_opt(:,1)>0);
        thetan             = max(exp(sum(par_weights.*log(theta_grid(type_mat(:,1))'))),0.01);
        ratiotemp          = lambda_y.*y_opt(:,1).^(1-tau_y)./h_opt(:,1);
        wage_aftx          = zeros(n_types,1); 
        wage_aftx((h_opt(:,1)>0)) = ratiotemp((h_opt(:,1)>0));        
        pn                 = pn_ratio_observed*sum(par_weights(:).*wage_aftx(:))/sum(par_weights(:).*(1-subsidy_correction(:)));  %pn_ratio_observed*sum(par_weights((h_opt(:,1)>0)).*wage_aftx((h_opt(:,1)>0)))/sum(par_weights((h_opt(:,1)>0)).*(1-subsidy_correction((h_opt(:,1)>0))));  
        pn_ratio_adjusted  = pn/sum(skill_dist.*theta_grid);       
        % --- Computing median in come of working adults for scaling chi_c
        age_cutoff_distribution_lb = 1; % I need to match the census definition of income which is income from earnings and pensions, pretax. That's not how it's coded in the lifecycle problem though.
        age_cutoff_distribution_ub = j_r-1; % Don't put this above j_r-1
        income_dist                = []; y_aux = [];  Omega_aux = []; 
        y_aux = y_opt(:,age_cutoff_distribution_lb:age_cutoff_distribution_ub); 
        Omega_aux = Omega_dist(:,age_cutoff_distribution_lb:age_cutoff_distribution_ub); Omega_aux = Omega_aux./sum(Omega_aux(:));  
        income_dist       = [y_aux(:) Omega_aux(:)]; % income distribution
        income_dist       = sortrows(income_dist,1);
        income_dist(:,3)  = cumsum(income_dist(:,2));
        [~,p50_arg]       = min(abs(income_dist(:,3)-0.50));
        yp50              = income_dist(p50_arg,1);      
        chi_c             = chi_c_fraction*yp50; % same scaling as CTC/EITC/TANF
    else 
        % --- CC pn:
        if min(GE_toggle_mat(Policy_vec_index,:))==1 
            pn = pn_ratio_adjusted*sum(skill_dist.*theta_grid); % updated differently in counterfactuals 
        end
    end  

    if min(GE_toggle_mat(Policy_vec_index,:))==1 
        % --- Updating proportional parameters of EITC, CTC, TANF, and pension_lvl, and realized ave conditional fc as a percent of median income using chosen income distribution: 
        age_cutoff_distribution_lb = 1; % I need to match the census definition of income which is income from earnings and pensions, pretax. That's not how it's coded in the lifecycle problem though.
        age_cutoff_distribution_ub = j_r-1; % Don't put this above j_r-1
        income_dist                = []; y_aux = [];  Omega_aux = []; 
        y_aux             = y_opt(:,age_cutoff_distribution_lb:age_cutoff_distribution_ub); 
        Omega_aux         = Omega_dist(:,age_cutoff_distribution_lb:age_cutoff_distribution_ub); Omega_aux = Omega_aux./sum(Omega_aux(:));  
        income_dist       = [y_aux(:) Omega_aux(:)]; % income distribution
        income_dist       = sortrows(income_dist,1);
        income_dist(:,3)  = cumsum(income_dist(:,2));
        [~,p50_arg]       = min(abs(income_dist(:,3)-0.50));
        yp50              = income_dist(p50_arg,1);      
        ypTANF            = 0;
    
        [EITC_policy_mat] = EITC_policy(yp50/US_yp50,j_a,J);
        [CTC_policy_mat]  = CTC_policy(yp50/US_yp50,j_a,J,transfer_proportion1,transfer_proportion2,refund_threshold,phaseout_threshold);
        [TANF_policy_mat] = TANF_policy(ypTANF,yp50/US_yp50,J);  
        
        % --- Updating proportional CCDF parameters using parenting families with resident children under age 12 income distribution:
        age_cutoff_distribution_lb = 1; 
        age_cutoff_distribution_ub = 2;
        income_dist       = []; y_aux = [];  Omega_aux = []; 
        y_aux             = y_opt(:,age_cutoff_distribution_lb:age_cutoff_distribution_ub); 
        Omega_aux         = Omega_dist(:,age_cutoff_distribution_lb:age_cutoff_distribution_ub); Omega_aux = Omega_aux./sum(Omega_aux(:));  
        income_dist       = [y_aux(:) Omega_aux(:)]; % parenting families income distribution
        income_dist       = sortrows(income_dist,1);
        income_dist(:,3)  = cumsum(income_dist(:,2));
        [~,parent_arg]    = min(abs(income_dist(:,3) - yp_cutoff)); % can toggle on an income cutoff
        cutoffpctiley     = income_dist(parent_arg,1); % cutoff for families with very young kids.
        [CCDF_policy_mat] = CCDF_policy(yp50,cutoffpctiley,CCDF_toggle,subsidy_chiu,rationing_rate,subsidy_b0,subsidy_b1); % Normalize with median household income from census - that's all households including retirees.
    
        % --- Updating pension level using last 5 years of working life, type-specific: 
        age_cutoff_distribution_lb = 3; 
        age_cutoff_distribution_ub = j_r-1;    
        pension_lvl         = ones(n_types,1);
        y_ave_pension       = (1/(age_cutoff_distribution_ub-age_cutoff_distribution_lb+1))*sum(y_opt(:,age_cutoff_distribution_lb:age_cutoff_distribution_ub),2); % type-specific average income over 35 years before retirement
        pension_lvl(:)      = pension_rep_rate*y_ave_pension;  
    end

    % --- Ave f.c. draw of CCDF applicants
    flag_ccdf_app = (ccdf_app_opt(:,1) == 2);
    fixed_cost_paid_draw = ccdf_fc_opt(:,1,1);
    Omega_aux            = Omega_dist(:,1); Omega_aux = Omega_aux./sum(Omega_aux(:));  
    ave_fc_pct_yp50      = 100*sum(Omega_aux(flag_ccdf_app==1).*fixed_cost_paid_draw(flag_ccdf_app==1)./sum(Omega_aux(flag_ccdf_app==1)))/yp50;

    disp('========================================='); 
    disp(['Resource Constraint GE loop: ' num2str( sum(Omega_dist(:).*(ccdf_fc_opt(:) + c_opt(:) + pn*n_opt(:)))- (1-ThetaG)*GDP )]);
    disptext = ['Loop time, GE total time, GE iter = ', '[' num2str(toc(GEloopstart),'% 0.0f ') ' ' num2str(toc(GEstart),'% 0.0f ') ' ' num2str(GE_iteration_count,'% 0.0f ') ']']; disp(disptext);
    disptext = ['Θ grid        = ', '[' num2str(theta_grid,'%0.3f ') ']']; disp(disptext);
    disptext = ['μ(Θ)          = ', '[' num2str(skill_dist,'%0.3f ') '] ' num2str(sum(skill_dist(:))) ',' num2str(sum(Omega_dist(:)))  ]; disp(disptext);
    disptext = ['Vk(Θ)         = ', '[' num2str(Vkid,'%0.3f ') ']']; disp(disptext);
    GE_iteration_count = GE_iteration_count+ 1;
end % end equilibrium loop
