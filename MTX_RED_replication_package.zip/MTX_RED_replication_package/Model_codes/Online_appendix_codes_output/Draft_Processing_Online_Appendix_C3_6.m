% Processing TP output 
for Final_SS_index =  [2 3]
    Start_SS_index = 1;
    TSTART = tic;
    disp(['Beginning: ' num2str(Final_SS_index)]); disp(datetime); 
    transition_path_output_filename = [online_appendix_path 'Raw_output_online_appendix\Output_appendix_TP_C3_6_' num2str(Start_SS_index) '_' num2str(Final_SS_index)];
    load(transition_path_output_filename);

    % earnings profiles and welfare calculations parameters
    wage_dist_levels = []; 
    for type_index = 1:n_types
        theta_index  = type_mat(type_index,1); 
        thetak_index = type_mat(type_index,2);
        cc_a_r_index = type_mat(type_index,3);
        cc_fc_index  = type_mat(type_index,4); 
    
        for age = 1:J
            labor_eff_units = theta_grid(theta_index);
            wage_growth_age = beta1_wagegrowth*(age-1) + beta2_wagegrowth*(age-1)^2 + beta3_wagegrowth*(age-1)^3;
            wage_dist_levels(type_index,age) = labor_eff_units*(1+wage_growth_age);
        end
    end
    
    denomW = zeros(1,J);
    for age_initial = 1:J
        denomW_aux = 0;
        for age = age_initial:J
            denomW_aux = denomW_aux + beta^(age-age_initial);
        end 
        denomW(age_initial) = denomW_aux;
    end

    % Initializing
    Array_policy_t   = zeros(34,T_tp);
    EV_ax_ante_age_t = zeros(J,T_tp);  
    W_change_newborns_t = zeros(n_thetak,T_tp);
    W_change_newborns_ave_t = zeros(1,T_tp);
    W_change_adults_t = zeros(n_theta,J,T_tp);
    W_change_adults_ave_t = zeros(J,T_tp);
    Share_gain_newborns_t = zeros(1,T_tp);
    Share_lose_newborns_t = zeros(1,T_tp);
    Share_indiff_newborns_t = zeros(1,T_tp);
    Share_gain_adults_t = zeros(J,T_tp);
    Share_lose_adults_t = zeros(J,T_tp);
    Share_indiff_adults_t = zeros(J,T_tp);
    EV_adults_t = NaN(n_theta,J,T_tp);

    y_ave_t = zeros(J,T_tp);
    yd_ave_t = zeros(J,T_tp);
    h_ave_t = zeros(J,T_tp);
    c_ave_t = zeros(J,T_tp);
    q_ave_t = zeros(J,T_tp);
    n_ave_t = zeros(J,T_tp);
    skill_ave_t = zeros(J,T_tp);
    theta_ave_t = zeros(J,T_tp);

    skill_ave_change_age_t = zeros(J,T_tp);
    q_ave_change_age_t = zeros(J,T_tp);
    n_ave_change_age_t = zeros(J,T_tp);
    h_ave_change_age_t = zeros(J,T_tp);
    c_ave_change_age_t = zeros(J,T_tp);
    theta_ave_change_age_t = zeros(J,T_tp);

    q_change_ave_age_t = zeros(J,T_tp);
    n_change_ave_age_t = zeros(J,T_tp);
    h_change_ave_age_t = zeros(J,T_tp);
    c_change_ave_age_t = zeros(J,T_tp);
    y_change_ave_age_t = zeros(J,T_tp);
    yd_change_ave_age_t = zeros(J,T_tp);
    theta_change_ave_age_t = zeros(J,T_tp);

    cdf_skill_dist_t = zeros(n_theta,T_tp);

    tax_rate_ave_inc_t = zeros(1,T_tp);
    target_pct_Y_G_t = zeros(1,T_tp);
    var_y_workingpop_t = zeros(1,T_tp);
    var_yd_workingpop_t = zeros(1,T_tp);
    var_skill_t = zeros(1,T_tp);
    rho_thetay_t = zeros(1,T_tp);
    rho_rry_t = zeros(1,T_tp);
    par_p50p10_t = zeros(1,T_tp);

    G_spending_change_t = zeros(1,T_tp);
    ave_tax_rate_change_t = zeros(1,T_tp);
    q_ave_change_t = zeros(1,T_tp);
    n_ave_change_t = zeros(1,T_tp);
    skill_ave_change_t = zeros(1,T_tp);
    h_ave_change_t = zeros(1,T_tp);
    GDP_change_t = zeros(1,T_tp);
    c_ave_change_t = zeros(1,T_tp);
    par_p50p10_change_t = zeros(1,T_tp);
    var_skill_change_t = zeros(1,T_tp);
    var_ypop_change_t = zeros(1,T_tp);
    rho_thetay_change_t = zeros(1,T_tp);
    rho_rry_change_t = zeros(1,T_tp);

    weight_thetak_t = NaN(n_thetak,T_tp);
    EV_newborns_t = NaN(n_thetak,T_tp);  
    std_y_workingpop_t    = NaN(1,T_tp); 
    mean_y_workingpop_t   = NaN(1,T_tp); 
    cv_y_workingpop_t     = NaN(1,T_tp); 
    var_logy_workingpop_t = NaN(1,T_tp); 
    p50p10_skill_t = NaN(1,T_tp); 
    p90p50_skill_t = NaN(1,T_tp); 
    p90p10_skill_t = NaN(1,T_tp); 
    p99p10_skill_t = NaN(1,T_tp); 
    p10skill_t = NaN(1,T_tp); 
    p50skill_t = NaN(1,T_tp); 
    p90skill_t = NaN(1,T_tp); 
    mean_skill_t = NaN(1,T_tp); 
    pctile_skill_t = NaN(100,T_tp);
    ave_p90_p50_skill_t = NaN(1,T_tp); 
    ave_p50_p10_skill_t = NaN(1,T_tp); 
    ave_p90_p10_skill_t = NaN(1,T_tp); 
    
    ave_q5_q1_t = NaN(1,T_tp); 
    ave_q3_q1_t = NaN(1,T_tp); 
    ave_q5_q3_t = NaN(1,T_tp); 
    
    ave_p10_skill_t = NaN(1,T_tp); 
    ave_p50_skill_t = NaN(1,T_tp); 
    ave_p90_skill_t = NaN(1,T_tp); 
    ave_p81_p100_skill_t = NaN(1,T_tp); 
    ave_p41_p60_skill_t = NaN(1,T_tp); 
    ave_p01_p20_skill_t = NaN(1,T_tp); 
    std_skill_t = NaN(1,T_tp); 
    cv_skill_t = NaN(1,T_tp); 
    var_logskill_t = NaN(1,T_tp); 
    gini_skill_t = NaN(1,T_tp);  
    
    ave_p50_p10_skill_change_t = NaN(1,T_tp); 
    ave_p90_p10_skill_change_t = NaN(1,T_tp); 
    ave_p90_p50_skill_change_t = NaN(1,T_tp); 
    meanskill_change_t = NaN(1,T_tp); 
    ave_p50_skill_change_t = NaN(1,T_tp); 
    var_logskill_change_t = NaN(1,T_tp); 
    gini_skill_change_t = NaN(1,T_tp); 
    cv_skill_change_t = NaN(1,T_tp); 
    cv_y_workingpop_change_t = NaN(1,T_tp);  

    % TP period loop
    for tpathi = 1:T_tp % begin transition path period loop      
        for age = 1:J             
            % =========================================== BEGIN WELFARE CHANGES (several measures): 
            % ==> Measure #1: Newborns given theta_k
            % --> Step 1 of 2: Construct relevant expected values
            if age == 1 % same for all ages, so only do this once. 
                EV_temp = []; ccdf_app_temp= []; weight_temp = NaN(n_theta,n_thetak,n_ccsub_types,n_bins_ccsub_fc);
                for type_index = 1:n_types  
                    weight_temp(type_mat(type_index,1),type_mat(type_index,2),type_mat(type_index,3),type_mat(type_index,4)) = J*Omega_dist_t(type_index,1,tpathi);
                    EV_temp(type_mat(type_index,1),type_mat(type_index,2),type_mat(type_index,3),type_mat(type_index,4)) = Vkid_t(theta_opt_t(type_index,1,tpathi),tpathi);
                end  
                
                for thetak_index = 1:n_thetak
                    weight_given_thetak = []; 
                    weight_given_thetak = squeeze(weight_temp(:,thetak_index,:,:))./sum(weight_temp(:,thetak_index,:,:),'all');
                    EV_newborns_t(thetak_index,tpathi)   = sum(weight_given_thetak.*squeeze(EV_temp(:,thetak_index,:,:)),'all');
                    weight_thetak_t(thetak_index,tpathi) = sum(weight_temp(:,thetak_index,:,:),'all');
                end
                % --> Step 2 of 2: Construct welfare change for given type thetak
                W_change_newborns_t(:,tpathi) = 100*(exp((EV_newborns_t(:,tpathi) - EV_newborns_t(:,1))/(denomW(1)))-1)  ;
                % Average across types of welfare change given type (theta_k)
                W_change_newborns_ave_t(tpathi) = sum(weight_thetak_t(:,tpathi).*W_change_newborns_t(:,tpathi),'all');
                % Share gaining, losing, and indifferent for newborns:
                Share_gain_newborns_t(tpathi)   = sum(weight_thetak_t(:,tpathi).*(W_change_newborns_t(:,tpathi)>0),'all'); 
                Share_lose_newborns_t(tpathi)   = sum(weight_thetak_t(:,tpathi).*(W_change_newborns_t(:,tpathi)<0),'all'); 
                Share_indiff_newborns_t(tpathi) = sum(weight_thetak_t(:,tpathi).*(W_change_newborns_t(:,tpathi)==0),'all'); 
            end % end age conditional 
            % ==> Measure #2: Newborns given theta_k
            % --> Step 1 of 2: Construct relevant expected values
            EV_temp = []; EV_temp_bsln = [];
            EV_temp = sum(J*Omega_dist_t(:,age,tpathi).*V_opt_realized_t(:,age,tpathi));
            EV_temp_bsln = sum(J*Omega_dist_t(:,age,1).*V_opt_realized_t(:,age,1));
            % --> Step 2 of 2: Construct welfare change 
            W_change_bvi_ave_t(age,tpathi) = 100*(exp((EV_temp - EV_temp_bsln)/(denomW(age)))-1)  ; 
            % ==> Measure #3: Adults given theta_a and age j
            EV_temp = NaN(n_theta,n_thetak,n_ccsub_types,n_bins_ccsub_fc); 
            ccdf_app_temp= NaN(n_theta,n_thetak,n_bins_ccsub_fc);
            for type_index = 1:n_types  
                EV_temp(type_mat(type_index,1),type_mat(type_index,2),type_mat(type_index,3),type_mat(type_index,4)) = V_opt_realized_t(type_index,age,tpathi);
                ccdf_app_temp(type_mat(type_index,1),type_mat(type_index,2),type_mat(type_index,4)) = ccdf_app_opt_t(type_index,age,tpathi);
            end              
            EV_adults_aux = NaN(n_theta,n_thetak,n_bins_ccsub_fc);
            for theta_index = 1:n_theta
                weight_temp = NaN(n_thetak,n_bins_ccsub_fc);
                for thetak_index = 1:n_thetak
                    for cc_fc_index = 1:n_bins_ccsub_fc  
                        weight_temp(thetak_index,cc_fc_index) = thetak_dist(theta_index,thetak_index)*chi_c_eps_dist(cc_fc_index);
                        % -- Step 1 of 1: construct relevant EV 
                        if ccdf_app_temp(theta_index,thetak_index,cc_fc_index) == 1 % incorporate application choices into distribution over ccdf application/receipt/no app distribution
                            EV_adults_aux(theta_index,thetak_index,cc_fc_index)      = weight_temp(thetak_index,cc_fc_index)*EV_temp(theta_index,thetak_index,1,cc_fc_index);
                        else 
                            EV_adults_aux(theta_index,thetak_index,cc_fc_index)      = weight_temp(thetak_index,cc_fc_index)*(Policy_pars_mat_inputs_t(2,tpathi)*EV_temp(theta_index,thetak_index,2,cc_fc_index)+ (1-Policy_pars_mat_inputs_t(2,tpathi))*EV_temp(theta_index,thetak_index,3,cc_fc_index));
                        end
                    end
                end
                % --> Step 2 of 2: Construct welfare change type_mat(type_index,1),type_mat(type_index,2),type_mat(type_index,4)
                EV_adults_t(theta_index,age,tpathi) = sum(EV_adults_aux(theta_index,:,:),'all');
                W_change_adults_t(theta_index,age,tpathi) = 100*(exp((EV_adults_t(theta_index,age,tpathi) - EV_adults_t(theta_index,age,1))/(denomW(age)))-1)  ;
            end 
             
            % Average across types of welfare change given type (theta_a)
            W_change_adults_ave_t(age,tpathi) = sum(skill_dist_t(:,tpathi).*W_change_adults_t(:,age,tpathi),'all');
            % Share gaining, losing, and indifferent for adults:
            Share_gain_adults_t(age,tpathi)   = sum(skill_dist_t(:,tpathi).*(W_change_adults_t(:,age,tpathi)>0),'all'); 
            Share_lose_adults_t(age,tpathi)   = sum(skill_dist_t(:,tpathi).*(W_change_adults_t(:,age,tpathi)<0),'all'); 
            Share_indiff_adults_t(age,tpathi) = sum(skill_dist_t(:,tpathi).*(W_change_adults_t(:,age,tpathi)==0),'all');             
            % =========================================== END WELFARE CHANGES         
            % =========================================== BEGIN AGE-SPECIFIC QUANTITIES AND CHANGES
            % Quantities by age
            y_ave_t(age,tpathi) = sum(J*Omega_dist_t(:,age,tpathi).*y_opt_t(:,age,tpathi));
            yd_ave_t(age,tpathi) = sum(J*Omega_dist_t(:,age,tpathi).*yd_opt_t(:,age,tpathi));
            h_ave_t(age,tpathi) = sum(J*Omega_dist_t(:,age,tpathi).*h_opt_t(:,age,tpathi));
            c_ave_t(age,tpathi) = sum(J*Omega_dist_t(:,age,tpathi).*c_opt_t(:,age,tpathi));
            q_ave_t(age,tpathi) = sum(J*Omega_dist_t(:,age,tpathi).*q_opt_t(:,age,tpathi));
            n_ave_t(age,tpathi) = sum(J*Omega_dist_t(:,age,tpathi).*n_opt_t(:,age,tpathi));
            skill_ave_t(age,tpathi) = sum(J*Omega_dist_t(:,age,tpathi).*wage_dist_levels(:,age));
            if age == 1
                theta_ave_t(age,tpathi) = 100.*sum(J*Omega_dist_t(:,age,tpathi).*theta_grid(theta_opt_t(:,age,tpathi))');
            else
                theta_ave_t(age,tpathi) = 0;
            end
            % Percent change in age-specific averages
            skill_ave_change_age_t(age,tpathi) = 100*(skill_ave_t(age,tpathi)/skill_ave_t(age,1) - 1);
            q_ave_change_age_t(age,tpathi) = 100*(q_ave_t(age,tpathi)/q_ave_t(age,1) - 1);
            n_ave_change_age_t(age,tpathi) = 100*(n_ave_t(age,tpathi)/n_ave_t(age,1) - 1);
            h_ave_change_age_t(age,tpathi) = 100*(h_ave_t(age,tpathi)/h_ave_t(age,1) - 1);
            c_ave_change_age_t(age,tpathi) = 100*(c_ave_t(age,tpathi)/c_ave_t(age,1) - 1);
            if age == 1
                theta_ave_change_age_t(age,tpathi) = 100.*sum(J*Omega_dist_t(:,age,tpathi).*(theta_ave_t(age,tpathi)./theta_ave_t(age,1) - 1));
            else
                theta_ave_change_age_t(age,tpathi) = 0;
            end  
            % =========================================== END AGE-SPECIFIC STATS
        end % end age loop
        % =========================================== BEGIN POPULATION STATS
        % Tax rate at average income in baseline equilibrium average income for working-age adults
        weight_temp = [];  
        weight_temp = Omega_dist_t(:,1:j_r-1,1); weight_temp = weight_temp./sum(weight_temp(:)); 
        y_temp = [];
        y_temp = sum(weight_temp.*y_opt_t(:,1:j_r-1,1),'all'); % compute tax rate at average income of INITIAL STEADY STATE
        tax_rate_ave_inc_t(tpathi) = 100*(1-(lambda_y_t(tpathi)*y_temp^(1-tau_y))/y_temp); 
        % Total government spending
        target_pct_Y_G_t(tpathi)   = 100*sum((CCDF_received_opt_t(:,:,tpathi)+tax_credtransf_opt_t(:,:,tpathi)+ThetaG*GDP_t_vec(tpathi)).*Omega_dist_t(:,:,tpathi),'all')/GDP_t_vec(tpathi);
        % Population variance of pretax income working age population
        ytemp = []; ytemp = y_opt_t(:,1:j_r-1,tpathi); 
        wtemp = []; wtemp = Omega_dist_t(:,1:j_r-1,tpathi); wtemp = wtemp./sum(wtemp(:));
        var_logy_workingpop_t(tpathi)  = var(log(ytemp(:)),wtemp(:));
        std_y_workingpop_t(tpathi)  = std(ytemp(:),wtemp(:));
        mean_y_workingpop_t(tpathi) = sum(ytemp(:).*wtemp(:));
        cv_y_workingpop_t(tpathi)   = std_y_workingpop_t(tpathi)/mean_y_workingpop_t(tpathi);
        % Population variance of after-tax (disposible) income working age population
        ytemp = []; ytemp = yd_opt_t(:,1:j_r-1,tpathi); 
        wtemp = []; wtemp = Omega_dist_t(:,1:j_r-1,tpathi); wtemp = wtemp./sum(wtemp(:));
        var_logy_workingpop_t(tpathi)  = var(log(ytemp(:)),wtemp(:)); 
        % CDF of adult skill 
        cdf_skill_dist_t(:,tpathi) = cumsum(skill_dist_t(:,tpathi));
        % Variance of adult skill
        var_skill_t(tpathi) = var(theta_grid,skill_dist_t(:,tpathi));
        % Correlation of child skill outcomes and adult income 
        [result] = weighted_correlation_coeff(y_opt_t(:,1,tpathi),theta_opt_t(:,1,tpathi),Omega_dist_t(:,1,tpathi)/sum(Omega_dist_t(:,1,tpathi)));
        rho_thetay_t(tpathi) = result;
        % Correlation rank-rank (Chetty et al 2014) and Gini coefficient
        % Need to take expectation over child income as adult conditional on adult type over
        % own child type and subsidy receipt.
        % Only do this for the GE experiments, it is time consuming  
        if Final_SS_index == 2 ||  Final_SS_index == 4
            parent_j = j_a; % SEE SECTION iv.a PAGE 1569 IN CHETTY ET AL 2014
            kid_j = 3;
            y_par_theta = zeros(n_theta,n_thetak,n_ccsub_types); 
            y_kid_theta = zeros(n_theta,n_thetak,n_ccsub_types); 
            weight_ykid = zeros(n_theta,n_thetak,n_ccsub_types);        
            for type_index = 1:n_types
                theta_index  = type_mat(type_index,1);
                thetak_index = type_mat(type_index,2); 
                cc_r_index   = type_mat(type_index,3);  
                cc_fc_index  = type_mat(type_index,4); 
                y_par_theta(theta_index,thetak_index,cc_r_index,cc_fc_index) = y_opt_t(type_index,parent_j,tpathi); 
                y_kid_theta(theta_index,thetak_index,cc_r_index,cc_fc_index) = y_opt_t(type_index,kid_j,tpathi); 
                weight_ykid(theta_index,thetak_index,cc_r_index,cc_fc_index) = Omega_dist_t(type_index,kid_j,tpathi);
            end        
            for theta_index = 1:n_theta
                weight_ykid(theta_index,:,:,:) = weight_ykid(theta_index,:,:,:)./sum(weight_ykid(theta_index,:,:,:),'all');
            end
            wy_kid_theta = weight_ykid.*y_kid_theta;
            rrcorr_dist      = zeros(n_types,5);  
            for type_index = 1:n_types
                theta_index  = type_mat(type_index,1);
                thetak_index = type_mat(type_index,2); 
                cc_r_index   = type_mat(type_index,3);
                cc_fc_index  = type_mat(type_index,4); 
                rrcorr_dist(type_index,1) = y_par_theta(theta_index,thetak_index,cc_r_index,cc_fc_index);
                rrcorr_dist(type_index,2) = sum(wy_kid_theta(theta_opt(type_index,1),:,:),'all'); % expected income
                rrcorr_dist(type_index,3) = Omega_dist_t(type_index,1,tpathi)/sum(Omega_dist_t(:,1,tpathi));
            end          
            rrcorr_dist      = sortrows(rrcorr_dist,1);
            for order_index = 1:n_types
                rrcorr_dist(order_index,4) = order_index;
            end         
            rrcorr_dist      = sortrows(rrcorr_dist,2);
            for order_index = 1:n_types
                rrcorr_dist(order_index,5) = order_index;
            end
            [result] = weighted_correlation_coeff(rrcorr_dist(:,4),rrcorr_dist(:,5),rrcorr_dist(:,3));
            rho_rry_t(tpathi) = result;
        else
            rho_rry_t(tpathi) = 9999;
        end
        % Pretax income inequality stats - to match GRID moments 25-34 
        income_dist      = []; y_temp = []; h_temp = []; Omega_dist_temp= [];
        y_temp = y_opt_t(:,2:3,tpathi); 
        logy_temp = log(y_temp(:));  
        h_temp = h_opt_t(:,2:3,tpathi); 
        wage_temp                     = wage_dist_levels(:,2:3);
        flag_working_and_in_wagerange = (h_temp(:)>0).*(wage_temp(:)>thetaminthreshold_GRID).*(wage_temp(:)<thetamaxthreshold_GRID); 
        Omega_dist_temp_aux  = Omega_dist_t(:,2:3,tpathi); Omega_dist_temp_aux = Omega_dist_temp_aux./sum(Omega_dist_temp_aux(:)); 
        Omega_dist_temp      = Omega_dist_temp_aux(:);
        income_dist          = [logy_temp((flag_working_and_in_wagerange==1)) Omega_dist_temp((flag_working_and_in_wagerange==1))./sum(Omega_dist_temp((flag_working_and_in_wagerange==1)))];
        income_dist          = sortrows(income_dist,1);
        income_dist(:,3)     = cumsum(income_dist(:,2));
        [~,p50yarg]          = min(abs(income_dist(:,end)-0.5));
        [~,p10yarg]          = min(abs(income_dist(:,end)-0.1));
        par_p50p10_t(tpathi) = income_dist(p50yarg,1) - income_dist(p10yarg,1);

        % CDF of adult skill 
        cdf_skill_dist_t(:,tpathi) = cumsum(skill_dist_t(:,tpathi));
        cdf_skill_dist_t(:,tpathi) = cdf_skill_dist_t(:,tpathi)./cdf_skill_dist_t(end,tpathi); % Normalizing
    
        % Percentile moments of adult skill
        [~,p10skill] = min(abs(cdf_skill_dist_t(:,tpathi)-0.10));
        [~,p50skill] = min(abs(cdf_skill_dist_t(:,tpathi)-0.50));
        [~,p90skill] = min(abs(cdf_skill_dist_t(:,tpathi)-0.90));
        [~,p99skill] = min(abs(cdf_skill_dist_t(:,tpathi)-0.99));
    
        p50p10_skill_t(tpathi) = theta_grid(p50skill) - theta_grid(p10skill);
        p90p50_skill_t(tpathi) = theta_grid(p90skill) - theta_grid(p50skill);
        p90p10_skill_t(tpathi) = theta_grid(p90skill) - theta_grid(p10skill);
        p99p10_skill_t(tpathi) = theta_grid(p99skill) - theta_grid(p10skill);
        p10skill_t(tpathi)     = theta_grid(p10skill); 
        p50skill_t(tpathi)     = theta_grid(p50skill); 
        p90skill_t(tpathi)     = theta_grid(p90skill); 
        mean_skill_t(tpathi)   = sum(skill_dist_t(:,tpathi).*theta_grid(:));

        cutoff_grid = linspace(0.01,1,100);
        for loop_index = 1:100    
            [~,arg] = min(abs(cdf_skill_dist_t(:,tpathi)-cutoff_grid(loop_index)));
            pctile_skill_t(loop_index,tpathi) = theta_grid(arg);
        end
        temp = pctile_skill_t(88:92,tpathi);
        ave_p88_p92 = sum(temp/size(temp,1),1);
        temp = pctile_skill_t(48:52,tpathi);
        ave_p48_p52 = sum(temp/size(temp,1),1);
        temp = pctile_skill_t(8:12,tpathi);
        ave_p8_p12 = sum(temp/size(temp,1),1);  
        
        ave_p90_p50_skill_t(tpathi) = ave_p88_p92/ave_p48_p52;
        ave_p50_p10_skill_t(tpathi) = ave_p48_p52/ave_p8_p12;
        ave_p90_p10_skill_t(tpathi) = ave_p88_p92/ave_p8_p12;
        ave_p50_skill_t(tpathi) = ave_p48_p52;
        ave_p10_skill_t(tpathi) = ave_p8_p12;           

        % Inequality measures of adult skill distribution
        std_skill_t(tpathi)        = std(theta_grid(:),skill_dist_t(:,tpathi));
        cv_skill_t(tpathi)         = std_skill_t(tpathi)/mean_skill_t(tpathi);
        var_logskill_t(tpathi)     = var(log(theta_grid(:)),skill_dist_t(:,tpathi));
        [gini_skill_t(tpathi),mu]  = gini(theta_grid(:),skill_dist_t(:,tpathi)./sum(skill_dist_t(:,tpathi)));    
        % =========================================== END POPULATION STATS
        % =========================================== BEGIN COMPUTING CHANGES 
        % Percent change (age correction for weights cancels out of ratio)
        G_spending_change_t(tpathi)   = target_pct_Y_G_t(tpathi)- target_pct_Y_G_t(1);
        ave_tax_rate_change_t(tpathi) = tax_rate_ave_inc_t(tpathi)-tax_rate_ave_inc_t(1);
        
        q_ave_change_t(tpathi)     = 100*(sum(q_ave_t(1,tpathi))/sum(q_ave_t(1,1)) - 1);
        n_ave_change_t(tpathi)     = 100*(sum(n_ave_t(1,tpathi))/sum(n_ave_t(1,1)) - 1);
        skill_ave_change_t(tpathi) = 100*(sum(skill_ave_t(1,tpathi))/sum(skill_ave_t(1,1)) - 1);
        h_ave_change_t(tpathi)     = 100*(sum(h_ave_t(1:j_r-1,tpathi))/sum(h_ave_t(1:j_r-1,1)) - 1);
        GDP_change_t(tpathi)       = 100*(GDP_t_vec(tpathi)/GDP_t_vec(1) - 1);
        c_ave_change_t(tpathi)     = 100*(sum(c_ave_t(:,tpathi))/sum(c_ave_t(:,1)) - 1);
        
        par_p50p10_change_t(tpathi) = par_p50p10_t(tpathi) - par_p50p10_t(1);
        var_skill_change_t(tpathi)  = var_skill_t(tpathi) - var_skill_t(1);
        var_ypop_change_t(tpathi)   = var_y_workingpop_t(tpathi) - var_y_workingpop_t(1);
        rho_thetay_change_t(tpathi) = rho_thetay_t(tpathi) - rho_thetay_t(1);
        rho_rry_change_t(tpathi)    = rho_rry_t(tpathi) - rho_rry_t(1);

        ave_p50_p10_skill_change_t(tpathi) = ave_p50_p10_skill_t(tpathi)-ave_p50_p10_skill_t(1);
        ave_p90_p10_skill_change_t(tpathi) = ave_p90_p10_skill_t(tpathi)-ave_p90_p10_skill_t(1);
        ave_p90_p50_skill_change_t(tpathi) = ave_p90_p50_skill_t(tpathi)-ave_p90_p50_skill_t(1);
        meanskill_change_t(tpathi) = mean_skill_t(tpathi) - mean_skill_t(1);
        ave_p50_skill_change_t(tpathi) = ave_p50_skill_t(tpathi) - ave_p50_skill_t(1);
        var_logskill_change_t(tpathi) =  var_logskill_t(tpathi) - var_logskill_t(1);
        gini_skill_change_t(tpathi) = gini_skill_t(tpathi) - gini_skill_t(1);
        cv_skill_change_t(tpathi) = cv_skill_t(tpathi) - cv_skill_t(1);
        cv_y_workingpop_change_t(tpathi) = cv_y_workingpop_t(tpathi) - cv_y_workingpop_t(tpathi); 
        % =========================================== END COMPUTING CHANGES
        % =========================================== BEGIN ARRAY OF MAIN RESULTS
        % Table of quantity changes needs to have:
        % Panel A: Pctg point change in (tax rate, spending overall by components by % GDP)
        % Panel B: Pct change in (Q,N,Average skill,H,Output,Consumption)
        % Panel C: Inequality and intergenerational mobility changes
        % Panel D: Welfare changes
        if tpathi~=1  && tpathi~=T_tp
            Array_policy_t(1,tpathi) = G_spending_change_t(tpathi); % Government spending
            Array_policy_t(2,tpathi) = ave_tax_rate_change_t(tpathi); % ave tax rate at average income of working-age adult in baseline economy
            Array_policy_t(3,tpathi) = q_ave_change_t(tpathi); % Q ave parents age 1
            Array_policy_t(4,tpathi) = n_ave_change_t(tpathi); % N ave parents age 1
            Array_policy_t(5,tpathi) = skill_ave_change_t(tpathi); % Adult skill ave
            Array_policy_t(6,tpathi) = h_ave_change_t(tpathi); % H ave working-age adults
            Array_policy_t(7,tpathi) = GDP_change_t(tpathi); % GDP 
            Array_policy_t(8,tpathi) = c_ave_change_t(tpathi); % C ave
            Array_policy_t(9,tpathi)  = par_p50p10_change_t(tpathi); % Change in inequality among parents
            Array_policy_t(10,tpathi) = ave_p90_p10_skill_change_t(tpathi);  
            Array_policy_t(11,tpathi) = ave_p90_p50_skill_change_t(tpathi);   
            Array_policy_t(12,tpathi) = ave_p50_p10_skill_change_t(tpathi);   
            Array_policy_t(13,tpathi) = meanskill_change_t(tpathi); 
            Array_policy_t(14,tpathi) = ave_p50_skill_change_t(tpathi);  % new adults skill median 
            Array_policy_t(15,tpathi) = var_logskill_change_t(tpathi); % Change in var log skill new adults 
            Array_policy_t(16,tpathi) = gini_skill_change_t(tpathi); % Change in gini skill new adults 
            Array_policy_t(17,tpathi) = cv_skill_change_t(tpathi);  % change in cv skill new adults 
            Array_policy_t(18,tpathi) = cv_y_workingpop_change_t(tpathi);  % change in coefficient of variation income population 
            Array_policy_t(19,tpathi) = rho_thetay_change_t(tpathi); % Change in rho_thetay 
            Array_policy_t(20,tpathi) = rho_rry_change_t(tpathi); % Change in rho_rry  
            Array_policy_t(21,tpathi) = W_change_bvi_ave_t(1,tpathi); % Welfare change newborns
            Array_policy_t(22,tpathi) = W_change_adults_ave_t(1,tpathi); % Welfare change new adults
            Array_policy_t(23,tpathi) = sum(W_change_adults_ave_t(:,tpathi)/J); % Welfare change adults alive 
            Array_policy_t(24,tpathi) = Share_gain_newborns_t(tpathi);  
            Array_policy_t(25,tpathi) = Share_lose_newborns_t(tpathi); 
            Array_policy_t(26,tpathi) = Share_indiff_newborns_t(tpathi);
            Array_policy_t(27,tpathi) = Share_gain_adults_t(1,tpathi);  
            Array_policy_t(25,tpathi) = Share_lose_adults_t(1,tpathi); 
            Array_policy_t(28,tpathi) = Share_indiff_adults_t(1,tpathi);
            Array_policy_t(29,tpathi) = sum(Share_gain_adults_t(:,tpathi)/J); 
            Array_policy_t(30,tpathi) = sum(Share_lose_adults_t(:,tpathi)/J); 
            Array_policy_t(31,tpathi) = sum(Share_indiff_adults_t(:,tpathi)/J); 
            Array_policy_t(32,tpathi) = 0;
            Array_policy_t(33,tpathi) = 1; 
            Array_policy_t(34,tpathi) = Final_SS_index; % TP End index 
        elseif tpathi==T_tp 
            Array_policy_t(1,tpathi) = G_spending_change_t(tpathi); % Government spending
            Array_policy_t(2,tpathi) = ave_tax_rate_change_t(tpathi); % ave tax rate at average income of working-age adult in baseline economy
            Array_policy_t(3,tpathi) = q_ave_change_t(tpathi); % Q ave parents age 1
            Array_policy_t(4,tpathi) = n_ave_change_t(tpathi); % N ave parents age 1
            Array_policy_t(5,tpathi) = skill_ave_change_t(tpathi); % Adult skill ave
            Array_policy_t(6,tpathi) = h_ave_change_t(tpathi); % H ave working-age adults
            Array_policy_t(7,tpathi) = GDP_change_t(tpathi); % GDP 
            Array_policy_t(8,tpathi) = c_ave_change_t(tpathi); % C ave
            Array_policy_t(9,tpathi)  = par_p50p10_change_t(tpathi); % Change in inequality among parents
            Array_policy_t(10,tpathi) = ave_p90_p10_skill_change_t(tpathi);  
            Array_policy_t(11,tpathi) = ave_p90_p50_skill_change_t(tpathi);   
            Array_policy_t(12,tpathi) = ave_p50_p10_skill_change_t(tpathi);   
            Array_policy_t(13,tpathi) = meanskill_change_t(tpathi); 
            Array_policy_t(14,tpathi) = ave_p50_skill_change_t(tpathi);  % new adults skill median 
            Array_policy_t(15,tpathi) = var_logskill_change_t(tpathi); % Change in var log skill new adults 
            Array_policy_t(16,tpathi) = gini_skill_change_t(tpathi); % Change in gini skill new adults 
            Array_policy_t(17,tpathi) = cv_skill_change_t(tpathi);  % change in cv skill new adults 
            Array_policy_t(18,tpathi) = cv_y_workingpop_change_t(tpathi);  % change in coefficient of variation income population 
            Array_policy_t(19,tpathi) = rho_thetay_change_t(tpathi); % Change in rho_thetay 
            Array_policy_t(20,tpathi) = rho_rry_change_t(tpathi); % Change in rho_rry  
            Array_policy_t(21,tpathi) = W_change_bvi_ave_t(1,tpathi); % Welfare change newborns
            Array_policy_t(22,tpathi) = W_change_adults_ave_t(1,tpathi); % Welfare change new adults
            Array_policy_t(23,tpathi) = sum(W_change_adults_ave_t(:,tpathi)/J); % Welfare change adults alive 
            Array_policy_t(24,tpathi) = Share_gain_newborns_t(tpathi);  
            Array_policy_t(25,tpathi) = Share_lose_newborns_t(tpathi); 
            Array_policy_t(26,tpathi) = Share_indiff_newborns_t(tpathi);
            Array_policy_t(27,tpathi) = Share_gain_adults_t(1,tpathi);  
            Array_policy_t(25,tpathi) = Share_lose_adults_t(1,tpathi); 
            Array_policy_t(28,tpathi) = Share_indiff_adults_t(1,tpathi);
            Array_policy_t(29,tpathi) = sum(Share_gain_adults_t(:,tpathi)/J); 
            Array_policy_t(30,tpathi) = sum(Share_lose_adults_t(:,tpathi)/J); 
            Array_policy_t(31,tpathi) = sum(Share_indiff_adults_t(:,tpathi)/J); 
            Array_policy_t(32,tpathi) = 0;
            Array_policy_t(33,tpathi) = 1; 
            Array_policy_t(34,tpathi) = Final_SS_index; % TP End index 
        else
            Array_policy_t(1,tpathi) = target_pct_Y_G_t(1); % Government spending
            Array_policy_t(2,tpathi) = tax_rate_ave_inc_t(1); % ave tax rate at average income of working-age adult in baseline economy
            Array_policy_t(3,tpathi) = q_ave_t(1); % Q ave parents age 1
            Array_policy_t(4,tpathi) = n_ave_t(1); % N ave parents age 1
            Array_policy_t(5,tpathi) = skill_ave_t(1); % Adult skill ave
            Array_policy_t(6,tpathi) = h_ave_t(1); % H ave working-age adults
            Array_policy_t(7,tpathi) = GDP_t_vec(1); % GDP 
            Array_policy_t(8,tpathi) = c_ave_t(1); % C ave
            Array_policy_t(9,tpathi)  = par_p50p10_t(tpathi); % Change in inequality among parents
            Array_policy_t(10,tpathi) = ave_p90_p10_skill_t(tpathi);  
            Array_policy_t(11,tpathi) = ave_p90_p50_skill_t(tpathi);   
            Array_policy_t(12,tpathi) = ave_p50_p10_skill_t(tpathi);   
            Array_policy_t(13,tpathi) = mean_skill_t(tpathi); 
            Array_policy_t(14,tpathi) = ave_p50_skill_t(tpathi);  % new adults skill median 
            Array_policy_t(15,tpathi) = var_logskill_t(tpathi); % Var log skill new adults 
            Array_policy_t(16,tpathi) = gini_skill_t(tpathi); % Gini skill new adults 
            Array_policy_t(17,tpathi) = cv_skill_t(tpathi);  % cv skill new adults 
            Array_policy_t(18,tpathi) = cv_y_workingpop_t(tpathi);  % Coefficient of variation income population 
            Array_policy_t(19,tpathi) = rho_thetay_t(tpathi); % rho_thetay 
            Array_policy_t(20,tpathi) = rho_rry_t(tpathi); % rho_rry  
            Array_policy_t(21:32,tpathi) = 0;
            Array_policy_t(33,tpathi) = 1; % TP Start index
            Array_policy_t(34,tpathi) = Final_SS_index; % TP End index
        end
        % =========================================== END ARRAY OF MAIN RESULTS
    end % end transition path period loop 
    % Save output array: 
    save_filename = [online_appendix_path 'Raw_output_online_appendix\Array_policy_t_' num2str(Start_SS_index) '_to_' num2str(Final_SS_index) '.mat']; save(save_filename,'Array_policy_t'); % Just the printing array
    % Delete raw output to save space:
    delete(transition_path_output_filename);
    % XXXX delete later?
    % save_filename = [online_appendix_path 'Processed_output_online_appendix\Workspace_Policy_transitions_' num2str(Start_SS_index) '_to_' num2str(Final_SS_index) '.mat']; save(save_filename); % The entire workspace
    % Print info on how long it took to do this exercise's transition path
    toc(TSTART)
    clearvars -except transition_path_output_filename online_appendix_path main_manuscript_path data_path; close all; % keep paths and filename
    disp(datetime); 
    disp('===============================');
end % End loop over final steady-state

% Building and saving combined arrays across exercises - GE with PE decompositions
clearvars -except online_appendix_path; close all; 
list_exercises = [2 3] ;  
ALL_array_policy_t = [];
for loop_iter =  1:size(list_exercises,2)
    
    Final_SS_index = list_exercises(loop_iter);
    disp('Begin'); disp(Final_SS_index);
    % Load exercise TP and update combined array
    loop_array_filename = [online_appendix_path 'Raw_output_online_appendix\Array_policy_t_' num2str(1) '_to_' num2str(Final_SS_index) '.mat']; 
    load(loop_array_filename);
    ALL_array_policy_t(:,:,loop_iter) = Array_policy_t;
    % Delete exercise array to save space
    delete(loop_array_filename); 
    clearvars -except ALL_array_policy_t online_appendix_path list_exercises

end
combined_array_filename = [online_appendix_path 'Processed_output_online_appendix\Combined_array_tp_C3_6.mat']; save(combined_array_filename,'ALL_array_policy_t'); 
save(combined_array_filename,'ALL_array_policy_t'); 

