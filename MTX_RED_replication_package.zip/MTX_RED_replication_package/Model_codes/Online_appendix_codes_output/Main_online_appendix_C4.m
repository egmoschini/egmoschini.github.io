% ================================================================================================================================ %
% --- SOLVING FOR STEADY-STATE MAIN FILE --- SUPPLEMENTAL EXERCISES FOR APPENDIX C.4 --- % 
% ================================================================================================================================ %
run Parameters_and_Calibration_targets.m 

% ---> Toggles for tasks:  
save_output_flag           = 1;   

% ---> Convergence criteria, parameter output/input settings: 
res_GE_cutoff              = 10^-5;
Cutoff_GE_iteration_count  = 25;

% ---> Policy pars key:  [subsidy_chic, rationing_rate, yp_cutoff, subsidy_b0, subsidy_b1, transfer_proportion1 (nonrefundable), transfer_proportion2 (refundable), refund_threshold, phaseout_threshold] Note: specific values are from CRS reports weighted with pop. fractions from Moschini (2023) or previous calibration results for the relevant experiment index.
% Note: subsidy_b1 is 0.85*reported beta_N,1 value b/c CCDF_policy.m divides by 0.85
% Appendices C.2.1, C.2.2, C.2.3, and C.2.4 
Policy_pars_mat_inputs = [];
Policy_pars_mat_inputs(1,:)  = [0.0 0.16 0.27 0.957 -0.296 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];         % Baseline equilibrium 2015-2017 - dollars are in thousands; 55k per-adult income for 2-parent families which is the same for married filing jointly and single/head of household amount, in per-adult units.
Policy_pars_mat_inputs(2,:)  = [0.0 0.16 0.27 0.957 -0.296 2 1.4 (0.21 + 0.79*0.5)*2.5 (0.21*200 + 0.79*0.5*400)];      % 2017 TCJA expansion CTC 
Policy_pars_mat_inputs(3,:)  = [0.375 0.0 0.27 0.957 -0.296 1 1 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];          % Calibrate: Eliminate CCDF rationing (2nd element) then calibrate fixed cost subsidy to match spending from exercise 2 - > calibrates first element
% Appendix C.4.2 - GE exercises Alternative CCDF expansions (3 vs. 4 and 5)
Policy_pars_mat_inputs(4,:)  = [0.4940 0.16 0.27 0.957 -0.296 1 1 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];        % Calibrate: fixed cost subsidy to match spending from exercise 2 - > calibrates first element
Policy_pars_mat_inputs(5,:)  = [0.0 0.16 1.00 0.9346 0 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];             % Calibrate to match spending in #2  %Policy_pars_mat_inputs(56,:)  = [0.0 0.16 1.00 0.9346 0 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];  % Calibrate to match spending in #2
% Appendix C.4.1 General equilibrium expansions of each policy from baseline
Policy_pars_mat_inputs(6,:)  = [0.1 0.0 0.27 0.957 -0.296 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)]; % CCDF  %Policy_pars_mat_inputs(57,:)  = [0.1 0.0 0.27 0.957 -0.296 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)]; % CCDF
Policy_pars_mat_inputs(7,:)  = [0.2 0.0 0.27 0.957 -0.296 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];         %Policy_pars_mat_inputs(58,:)  = [0.2 0.0 0.27 0.957 -0.296 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];
Policy_pars_mat_inputs(8,:)  = [0.375 0.0 0.27 0.957 -0.296 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];       %Policy_pars_mat_inputs(59,:)  = [0.375 0.0 0.27 0.957 -0.296 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];
Policy_pars_mat_inputs(9,:)  = [1.1 0.0 0.27 0.957 -0.296 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];         %Policy_pars_mat_inputs(60,:)  = [1.1 0.0 0.27 0.957 -0.296 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];
Policy_pars_mat_inputs(10,:) = [2*chi_c_eps_grid(end) 0.0 0.27 0.957 -0.296 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)]; % Policy_pars_mat_inputs(61,:)  = [2*chi_c_eps_grid(end) 0.0 0.27 0.957 -0.296 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];
Policy_pars_mat_inputs(11,:) = [0.0 0.16 0.27 0.957 -0.296 1.2 1.2 (0.21 + 0.79*0.5)*2.5 200];   % CTC                 %Policy_pars_mat_inputs(62,:)  = [0.0 0.16 0.27 0.957 -0.296 1.2 1.2 (0.21 + 0.79*0.5)*2.5 200];   % CTC   
Policy_pars_mat_inputs(12,:) = [0.0 0.16 0.27 0.957 -0.296 1.5 1.5 (0.21 + 0.79*0.5)*2.5 200];   %Policy_pars_mat_inputs(63,:)  = [0.0 0.16 0.27 0.957 -0.296 1.5 1.5 (0.21 + 0.79*0.5)*2.5 200];      
Policy_pars_mat_inputs(13,:) = [0.0 0.16 0.27 0.957 -0.296 2.0 2.0 (0.21 + 0.79*0.5)*2.5 200];   %Policy_pars_mat_inputs(64,:)  = [0.0 0.16 0.27 0.957 -0.296 2.0 2.0 (0.21 + 0.79*0.5)*2.5 200];      
Policy_pars_mat_inputs(14,:) = [0.0 0.16 0.27 0.957 -0.296 2.5 2.5 (0.21 + 0.79*0.5)*2.5 200];   %Policy_pars_mat_inputs(65,:)  = [0.0 0.16 0.27 0.957 -0.296 2.5 2.5 (0.21 + 0.79*0.5)*2.5 200];      
Policy_pars_mat_inputs(15,:) = [0.0 0.16 0.27 0.957 -0.296 3.0 3.0 (0.21 + 0.79*0.5)*2.5 200];   %Policy_pars_mat_inputs(66,:)  = [0.0 0.16 0.27 0.957 -0.296 3.0 3.0 (0.21 + 0.79*0.5)*2.5 200];      
Policy_pars_mat_inputs(16,:) = [0.0 0.16 0.27 0.957 -0.296 3.5 3.5 (0.21 + 0.79*0.5)*2.5 200];   %Policy_pars_mat_inputs(67,:)  = [0.0 0.16 0.27 0.957 -0.296 3.5 3.5 (0.21 + 0.79*0.5)*2.5 200];      
Policy_pars_mat_inputs(17,:) = [0.0 0.16 0.27 0.957 -0.296 4.0457 4.0457 (0.21 + 0.79*0.5)*2.5 200]; % calibrate to match spending in 10, all app costs paid by government and rationing eliminated %Policy_pars_mat_inputs(68,:)  = [0.0 0.16 0.27 0.957 -0.296 4.0457 4.0457 (0.21 + 0.79*0.5)*2.5 200];  % calibrate to match spending in 61, all app costs paid by government and rationing eliminated

% --- Policies [EITC_toggle CTC_toggle TANF_toggle CCDF_toggle] 2 is on, 1 is off. 
Policy_toggle_mat      = 2*ones(size(Policy_pars_mat_inputs,1),4); 

% --- General Equilibrium Objects that Adjust GE_toggle_mat key: 1 ==> [skill_dist adjusts, Vkid adjusts, lambda_y adjusts, pn adjusts, yp50_policy_scaling adjusts, pension_lvl adjusts]  
GE_toggle_mat = ones(size(Policy_pars_mat_inputs,1),6); % GE is default
 
% Index of GE objects for PE decompositions
PE_decomp_reference_mat = zeros(size(Policy_pars_mat_inputs,1),1); 

% Arrays of inputs for calibration targets and parameter values  
Calib_targets_mat   = repmat(DataMoment_values_benchmark(:,1),[1 size(Policy_toggle_mat,1)]);
Calib_parvalues_mat = repmat(Parameter_values_benchmark(:,1),[1 size(Policy_toggle_mat,1)]);

% Flag loops that are calibration loops; it may be that the code set has more than one.
Calibration_loop_flag_mat = zeros(1,size(Policy_toggle_mat,1));
Calibration_loop_flag_mat(1) = 1;

%  ---> For speed - initializing policy loop output (see Descriptive_Statistics_Equilibrium.m for computation of contents): 
V1_policy_mat            = zeros(n_types,size(Policy_toggle_mat,1));
Vkid_policy_mat          = zeros(n_theta,size(Policy_toggle_mat,1));
GE_objects_policy_mat    = zeros(6,size(Policy_toggle_mat,1));
GE_quantities_policy_mat = zeros(5,size(Policy_toggle_mat,1));
Exp_G_policy_mat         = zeros(3,size(Policy_toggle_mat,1));
Recipients_G_policy_mat  = zeros(2,size(Policy_toggle_mat,1));
Welfare_change_theta     = zeros(n_types,size(Policy_toggle_mat,1));
Welfare_change_pct       = zeros(1,size(Policy_toggle_mat,1));
skill_dist_policy_mat    = zeros(n_theta,size(Policy_toggle_mat,1)); 
Omega_dist_policy_mat    = zeros(n_types,J,size(Policy_toggle_mat,1));
V_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1));
V_opt_realized_policy_mat = zeros(n_types,J,size(Policy_toggle_mat,1));
theta_opt_policy_mat     = zeros(n_types,J,size(Policy_toggle_mat,1)); 
n_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
q_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
h_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
c_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
thetaa_policy_mat        = zeros(n_types,J,size(Policy_toggle_mat,1));
y_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
yd_opt_policy_mat        = zeros(n_types,J,size(Policy_toggle_mat,1)); 
ccdf_app_opt_policy_mat  = zeros(n_types,J,size(Policy_toggle_mat,1)); 
target_pct_Y_G_policy_mat         = zeros(1,size(Policy_toggle_mat,1));  
target_pct_Y_CTC_CCDF_policy_mat  = zeros(1,size(Policy_toggle_mat,1)); 
Policy_pars_mat_outputs           = 0.*Policy_pars_mat_inputs;   
gov_cc_expense_opt_policy_mat     = zeros(n_types,J,size(Policy_toggle_mat,1)); 
tax_credits_transf_opt_policy_mat = zeros(n_types,J,size(Policy_toggle_mat,1)); 
taxes_paid_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1));   
ave_fc_pct_yp50_policy_mat        = zeros(1,size(Policy_toggle_mat,1));
res_vec_policy_mat                = zeros(3,size(Policy_toggle_mat,1)); 
value_policy_equiv_par_policy_mat = zeros(1,size(Policy_toggle_mat,1));  
res_policy_equiv_policy_mat       = zeros(1,size(Policy_toggle_mat,1));

%  ---> Initialize Iteration indeces and residuals that do not change or get updated sometimes, but get printed
calibration_iter_count = 1; 
policy_iter_count      = 1; 
res_policy_equiv       = 0; 
value_policy_equiv_par = 0; 

%  ---> Begin loop
tstart_main_code = tic; 

for Policy_vec_index =  1:size(Policy_toggle_mat,1)
    
    tstart_policyloop = tic; diary on; disp(['BEGIN POLICY INDEX #: ' num2str(Policy_vec_index)]); disp('Date and time began loop: '); disp(datetime);  diary off;

    % Open calibration targets for this Policy vector loop
    Laborsupply_target      = Calib_targets_mat(1,Policy_vec_index);
    N_hours_target          = Calib_targets_mat(2,Policy_vec_index);
    Corrincskill_target     = Calib_targets_mat(3,Policy_vec_index);
    CCDF_receipt_target     = Calib_targets_mat(4,Policy_vec_index);
    GRIDparp50p10_target    = Calib_targets_mat(5,Policy_vec_index);
    Corrinitialskill_target = Calib_targets_mat(6,Policy_vec_index);
    SS_spending_percentageY = Calib_targets_mat(7,Policy_vec_index);
    pn_ratio_observed       = Calib_targets_mat(8,Policy_vec_index);
    % Open parameter initialization for this Policy vector loop
    psi               = Calib_parvalues_mat(1,Policy_vec_index); 
    lambda_I          = Calib_parvalues_mat(2,Policy_vec_index); 
    b                 = Calib_parvalues_mat(3,Policy_vec_index); 
    chi_c_fraction    = Calib_parvalues_mat(4,Policy_vec_index); 
    varlogthetak      = Calib_parvalues_mat(5,Policy_vec_index); 
    initial_corr_par  = Calib_parvalues_mat(6,Policy_vec_index); 
    pension_rep_rate  = Calib_parvalues_mat(7,Policy_vec_index);     

    diary on;
    disp('CALIBRATION TARGETS:');
    disp(['      H   ','      N   ','  Corr(Θ,y) ','  CCDF   ','   Ineq   ','Corr(Θa,Θk)   ','SS   ']);
    disp(round(Calib_targets_mat(:,Policy_vec_index),4)');
    disp('PARAMETERIZATION INITIALIZATION:');
    disp(['      ψ   ','      λ_I   ','  χ_c/yp50   ',' b/β   ','   β_ρ   ','var(log(Θk))   ','φ_SS   ']);
    disp(round([psi lambda_I chi_c_fraction b/beta initial_corr_par varlogthetak pension_rep_rate],4));
    diary off;
    
    % Policy attributes - initialize policy loop:
    Policy_toggle_vec = Policy_toggle_mat(Policy_vec_index,:); %   
    EITC_toggle = Policy_toggle_vec(1); 
    CTC_toggle  = Policy_toggle_vec(2); 
    TANF_toggle = Policy_toggle_vec(3); 
    CCDF_toggle = Policy_toggle_vec(4);  

    subsidy_chic            = Policy_pars_mat_inputs(Policy_vec_index,1);  
    rationing_rate          = Policy_pars_mat_inputs(Policy_vec_index,2);  
    yp_cutoff               = Policy_pars_mat_inputs(Policy_vec_index,3); 
    subsidy_b0              = Policy_pars_mat_inputs(Policy_vec_index,4); 
    subsidy_b1              = Policy_pars_mat_inputs(Policy_vec_index,5); 
    transfer_proportion1    = Policy_pars_mat_inputs(Policy_vec_index,6); 
    transfer_proportion2    = Policy_pars_mat_inputs(Policy_vec_index,7); 
    refund_threshold        = Policy_pars_mat_inputs(Policy_vec_index,8); 
    phaseout_threshold      = Policy_pars_mat_inputs(Policy_vec_index,9);  

    if Policy_vec_index ==1 
            tstart_EquLoop = tic;  run Solving_Equilibrium.m;  
            run Descriptive_Statistics_Equilibrium.m
    else 
        if ismember(Policy_vec_index,[3,4,5,17])==0  % Exercises that DO NOT calibrate policy parameters
            tstart_EquLoop = tic;  run Solving_Equilibrium.m;  
            run Descriptive_Statistics_Equilibrium.m
        else  % Exercises that DO calibrate policy parameters to hit spending level    
            tstart_EquLoop = tic;  run Solving_Equilibrium.m;  
            run Descriptive_Statistics_Equilibrium.m
            % If targets specific spending level, report spending in this
            % loop and in target:             
            if ismember(Policy_vec_index,[3,4,5])   
                target_index = 2; % 2018 CTC expansion 
            elseif ismember(Policy_vec_index,17)    
                target_index = 10; % eliminating CCDF rationing and full app cost subsidy  
            end
            target_pct_Y_G_iter = target_pct_Y_G_policy_mat(target_index); % Govt spending target 
            pct_realized     = target_pct_Y_G_policy_mat(Policy_vec_index);        
            res_policy_equiv = abs(pct_realized - target_pct_Y_G_iter);
            diary on; disp('Equiv. spending calibration: update --> '); disp(['Share of output and input pars: ' num2str([pct_realized, res_policy_equiv, subsidy_chic, rationing_rate, yp_cutoff, subsidy_b0,subsidy_b1, transfer_proportion1, transfer_proportion2, refund_threshold, phaseout_threshold], '%0.4f ,')]); diary off;
        end % end conditional on policy index  

    end % end calibration conditional 
    Policy_pars_mat_outputs(Policy_vec_index,:) = [subsidy_chic, rationing_rate, yp_cutoff, subsidy_b0,subsidy_b1, transfer_proportion1, transfer_proportion2, refund_threshold, phaseout_threshold];

end % end policy loop

%  ---> Output results
if save_output_flag == 1
    output_filename = 'Raw_output_online_appendix/Output_appendix_C4.mat';
    save(output_filename);  
end
diary on; disp(['Time in seconds for this main file = ' num2str(toc(tstart_main_code))] ); diary off;  
disp(['MOSCHINI AND TRAN-XUAN (2025) SUPPLEMENTAL EXERCISE CODE COMPLETED. SEE DIARY FILE: ' get(0,'DiaryFile')]);

 