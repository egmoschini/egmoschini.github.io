% ================================================================================================================================ %
% --- SOLVING FOR STEADY-STATE MAIN FILE --- SUPPLEMENTAL EXERCISES FOR APPENDIX C.2 and C.3 (except TP) --- % 
% ================================================================================================================================ %
run Parameters_and_Calibration_targets.m 

% ---> Toggles for tasks:  
save_output_flag           = 1;   

% ---> Convergence criteria, parameter output/input settings: 
res_GE_cutoff              = 10^-5;
Cutoff_GE_iteration_count  = 25;

% ---> Policy pars key:  [subsidy_chic, rationing_rate, yp_cutoff, subsidy_b0, subsidy_b1, transfer_proportion1 (nonrefundable), transfer_proportion2 (refundable), refund_threshold, phaseout_threshold] Note: specific values are from CRS reports weighted with pop. fractions from Moschini (2023) or previous calibration results for the relevant experiment index.
% Note: subsidy_b1 is 0.85*reported beta_N,1 value b/c CCDF_policy.m divides by 0.85
% Appendices C.2.1, C.2.2, C.2.3, and C.2.4 
Policy_pars_mat_inputs = [];
Policy_pars_mat_inputs(1,:)  = [0.0 0.16 0.27 0.957 -0.296 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];         % Baseline equilibrium 2015-2017 - dollars are in thousands; 55k per-adult income for 2-parent families which is the same for married filing jointly and single/head of household amount, in per-adult units.
Policy_pars_mat_inputs(2,:)  = [0.0 0.16 0.27 0.957 -0.296 2 1.4 (0.21 + 0.79*0.5)*2.5 (0.21*200 + 0.79*0.5*400)];      % 2017 TCJA expansion CTC 
Policy_pars_mat_inputs(3,:)  = [0.375 0.0 0.27 0.957 -0.296 1 1 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];          % Calibrate: Eliminate CCDF rationing (2nd element) then calibrate fixed cost subsidy to match spending from exercise 2 - > calibrates first element
Policy_pars_mat_inputs(4,:)  = [0.375 0.0 0.999 0.957 0 1 1.0 (0.21 + 0.79*0.5)*3   (0.21*75  + 0.79*0.5*110)];         % marginally eliminating means-testing, goes with exercises 2 and 3, from Main_background_CCDF_no_means_testing.m
% Appendix C.3.3 Motivation for choice of CCDF policy margins
Policy_pars_mat_inputs(5,:)  = [0.0 0.0 0.27 0.957 -0.296 1 1 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];            % Eliminate rationing for CCDF
Policy_pars_mat_inputs(6,:)  = [0.0 0.16 0.27 0.9456 0.000 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];         % Calibrate: set beta0 to match spending (Eliminate CCDF rationing) in 5        
Policy_pars_mat_inputs(7,:)  = [0.0 0.16 0.27 0.957 -0.0461 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];        % Calibrate: set beta1 to match spending (Eliminate CCDF rationing) in 5             
Policy_pars_mat_inputs(8,:)  = [0.0 0.16 0.999 0.957 -0.296 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];        % Demonstrate that only maximizing CCDF eligibility does little to change spending absent other changes  
% Appendix C.3.2 Partial equilibrium decompositions of main exercise expansions policy  margins
Policy_pars_mat_inputs(9,:) = [0.0 0.16 0.27 0.957 -0.296 2 1.4 (0.21 + 0.79*0.5)*2.5 (0.21*75 + 0.79*0.5*110)];        % 2017 TCJA turning off one margin at a time: phaseout threshold         
Policy_pars_mat_inputs(10,:) = [0.0 0.16 0.27 0.957 -0.296 2 1.4 (0.21 + 0.79*0.5)*3 (0.21*200 + 0.79*0.5*400)];        % 2017 TCJA turning off one margin at a time: phasein threshold            
Policy_pars_mat_inputs(11,:) = [0.0 0.16 0.27 0.957 -0.296 1 1.0 (0.21 + 0.79*0.5)*2.5 (0.21*200 + 0.79*0.5*400)];      % 2017 TCJA turning off one margin at a time: credit level pars 
Policy_pars_mat_inputs(12,:) = [0.375 0.16 0.27 0.957 -0.296 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];       % CCDF equivalent turning off one margin at a time: rationing  
Policy_pars_mat_inputs(13,:) = [0.0 0.0 0.27 0.957 -0.296 1 1 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];            % CCDF equivalent turning off one margin at a time: fixed cost subsidy  
% Appendix C.3.5 Partial equilibrium decompositions of main experiment expansions
Policy_pars_mat_inputs(14:20,:) = repmat(Policy_pars_mat_inputs(2,:),[7 1]);    
Policy_pars_mat_inputs(21:27,:) = repmat(Policy_pars_mat_inputs(3,:),[7 1]);    

% --- Policies [EITC_toggle CTC_toggle TANF_toggle CCDF_toggle] 2 is on, 1 is off. 
Policy_toggle_mat      = 2*ones(size(Policy_pars_mat_inputs,1),4); 

% --- General Equilibrium Objects that Adjust GE_toggle_mat key: 1 ==> [skill_dist adjusts, Vkid adjusts, lambda_y adjusts, pn adjusts, yp50_policy_scaling adjusts, pension_lvl adjusts]  
GE_toggle_mat = ones(size(Policy_pars_mat_inputs,1),6); % GE is default

% Partial equilibrium decompositions
GE_toggle_mat(14,:) = [0 0 0 0 0 0]; % Exercise 2: Fully PE
GE_toggle_mat(15,:) = [0 1 1 1 1 1]; % skill_dist fixed baseline
GE_toggle_mat(16,:) = [1 0 1 1 1 1]; % Vkid fixed baseline
GE_toggle_mat(17,:) = [1 1 0 1 1 1]; % lambda_y fixed baseline
GE_toggle_mat(18,:) = [1 1 1 0 1 1]; % pn fixed baseline
GE_toggle_mat(19,:) = [1 1 1 1 0 1]; % yp50_policy_scaling fixed baseline
GE_toggle_mat(20,:) = [1 1 1 1 1 0]; % pension_lvl fixed baseline
GE_toggle_mat(21,:) = [0 0 0 0 0 0]; % Exercise 3: Fully PE
GE_toggle_mat(22,:) = [0 1 1 1 1 1]; % skill_dist fixed baseline
GE_toggle_mat(23,:) = [1 0 1 1 1 1]; % Vkid fixed baseline
GE_toggle_mat(24,:) = [1 1 0 1 1 1]; % lambda_y fixed baseline
GE_toggle_mat(25,:) = [1 1 1 0 1 1]; % pn fixed baseline
GE_toggle_mat(26,:) = [1 1 1 1 0 1]; % yp50_policy_scaling fixed baseline
GE_toggle_mat(27,:) = [1 1 1 1 1 0]; % pension_lvl fixed baseline

% Fully PE, but use new equilibrium not old
GE_toggle_mat(9,:)  = [2 2 2 2 2 2]; % Exercise 2 
GE_toggle_mat(10,:) = [2 2 2 2 2 2]; % Exercise 2 
GE_toggle_mat(11,:) = [2 2 2 2 2 2]; % Exercise 2 
GE_toggle_mat(12,:) = [2 2 2 2 2 2]; % Exercise 3 
GE_toggle_mat(13,:) = [2 2 2 2 2 2]; % Exercise 3 

% Index of GE objects for PE decompositions
PE_decomp_reference_mat = zeros(size(Policy_pars_mat_inputs,1),1); 
PE_decomp_reference_mat(9:11)  = 2; 
PE_decomp_reference_mat(12:13) = 3;
PE_decomp_reference_mat(14:20) = 2;
PE_decomp_reference_mat(21:27) = 3; 

% Arrays of inputs for calibration targets and parameter values  
Calib_targets_mat   = repmat(DataMoment_values_benchmark(:,1),[1 size(Policy_toggle_mat,1)]);
Calib_parvalues_mat = repmat(Parameter_values_benchmark(:,1),[1 size(Policy_toggle_mat,1)]);

% Flag loops that are calibration loops; it may be that the code set has more than one.
Calibration_loop_flag_mat = zeros(1,size(Policy_toggle_mat,1));
Calibration_loop_flag_mat(1) = 1;

%  ---> For speed - initializing policy loop output (see Descriptive_Statistics_Equilibrium.m for computation of contents): 
V1_policy_mat            = zeros(n_types,size(Policy_toggle_mat,1));
Vkid_policy_mat          = zeros(n_theta,size(Policy_toggle_mat,1));
GE_objects_policy_mat    = zeros(6,size(Policy_toggle_mat,1));
GE_quantities_policy_mat = zeros(5,size(Policy_toggle_mat,1));
Exp_G_policy_mat         = zeros(3,size(Policy_toggle_mat,1));
Recipients_G_policy_mat  = zeros(2,size(Policy_toggle_mat,1));
Welfare_change_theta     = zeros(n_types,size(Policy_toggle_mat,1));
Welfare_change_pct       = zeros(1,size(Policy_toggle_mat,1));
skill_dist_policy_mat    = zeros(n_theta,size(Policy_toggle_mat,1)); 
Omega_dist_policy_mat    = zeros(n_types,J,size(Policy_toggle_mat,1));
V_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1));
V_opt_realized_policy_mat = zeros(n_types,J,size(Policy_toggle_mat,1));
theta_opt_policy_mat     = zeros(n_types,J,size(Policy_toggle_mat,1)); 
n_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
q_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
h_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
c_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
thetaa_policy_mat        = zeros(n_types,J,size(Policy_toggle_mat,1));
y_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
yd_opt_policy_mat        = zeros(n_types,J,size(Policy_toggle_mat,1)); 
ccdf_app_opt_policy_mat  = zeros(n_types,J,size(Policy_toggle_mat,1)); 
target_pct_Y_G_policy_mat         = zeros(1,size(Policy_toggle_mat,1));  
target_pct_Y_CTC_CCDF_policy_mat  = zeros(1,size(Policy_toggle_mat,1)); 
Policy_pars_mat_outputs           = 0.*Policy_pars_mat_inputs;   
gov_cc_expense_opt_policy_mat     = zeros(n_types,J,size(Policy_toggle_mat,1)); 
tax_credits_transf_opt_policy_mat = zeros(n_types,J,size(Policy_toggle_mat,1)); 
taxes_paid_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1));   
ave_fc_pct_yp50_policy_mat        = zeros(1,size(Policy_toggle_mat,1));
res_vec_policy_mat                = zeros(3,size(Policy_toggle_mat,1)); 
value_policy_equiv_par_policy_mat = zeros(1,size(Policy_toggle_mat,1));  
res_policy_equiv_policy_mat       = zeros(1,size(Policy_toggle_mat,1));

%  ---> Initialize Iteration indeces and residuals that do not change or get updated sometimes, but get printed
calibration_iter_count = 1; 
policy_iter_count      = 1; 
res_policy_equiv       = 0; 
value_policy_equiv_par = 0; 

%  ---> Begin loop
tstart_main_code = tic; 

for Policy_vec_index =  1:size(Policy_toggle_mat,1)
    
    tstart_policyloop = tic; diary on; disp(['BEGIN POLICY INDEX #: ' num2str(Policy_vec_index)]); disp('Date and time began loop: '); disp(datetime);  diary off;

    % Open calibration targets for this Policy vector loop
    Laborsupply_target      = Calib_targets_mat(1,Policy_vec_index);
    N_hours_target          = Calib_targets_mat(2,Policy_vec_index);
    Corrincskill_target     = Calib_targets_mat(3,Policy_vec_index);
    CCDF_receipt_target     = Calib_targets_mat(4,Policy_vec_index);
    GRIDparp50p10_target    = Calib_targets_mat(5,Policy_vec_index);
    Corrinitialskill_target = Calib_targets_mat(6,Policy_vec_index);
    SS_spending_percentageY = Calib_targets_mat(7,Policy_vec_index);
    pn_ratio_observed       = Calib_targets_mat(8,Policy_vec_index);
    % Open parameter initialization for this Policy vector loop
    psi               = Calib_parvalues_mat(1,Policy_vec_index); 
    lambda_I          = Calib_parvalues_mat(2,Policy_vec_index); 
    b                 = Calib_parvalues_mat(3,Policy_vec_index); 
    chi_c_fraction    = Calib_parvalues_mat(4,Policy_vec_index); 
    varlogthetak      = Calib_parvalues_mat(5,Policy_vec_index); 
    initial_corr_par  = Calib_parvalues_mat(6,Policy_vec_index); 
    pension_rep_rate  = Calib_parvalues_mat(7,Policy_vec_index);     

    diary on;
    disp('CALIBRATION TARGETS:');
    disp(['      H   ','      N   ','  Corr(Θ,y) ','  CCDF   ','   Ineq   ','Corr(Θa,Θk)   ','SS   ']);
    disp(round(Calib_targets_mat(:,Policy_vec_index),4)');
    disp('PARAMETERIZATION INITIALIZATION:');
    disp(['      ψ   ','      λ_I   ','  χ_c/yp50   ',' b/β   ','   β_ρ   ','var(log(Θk))   ','φ_SS   ']);
    disp(round([psi lambda_I chi_c_fraction b/beta initial_corr_par varlogthetak pension_rep_rate],4));
    diary off;
    
    % Policy attributes - initialize policy loop:
    Policy_toggle_vec = Policy_toggle_mat(Policy_vec_index,:); %   
    EITC_toggle = Policy_toggle_vec(1); 
    CTC_toggle  = Policy_toggle_vec(2); 
    TANF_toggle = Policy_toggle_vec(3); 
    CCDF_toggle = Policy_toggle_vec(4);  

    subsidy_chic            = Policy_pars_mat_inputs(Policy_vec_index,1);  
    rationing_rate          = Policy_pars_mat_inputs(Policy_vec_index,2);  
    yp_cutoff               = Policy_pars_mat_inputs(Policy_vec_index,3); 
    subsidy_b0              = Policy_pars_mat_inputs(Policy_vec_index,4); 
    subsidy_b1              = Policy_pars_mat_inputs(Policy_vec_index,5); 
    transfer_proportion1    = Policy_pars_mat_inputs(Policy_vec_index,6); 
    transfer_proportion2    = Policy_pars_mat_inputs(Policy_vec_index,7); 
    refund_threshold        = Policy_pars_mat_inputs(Policy_vec_index,8); 
    phaseout_threshold      = Policy_pars_mat_inputs(Policy_vec_index,9);  

    if Policy_vec_index ==1 
            tstart_EquLoop = tic;  run Solving_Equilibrium.m;  
            run Descriptive_Statistics_Equilibrium.m
    else 
        if ismember(Policy_vec_index,[3,6,7,8])==0  % Exercises that DO NOT calibrate policy parameters
            tstart_EquLoop = tic;  run Solving_Equilibrium.m;  
            run Descriptive_Statistics_Equilibrium.m
        else  % Exercises that DO calibrate policy parameters to hit spending level    
            tstart_EquLoop = tic;  run Solving_Equilibrium.m;  
            run Descriptive_Statistics_Equilibrium.m
            % If targets specific spending level, report spending in this
            % loop and in target:             
            if ismember(Policy_vec_index,3)   
                target_index = 2; % 2018 CTC expansion
            elseif ismember(Policy_vec_index,[6 7 8])    
                target_index = 5; % eliminating CCDF rationing
            end
            target_pct_Y_G_iter = target_pct_Y_G_policy_mat(target_index); % Govt spending target 
            pct_realized     = target_pct_Y_G_policy_mat(Policy_vec_index);        
            res_policy_equiv = abs(pct_realized - target_pct_Y_G_iter);
            diary on; disp('Equiv. spending calibration: update --> '); disp(['Share of output and input pars: ' num2str([pct_realized, res_policy_equiv, subsidy_chic, rationing_rate, yp_cutoff, subsidy_b0,subsidy_b1, transfer_proportion1, transfer_proportion2, refund_threshold, phaseout_threshold], '%0.4f ,')]); diary off;
        end % end conditional on policy index  

    end % end calibration conditional 
    Policy_pars_mat_outputs(Policy_vec_index,:) = [subsidy_chic, rationing_rate, yp_cutoff, subsidy_b0,subsidy_b1, transfer_proportion1, transfer_proportion2, refund_threshold, phaseout_threshold];

end % end policy loop
  
%  ---> Output results
if save_output_flag == 1
    output_filename = 'Raw_output_online_appendix/Output_appendix_C2_C3.mat';
    save(output_filename);  
end
diary on; disp(['Time in seconds for this main file = ' num2str(toc(tstart_main_code))] ); diary off; 
disp(['MOSCHINI AND TRAN-XUAN (2025) SUPPLEMENTAL EXERCISE CODE COMPLETED. SEE DIARY FILE: ' get(0,'DiaryFile')]);

 