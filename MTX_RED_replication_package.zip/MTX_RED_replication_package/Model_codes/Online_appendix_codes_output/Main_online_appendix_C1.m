% ================================================== MAIN MANUSCRIPT EXERCISES/CALIBRATION COMPARATIVE STATICS MAIN FILE ==================================================== %
run Parameters_and_Calibration_targets.m 

% --- Toggles for tasks:     
save_output_flag = 1;   

% --- Convergence criteria, parameter output/input settings: 
res_GE_cutoff              = 10^-5; 
Cutoff_GE_iteration_count  = 25;  

% ---> Policy pars key:  [subsidy_chic, rationing_rate, yp_cutoff, subsidy_b0, subsidy_b1, transfer_proportion1 (nonrefundable), transfer_proportion2 (refundable), refund_threshold, phaseout_threshold] Note: specific values are from CRS reports weighted with pop. fractions from Moschini (2023) or previous calibration results for the relevant experiment index.
% Note: subsidy_b1 is 0.85*reported beta_N,1 value b/c CCDF_policy.m divides by 0.85 
Policy_pars_mat_inputs = [];
Policy_pars_mat_inputs(1,:)  = [0.0  0.16 0.27 0.957 -0.296 1 1 (0.21 + 0.79*0.5)*3   (0.21*75  + 0.79*0.5*110)];          % Baseline equilibrium 2015-2017 - dollars are in thousands; 55k per-adult income for 2-parent families which is the same for married filing jointly and single/head of household amount, in per-adult units.
Policy_pars_mat_inputs(2:15,:) = repmat(Policy_pars_mat_inputs(1,:),[14 1]);

% --- Policies [EITC_toggle CTC_toggle TANF_toggle CCDF_toggle] 2 is on, 1 is off. 
Policy_toggle_mat      = 2*ones(size(Policy_pars_mat_inputs,1),4); 

% --- General Equilibrium Objects that Adjust 
% -- GE_toggle_mat key: 1 ==> [skill_dist adjusts, Vkid adjusts, lambda_y adjusts, pn adjusts, yp50_policy_scaling adjusts, pension_lvl adjusts]  
GE_toggle_mat = ones(size(Policy_pars_mat_inputs,1),6);   % GE is default

% Arrays of inputs for calibration targets and parameter values 
Calib_targets_mat   = repmat(DataMoment_values_benchmark(:,1),[1 size(Policy_toggle_mat,1)]);
% [psi lambda_I b chi_c_fraction varlogthetak initial_corr_par pension_rep_rate]
Calib_parvalues_mat = repmat(Parameter_values_benchmark(:,1),[1 size(Policy_toggle_mat,1)]);

col_index = 2;
for index = 1:7 % index order: [psi lambda_I b chi_c_fraction varlogthetak initial_corr_par pension_rep_rate]
    Calib_parvalues_mat(index,col_index) = 0.80*Calib_parvalues_mat(index,1); col_index = col_index+1;
    Calib_parvalues_mat(index,col_index) = 1.20*Calib_parvalues_mat(index,1); col_index = col_index+1;
end
 
% Matrix linking exercises with baseline equilibrium
Benchmark_index_mat = ones(1,size(Policy_toggle_mat,1));
for index = 1:size(Policy_toggle_mat) 
    Benchmark_index_mat(index) = index;
end   

%  ---> Initializing policy loop output (see Descriptive_Statistics_Equilibrium.m for computation of contents):  
V1_policy_mat            = zeros(n_types,size(Policy_toggle_mat,1));
Vkid_policy_mat          = zeros(n_theta,size(Policy_toggle_mat,1));
GE_objects_policy_mat    = zeros(6,size(Policy_toggle_mat,1));
GE_quantities_policy_mat = zeros(5,size(Policy_toggle_mat,1));
Exp_G_policy_mat         = zeros(3,size(Policy_toggle_mat,1));
Recipients_G_policy_mat  = zeros(2,size(Policy_toggle_mat,1));
Welfare_change_theta     = zeros(n_types,size(Policy_toggle_mat,1));
Welfare_change_pct       = zeros(1,size(Policy_toggle_mat,1));
skill_dist_policy_mat    = zeros(n_theta,size(Policy_toggle_mat,1)); 
Omega_dist_policy_mat    = zeros(n_types,J,size(Policy_toggle_mat,1));
V_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1));
V_opt_realized_policy_mat = zeros(n_types,J,size(Policy_toggle_mat,1));
theta_opt_policy_mat     = zeros(n_types,J,size(Policy_toggle_mat,1)); 
n_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
q_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
h_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
c_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
thetaa_policy_mat        = zeros(n_types,J,size(Policy_toggle_mat,1));
y_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
yd_opt_policy_mat        = zeros(n_types,J,size(Policy_toggle_mat,1)); 
ccdf_app_opt_policy_mat  = zeros(n_types,J,size(Policy_toggle_mat,1)); 
target_pct_Y_G_policy_mat         = zeros(1,size(Policy_toggle_mat,1));  
target_pct_Y_CTC_CCDF_policy_mat  = zeros(1,size(Policy_toggle_mat,1)); 
Policy_pars_mat_outputs           = 0.*Policy_pars_mat_inputs;   
gov_cc_expense_opt_policy_mat     = zeros(n_types,J,size(Policy_toggle_mat,1)); 
tax_credits_transf_opt_policy_mat = zeros(n_types,J,size(Policy_toggle_mat,1)); 
taxes_paid_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1));   
ave_fc_pct_yp50_policy_mat        = zeros(1,size(Policy_toggle_mat,1));
res_vec_policy_mat                = zeros(3,size(Policy_toggle_mat,1)); 
value_policy_equiv_par_policy_mat = zeros(1,size(Policy_toggle_mat,1));  
res_policy_equiv_policy_mat       = zeros(1,size(Policy_toggle_mat,1));

DataMoment_values_policy_mat  = zeros(9,size(Policy_toggle_mat,1));
ModelMoment_values_policy_mat = zeros(9,size(Policy_toggle_mat,1));
Parameter_values_policy_mat   = zeros(10,size(Policy_toggle_mat,1));

%  ---> Initialize objects that do not change or get updated sometimes, but get printed 
res_policy_equiv       = 0; 
value_policy_equiv_par = 0; 

%  ---> Begin loop
tstart_main_code = tic; 

for Policy_vec_index = 1:size(Policy_toggle_mat,1)
    
    % ---> INITIALIZATION
    tstart_policyloop = tic; diary on; disp(['BEGIN POLICY INDEX #: ' num2str(Policy_vec_index)]); disp('Date and time began loop: '); disp(datetime);  diary off;
    % Open calibration targets for this Policy vector loop
    Laborsupply_target      = Calib_targets_mat(1,Policy_vec_index);
    N_hours_target          = Calib_targets_mat(2,Policy_vec_index);
    Corrincskill_target     = Calib_targets_mat(3,Policy_vec_index);
    CCDF_receipt_target     = Calib_targets_mat(4,Policy_vec_index);
    GRIDparp50p10_target    = Calib_targets_mat(5,Policy_vec_index);
    Corrinitialskill_target = Calib_targets_mat(6,Policy_vec_index);
    SS_spending_percentageY = Calib_targets_mat(7,Policy_vec_index);
    pn_ratio_observed       = Calib_targets_mat(8,Policy_vec_index);

    % Open parameter initialization for this Policy vector loop
    psi               = Calib_parvalues_mat(1,Policy_vec_index); 
    lambda_I          = Calib_parvalues_mat(2,Policy_vec_index); 
    b                 = Calib_parvalues_mat(3,Policy_vec_index); 
    chi_c_fraction    = Calib_parvalues_mat(4,Policy_vec_index); 
    varlogthetak      = Calib_parvalues_mat(5,Policy_vec_index); 
    initial_corr_par  = Calib_parvalues_mat(6,Policy_vec_index); 
    pension_rep_rate  = Calib_parvalues_mat(7,Policy_vec_index);  

    % Policy attributes - initialize policy loop:
    Policy_toggle_vec = Policy_toggle_mat(Policy_vec_index,:); %   
    EITC_toggle = Policy_toggle_vec(1); 
    CTC_toggle  = Policy_toggle_vec(2); 
    TANF_toggle = Policy_toggle_vec(3); 
    CCDF_toggle = Policy_toggle_vec(4);  

    % Policy input levels: 
    subsidy_chic            = Policy_pars_mat_inputs(Policy_vec_index,1);  
    rationing_rate          = Policy_pars_mat_inputs(Policy_vec_index,2);  
    yp_cutoff               = Policy_pars_mat_inputs(Policy_vec_index,3); 
    subsidy_b0              = Policy_pars_mat_inputs(Policy_vec_index,4); 
    subsidy_b1              = Policy_pars_mat_inputs(Policy_vec_index,5); 
    transfer_proportion1    = Policy_pars_mat_inputs(Policy_vec_index,6); 
    transfer_proportion2    = Policy_pars_mat_inputs(Policy_vec_index,7); 
    refund_threshold        = Policy_pars_mat_inputs(Policy_vec_index,8); 
    phaseout_threshold      = Policy_pars_mat_inputs(Policy_vec_index,9); 

    % Print Calibration target moments and parameters: 
    diary on;
    disp(['COMPARATIVE STATICS REFERENCEING INDEX: ' num2str(Policy_vec_index)]);  
    disp('COMPARATIVE STATICS INPUT PARAMETERS:');  
    disp(['      ψ   ','      λ_I   ','  χ_c/yp50   ',' b/β   ','   β_ρ   ','var(log(Θk))   ','φ_SS   ']);
    disp(round([psi lambda_I chi_c_fraction b/beta initial_corr_par varlogthetak pension_rep_rate],4));
    diary off;  

    % ---> Solving for GE 
    tstart_EquLoop = tic;  
    run Solving_Equilibrium_CompStat.m;  
    run Descriptive_Statistics_Equilibrium.m 
    % Equilibrium policy values:
    Policy_pars_mat_outputs(Policy_vec_index,:) = [subsidy_chic, rationing_rate, yp_cutoff, subsidy_b0,subsidy_b1, transfer_proportion1, transfer_proportion2, refund_threshold, phaseout_threshold];
    
    % ---> Save target moments for comparative statics on parameters: 
    if save_output_flag == 1  
        % --- Updating joint distribution; construct with skill_dist_update if GE
        Omega_dist_PE = zeros(n_types,J);
        parfor type_index = 1:n_types 
            theta_index  = type_mat(type_index,1);
            thetak_index = type_mat(type_index,2); 
            cc_r_index   = type_mat(type_index,3); 
            cc_fc_index  = type_mat(type_index,4);  
            for age = 1:J  
                if cc_r_index == 1 % incorporate application choices into distribution over ccdf application/receipt/no app distribution
                    probccstatus = (ccdf_app_opt(type_index,age) == 1); % did not apply 
                elseif cc_r_index == 2
                    probccstatus = (1-CCDF_policy_mat(6))*(ccdf_app_opt(type_index,age) == 2); % prob. did not receive || applied
                else  
                    probccstatus = CCDF_policy_mat(6)*(ccdf_app_opt(type_index,age) == 2); % prob. did receive || applied  
                end
                probkid    = thetak_dist(theta_index,thetak_index);
                probparent = skill_dist(theta_index);
                probage    = 1/J;
                probfc     = chi_c_eps_dist(cc_fc_index);
                Omega_dist_PE(type_index,age) = probfc*probccstatus*probkid*probparent*probage;
            end
        end 
        par_weights  = Omega_dist_PE(:,1)/sum(Omega_dist_PE(:,1));
        prime_working_age_weights = Omega_dist_PE(:,2:7)./sum(Omega_dist_PE(:,2:7),'all'); % ages 25 - 55 to match CPS and GRID moments
        h_hours      = sum(h_opt(:,2:7).*prime_working_age_weights,'all');  
        n_hours      = sum(n_opt(:,1).*par_weights(:)); 
        q_hours      = sum(q_opt(:,1).*par_weights(:)); 
        qn_ratio     = sum(q_opt(:,1).*par_weights(:)./n_opt(:,1)); 
        [rho_thetay] = weighted_correlation_coeff(y_opt(:,1),theta_opt(:,1),par_weights);
        CCDF_receipt  = sum((gov_cc_expense_opt(:,1)>0).*par_weights);
        CCDF_eligible = sum((CCDF_toggle == 2).*(y_opt(:,1)<=CCDF_policy_mat(1)).*(h_opt(:,1)>0).*par_weights);   
        CCDF_uptake   = CCDF_receipt/CCDF_eligible;
        [rho_initialskill] = weighted_correlation_coeff(theta_grid(type_mat(:,1))',thetak_grid(type_mat(:,2))',par_weights);
        SS_spending  = 100*sum(repmat(pension_lvl,[1 J-j_r+1]).*Omega_dist_PE(:,j_r:J),'all')/GE_objects_policy_mat(1,1);

        % Pretax income inequality stats - to match GRID moments 25-34 
        % Use the next generation labor supply choices
        income_dist      = []; y_temp = []; Omega_dist_temp= [];
        y_temp = y_opt(:,2:3); logy_temp = log(y_temp(:));  
        h_temp = h_opt(:,2:3); 
        wage_temp = wage_dist_levels(:,2:3);
        flag_working_and_in_wagerange = (h_temp(:)>0).*(wage_temp(:)>thetaminthreshold_GRID).*(wage_temp(:)<thetamaxthreshold_GRID); 
        Omega_dist_tempOutput_Recalibration_aux = Omega_dist_PE(:,2:3); Omega_dist_temp_aux = Omega_dist_temp_aux./sum(Omega_dist_temp_aux(:)); Omega_dist_temp = Omega_dist_temp_aux(:);
        income_dist      = [logy_temp((flag_working_and_in_wagerange==1)) Omega_dist_temp((flag_working_and_in_wagerange==1))./sum(Omega_dist_temp((flag_working_and_in_wagerange==1)))];
        income_dist      = sortrows(income_dist,1);
        income_dist(:,3) = cumsum(income_dist(:,2));
        [~,p50yarg]      = min(abs(income_dist(:,end)-0.5));
        [~,p10yarg]      = min(abs(income_dist(:,end)-0.1));
        p50_yparGRID            = income_dist(p50yarg,1);
        p10_yparGRID            = income_dist(p10yarg,1);

        DataMoment_values_policy_mat(:,Policy_vec_index)  = [Laborsupply_target N_hours_target Corrincskill_target CCDF_receipt_target GRIDparp50p10_target Corrinitialskill_target SS_spending_percentageY 0.000 pn_ratio_observed]';
        ModelMoment_values_policy_mat(:,Policy_vec_index) = [h_hours n_hours rho_thetay CCDF_receipt p50_yparGRID - p10_yparGRID rho_initialskill 0.01*SS_spending 0.000 pn/(sum(par_weights(:).*wage_aftx(:))/sum(par_weights(:).*(1-subsidy_correction(:))))]';
        Parameter_values_policy_mat(:,Policy_vec_index)   = [psi lambda_I b/beta chi_c_fraction varlogthetak initial_corr_par pension_rep_rate thetan chi_c pn_ratio_adjusted]';
        
        ModelMoment_values_iter = ModelMoment_values_policy_mat(:,Policy_vec_index);
        DataMoment_values_iter  = DataMoment_values_policy_mat(:,Policy_vec_index);
        disp('CALIBRATION TARGETS AND MODEL MOMENTS:');
        disp(['      H   ','      N   ','  Corr(Θ,y) ','  CCDF   ','   Ineq   ','Corr(Θa,Θk)   ','SS   ']);
        disp(round(Calib_targets_mat(:,Policy_vec_index),4)');
        disp(round(ModelMoment_values_iter(:)',4));
        disp('CURRENT PARAMETERIZATION:');
        disp(['      ψ   ','      λ_I   ','  χ_c/yp50   ',' b/β   ','   β_ρ   ','var(log(Θk))   ','φ_SS   ']);
        disp(round([psi lambda_I chi_c_fraction b/beta initial_corr_par varlogthetak pension_rep_rate],4));
        diary off;
        disp(['Saving calibrated parameters for index #: ' num2str(Policy_vec_index)]); 
        output_filename = [online_appendix_path 'Raw_output_online_appendix\Output_appendix_C1' num2str(Policy_vec_index) '.mat'];     
        save(output_filename,'psi','lambda_I','b','chi_c','chi_c_fraction','initial_corr_par','varlogthetak','pension_rep_rate','DataMoment_values_iter','ModelMoment_values_iter');  
    end
end % end policy loop

%  ---> Output results are saved in each loop
diary on; disp(['Time in seconds for this main file = ' num2str(toc(tstart_main_code))] ); diary off;
disp(['CODE COMPLETED. See diary file: ' get(0,'DiaryFile')]);
  