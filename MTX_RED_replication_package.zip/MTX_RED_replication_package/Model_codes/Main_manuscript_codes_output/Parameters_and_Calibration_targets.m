%% ================= BEGIN FIXED PARAMETERS ====================== %  

% --- Preferences and lifecycle parameters and production technology assumption: 
beta   = 0.96^5; 
Frisch = 1.5; % Constant Frisch elasticity parameter, midpoint of macro range overviewed by Keane and Rogerson (2015) "Reconciling Micro and  Macro Labor Supply Elasticities: A Structural Perspective"
J      = 11;
j_r    = 10; % retirement age. set above J to shut off pension system.
j_a    = 4;
OECD_child = 0.3; % for consumption equivalence scales
w     = 1; % Technology for consumption good: linear in labor efficiency units
chi_u = 0; % initial preference cost of application for childcare subsidy  

% --- G, tax, and pension parameters 
share_pension_taxed = 0.85;  % Up to 85 percent of the benefit may be taxed, from IRS-SSA Publication 915 Cat. No 15320P - citation proportion SS benefit taxed
ThetaG              = 0.175;  % Average 2015-2017 using Table 1.1.10 from NIPAS. Previously (first submission to RED): 0.142 Average 2015-2017 using components of Table 3.1 from NIPA
tau_c               = 0.0433; % Estimated with OECD data 2015-2017 using Mendoza et al (1994) methodology.
tau_y               = 0.061;  % PSID estimate is 0.063; CPS estimate is 0.059-0.065 depending on sample (latest has 0.061 as well). CBO 2016 estimate is 0.054  
ypTANF              = 0;      % TANF income cutoff 

% --- Childcare policy fixed cost dispersion from Guzman 2019 
mean_chi_c_eps_levels_Guzman2019   = 1; % Normalized mean value of application rates/fixed costs from Table D3 Guzman 2019 Appendix
var_chi_c_eps_levels_Guzman2019    = 0.1135; % variance of fixed cost around mean from Table D3 of Guzman 2019 online appendix 

% --- Normalization value in 2016 USD
US_yp50 = 57657; % average of 2015-2017 Median Hh income Guzman 2017 and Guzman 2018 in 2016 dollars used for scaling policies into model magnitudes. Computed in excel file "Size_of_programs.xlsx"

% --- Investment technologies (from moschini 2023 population moments)   
N_hours_data_working = 37.13*0.21 + 33.14*0.79;  
Q_hours_data_working = 11.45*0.21 + 10.48*0.79;  
share_sf = (37.13*0.21/(37.13*0.21 + 33.14*0.79)); % quantity weighted share on SF for averaging using estimation sample quantities
pn_ratio_observed_working = share_sf*2.59/12.24  + (1-share_sf)*4.2/15.07; % for working moms

nu       = 0.21*0.44 + 0.79*0.59;
upsilon  = 0.49;
chi      = 0.38;
aux_data = (1./nu).*log(N_hours_data_working/Q_hours_data_working) + log(pn_ratio_observed_working);
gamma    = 1./(1+exp(aux_data)); % implied share based on other parameters and observed prices/quantities in the population
thetan_initialization = 1; % this determines the initial theta_grid; does not change across calibrations. 

% --- Wage growth: keeps size of programs from being too small. From Lagakos et al (2018)
beta1_wagegrowth = 0.5090316;   
beta2_wagegrowth = -0.0903729; 
beta3_wagegrowth = 0.0053412;   

% --- Skill grid of adults proportions (Θk_grid and Θ_grid's bounds are set within calibration loop)
ub_proportion   = 0.5; % Re-initialize theta_grid; bounds depend on initial skill grid bounds and λ_I and Θn: 
lb_level        = 0.02;

% ================= END FIXED PARAMETERS ====================== %

%% ================= BEGIN GRIDS ====================== %  
n_theta  = 35; n_thetak = 55; n_h = 7; n_childcare = 200; n_ccsub_types = 3; n_bins_ccsub_fc = 9; % making the grid on thetak dense smooths out the final skill distribution so it is more continuous, no sudden dips. 

% Type matrix for loop: 
n_types = n_theta*n_thetak*n_ccsub_types*n_bins_ccsub_fc; % this version has endogenous yes/no CCDF uptake so not in type space.
type_mat = zeros(n_types,4);
type_index = 1;
for i = 1:n_theta
    for j = 1:n_thetak 
        for cc_i = 1:n_ccsub_types
            for cc_j = 1:n_bins_ccsub_fc
                type_mat(type_index,1) = i;
                type_mat(type_index,2) = j;  
                type_mat(type_index,3) = cc_i; 
                type_mat(type_index,4) = cc_j;
                type_index = type_index + 1;
            end
        end
    end
end

% Grid on labor supply 
h_grid          =  linspace(0,0.48,n_h); % 50 is the 90th percntile of hours worked in the CPS linspace(0.0,0.999,n_h);

% --- Densities of grids
density_grid_par_thetaa   = 2;
density_grid_par_thetak   = 2;
density_grid_par_chi_c    = 2;

% --- Skill grid of kids' initial draw proportions - assumptions 
mulogk_continuous = 0;  % assumption about mean of log(Θk)
lb_thetak         = 0.05; %exp(mulogk_continuous-1.96*varlogthetak^0.5); % assumptions about grid bounds
ub_thetak         = 10.05;  %exp(mulogk_continuous+1.96*varlogthetak^0.5); %assumptions about grid bounds

% --- Grid on thetak which is held fixed; grid on theta is updated each calibration loop.
thetak_grid = linspace(lb_thetak^(1/density_grid_par_thetak),ub_thetak^(1/density_grid_par_thetak),n_thetak).^density_grid_par_thetak;

% --- Discretized draws: properties of approximations
flag_lognormal = 1;               % set to 1 for log normal, 0 for normal shock to fixed cost
grid_bound_scaling_factor = 1.96; % # of SDs away from mean that the grid goes 
calibrating_iter_max_temp = 300;  % # of iterations for grid approximation

% Generate log_normal discretized distribution of shock to fixed cost:    
% Given grid density and bounds, pick parameters so that realized mean and
% variance match the data.
if n_bins_ccsub_fc>1     
    if flag_lognormal == 1
        var_sol_logs = 0.2; 
        mean_sol_logs = log(mean_chi_c_eps_levels_Guzman2019) - var_sol_logs/2; % implied mu given guess var and target mean in levels    
        res = ones(1,2); iter = 1;
        while iter <calibrating_iter_max_temp    
            chi_c_eps_grid = linspace(exp(mean_sol_logs-grid_bound_scaling_factor*var_sol_logs^0.5)^(1/density_grid_par_chi_c),(exp(mean_sol_logs+grid_bound_scaling_factor*var_sol_logs^0.5))^(1/density_grid_par_chi_c),n_bins_ccsub_fc).^(density_grid_par_chi_c);
            chi_c_eps_dist = lognpdf(chi_c_eps_grid,mean_sol_logs,var_sol_logs^0.5); 
            chi_c_eps_dist = chi_c_eps_dist./sum(chi_c_eps_dist); 
            res(1) = abs(std(chi_c_eps_grid,10^9*chi_c_eps_dist) - var_chi_c_eps_levels_Guzman2019^0.5);
            res(2) = abs(sum(chi_c_eps_dist.*chi_c_eps_grid) - mean_chi_c_eps_levels_Guzman2019);    
            var_sol_logs  = var_sol_logs*abs(std(chi_c_eps_grid,10^9*chi_c_eps_dist)/var_chi_c_eps_levels_Guzman2019^0.5)^(-0.3);
            mean_sol_logs = mean_sol_logs*abs(sum(chi_c_eps_dist.*chi_c_eps_grid)/mean_chi_c_eps_levels_Guzman2019)^(0.3);    
            iter = iter+1;
        end
        var_chi_c_eps_logs  = var_sol_logs; 
        mean_chi_c_eps_logs = mean_sol_logs;
        chi_c_eps_grid = linspace(exp(mean_chi_c_eps_logs-grid_bound_scaling_factor*var_chi_c_eps_logs^0.5)^(1/density_grid_par_chi_c),(exp(mean_chi_c_eps_logs+grid_bound_scaling_factor*var_chi_c_eps_logs^0.5))^(1/density_grid_par_chi_c),n_bins_ccsub_fc).^(density_grid_par_chi_c);
        chi_c_eps_dist = lognpdf(chi_c_eps_grid,mean_sol_logs,var_sol_logs^0.5); 
        chi_c_eps_dist = chi_c_eps_dist./sum(chi_c_eps_dist); 
    else
        density_grid_par_chi_c    = 1; % even density when using the normal
        var_sol_levels  = var_chi_c_eps_levels_Guzman2019; 
        mean_sol_levels = mean_chi_c_eps_levels_Guzman2019; % implied mu given guess var and target mean in levels    
        res = ones(1,2); iter = 1;
        while iter <calibrating_iter_max_temp    
            chi_c_eps_grid = linspace( (mean_sol_levels-grid_bound_scaling_factor*var_sol_levels^0.5)^(1/density_grid_par_chi_c),( (mean_sol_levels+grid_bound_scaling_factor*var_sol_levels^0.5))^(1/density_grid_par_chi_c),n_bins_ccsub_fc).^(density_grid_par_chi_c);
            chi_c_eps_dist = normpdf(chi_c_eps_grid,mean_sol_levels,var_sol_levels^0.5); 
            chi_c_eps_dist = chi_c_eps_dist./sum(chi_c_eps_dist); 
            res(1) = abs(std(chi_c_eps_grid,10^9*chi_c_eps_dist) -  var_chi_c_eps_levels_Guzman2019^0.5);
            res(2) = abs(sum(chi_c_eps_dist.*chi_c_eps_grid) - mean_chi_c_eps_levels_Guzman2019);    
            var_sol_levels = var_sol_levels*abs(std(chi_c_eps_grid,10^9*chi_c_eps_dist)/var_chi_c_eps_levels_Guzman2019^0.5)^(-0.3);
            mean_sol_levels = mean_sol_levels*abs(sum(chi_c_eps_dist.*chi_c_eps_grid)/mean_chi_c_eps_levels_Guzman2019)^(-0.3);    
            iter = iter+1;
        end
        var_chi_c_eps_levels = var_sol_levels; 
        mean_chi_c_eps_levels = mean_sol_levels;
        chi_c_eps_grid = linspace( (mean_chi_c_eps_levels-grid_bound_scaling_factor*var_chi_c_eps_levels^0.5)^(1/density_grid_par_chi_c),((mean_chi_c_eps_levels+grid_bound_scaling_factor*var_chi_c_eps_levels^0.5))^(1/density_grid_par_chi_c),n_bins_ccsub_fc).^(density_grid_par_chi_c);
        chi_c_eps_cdf  = normpdf(chi_c_eps_grid,mean_chi_c_eps_levels,var_chi_c_eps_levels^0.5); 
        chi_c_eps_dist = chi_c_eps_dist./sum(chi_c_eps_dist); 
    end
else
    chi_c_eps_grid = 1;
    chi_c_eps_dist = 1; 
end
% sum(chi_c_eps_dist.*chi_c_eps_grid) 
% std_output = std(chi_c_eps_grid,100*chi_c_eps_dist);
% std_output^2
% % var_chi_c_eps_logs
% % mean_chi_c_eps_logs
%  bar(chi_c_eps_grid,chi_c_eps_dist)
% res
% ================= END GRIDS ====================== %  

%% ============ BEGIN CALIBRATION TARGETS & CALIBRATION INITIALIZATION & OTHER EMPIRICAL MOMENTS ===================== %
% --- BEGIN Calibration targets and parameter values -- BENCHMARK:
Laborsupply_target      = 0.3099; % CPS 2015-2017, ages 25-55, adults with non-workers set to 0 and "hours vary" response dropped. kept armed forces.
N_hours_target          = 0.3457*0.21 + 0.2967*0.79; % Averaged  Moschini (2023)
Corrincskill_target     = 0.32; % Moschini (2023)
CCDF_receipt_target     = 0.0376; % average of children receiving CCDF to children in age range; to adjust for share under 5 receiving and eligible proportionally cancels... 
Corrinitialskill_target = 0.057; % CHS (2010) Appendix Table
GRIDparp50p10_target    = 1.390; % Using GRID for US, average of 2015-2017, ages 25-34. previously was just 2016.
SS_spending_percentageY = 4.80; % MRX Table 9 - need to update, currently 2016-2018 not 2015-2017 average.

% --- Other moments: 
GRIDp50p10_target       = 1.401; % Using GRID for US, 2016, ages 25-55
GRIDp90p50_target       = 0.993; % Using GRID for US, 2016, ages 25-55
GRIDp75p50_target       = 0.52; % Using GRID for US, 2016, ages 25-55
GRIDp90p10_target       = 2.394; % Using GRID for US, 2016, ages 25-55
GRIDparp75p50_target    = 0.47; % Using GRID for US, 2016, ages 25-55
GRIDparp90p50_target    = 0.8537; % Using GRID for US, 2016 ages 25-34
GRIDparp90p10_target    = 2.241; % Using GRID for US, 2016 ages 25-34 
Gini_target             = 0.479;  % Using GRID for US, average 2015-2017, ages 25-55
Corr_parentrank_childrank_target = 0.34; % Chetty et al 2014
Q_hours_data            = 0.0986*0.21 + 0.1148*0.79; % only mother time, does not condition on working (population sample Moschini 2023).

% --- Pre-subsidy childcare price ratio vs pretax wage population (working + nonworking)
pn_ratio_observed = 0.176; % 0.176 = (34.57*0.21/(34.57*0.21 + 29.67*0.79))*1.25/9.86 + (1-34.57*0.21/(34.57*0.21 + 29.67*0.79))*2.91/15.24 from moschini 2023 population moments, quantity-weighted, doesn't restrict to working moms.

% --- Initializing calibrated parameter values at default levels and save: 
psi              = 6.7125;  
lambda_I         = 4.826;  
chi_c_fraction   = 0.140; % --> fraction of median income 
b                = 0.32945*beta;    
initial_corr_par = 0.0936;   
varlogthetak     = 1.03;      
pension_rep_rate = 0.1976;   

% --- Arrays of benchmark values
DataMoment_values_benchmark(:,1)  = [Laborsupply_target N_hours_target Corrincskill_target CCDF_receipt_target GRIDparp50p10_target Corrinitialskill_target SS_spending_percentageY pn_ratio_observed]';
Parameter_values_benchmark(:,1)   = [psi lambda_I b chi_c_fraction varlogthetak initial_corr_par pension_rep_rate]';

% psi              = 6.7125;  
% lambda_I         = 4.826;  
% chi_c_fraction   = 0.1405; % --> fraction of median income 
% b                = 0.3294*beta;    
% initial_corr_par = 0.0936;   
% varlogthetak     = 1.0;      
% pension_rep_rate = 0.1976; 

% Labor supply, ψ               : 0.3099 // 0.3102 ,6.7120
% N hours,    λ_I               : 0.3070 // 0.3074 ,4.8265
% Pct w/ CCDF,  χ_c/yp50        : 0.0376 // 0.0391 ,0.1413
% Corr(Y,Θ*), b/β               : 0.3200 // 0.3192 ,0.3394
% Corr(Θa,Θk), β_ρ              : 0.0570 // 0.0571 ,0.0956
% ln p50-p10,var(log(Θk))       : 1.3900 // 1.3868 ,1.0401
% SS Spending % GDP, φ_SS       : 4.8000 // 4.8006 ,0.1976

% 
% Labor supply, ψ               : 0.3099 // 0.3102 ,6.7113
% N hours,    λ_I               : 0.3070 // 0.3074 ,4.8258
% Pct w/ CCDF,  χ_c/yp50        : 0.0376 // 0.0391 ,0.1410
% Corr(Y,Θ*), b/β               : 0.3200 // 0.3193 ,0.3395
% Corr(Θa,Θk), β_ρ              : 0.0570 // 0.0570 ,0.0956
% ln p50-p10,var(log(Θk))       : 1.3900 // 1.3868 ,1.0419
% SS Spending % GDP, φ_SS       : 4.8000 // 4.8003 ,0.1976


% Labor supply, ψ               : 0.3099 // 0.3102 ,6.7060
% N hours,    λ_I               : 0.3070 // 0.3074 ,4.8244
% Pct w/ CCDF,  χ_c/yp50        : 0.0376 // 0.0389 ,0.1417
% Corr(Y,Θ*), b/β               : 0.3200 // 0.3190 ,0.3400
% Corr(Θa,Θk), β_ρ              : 0.0570 // 0.0572 ,0.0957
% ln p50-p10,var(log(Θk))       : 1.3900 // 1.3867 ,1.0399
% SS Spending % GDP, φ_SS       : 4.8000 // 4.8002 ,0.1976

% --- BEGIN Calibration targets and parameter values -- BENCHMARK:
% With old CCDF estimates
% Labor supply, ψ               : 0.3099 // 0.3103 ,6.6910
% N hours,    λ_I               : 0.3070 // 0.3075 ,4.8160
% Pct w/ CCDF,  χ_c/yp50        : 0.0376 // 0.0382 ,0.1423
% Corr(Y,Θ*), b/β               : 0.3200 // 0.3189 ,0.3425
% Corr(Θa,Θk), β_ρ              : 0.0600 // 0.0601 ,0.0994
% ln p50-p10,var(log(Θk))       : 1.3870 // 1.3865 ,1.0351
% SS Spending % GDP, φ_SS       : 4.8000 // 4.8002 ,0.1976


% With old targets, specifically 2 percent children under 5 not 4 percent receiving ccdf
% psi              = 6.6720;  
% lambda_I         = 4.7829;  
% chi_c_fraction   = 0.1501; % --> fraction of median income 
% b                = 0.3445*beta;    
% initial_corr_par = 0.0996;   
% varlogthetak     = 1.0336;      
% pension_rep_rate = 0.1976; 
% 
% ============ END CALIBRATION TARGETS & CALIBRATION INITIALIZATION & OTHER EMPIRICAL MOMENTS ===================== %

