function [CCDF_policy_mat] = CCDF_policy(yp50,cutoffpctiley,CCDF_toggle,fraction_chic_paid_cons,rationing_rate,subsidy_b0,subsidy_b1)
    % Need to re-estimate this for 2015-2017 
    CCDF_policy_mat = zeros(1,7);
 
    if  CCDF_toggle == 2 
        CCDF_policy_mat(1) = cutoffpctiley; % yub, income ub for eligibility proportional to median income. Uses Herbst (2008) T2
        CCDF_policy_mat(2) = subsidy_b0; % beta0 for subsidy
        CCDF_policy_mat(3) = subsidy_b1; % beta1 for subsidy
        CCDF_policy_mat(4) = 0.0; % beta2 for subsidy
        CCDF_policy_mat(5) = 0.85*yp50; % normalizer for income
        CCDF_policy_mat(6) = 1-rationing_rate; % rationing_rate = 0.16 probability of receipt conditional on applying from Guzman (2019) paper.
        CCDF_policy_mat(7) = fraction_chic_paid_cons;
    else % shut off beta0 if the policy is turned off.
        CCDF_policy_mat(1) = 0.0; % yub, income ub for eligibility proportional to median income. see UI excel sheets for calculations, this is a across-state average for 2018-2019.
        CCDF_policy_mat(2) = 0.0; % beta0 for subsidy
        CCDF_policy_mat(3) = 0.0; % beta1 for subsidy
        CCDF_policy_mat(4) = 0.0; % beta2 for subsidy
        CCDF_policy_mat(5) = 1; % normalizer for income
        CCDF_policy_mat(6) = 1; % 
        CCDF_policy_mat(7) = fraction_chic_paid_cons;    
    end

end