function [TANF_policy_mat] = TANF_policy(y_cutoff,mean_inc_norm,J)

    TANF_policy_mat = zeros(J,2);
    CPI2015_2016 = 1.01;  % See "Size_of_programs.xlsx"  
    % TANF assistance has 5-year lifetime limit, so I assume occurs when j=1, otherwise transfer is 0.
    TANF_policy_mat(1,1) = (CPI2015_2016*332*12)*mean_inc_norm; % 12th report to congress page 36 1.8 average child recipients 398 average monthly cash transfer so 221 per child - 332 is transfer for 1 child.
    TANF_policy_mat(1,2) = y_cutoff; % income ub for eligibility

end 