function [CTC_policy_mat] = CTC_policy(mean_inc_norm,j_a,J,transfer_proportion1,transfer_proportion2,refund_threshold,phaseout_threshold)
    % Use the 2009-2017 values, not the 2018-2019 values. Need to account
    % for inflation at some point. See Table 2 in CRS R45124

    CTC_policy_mat = zeros(J,6);
    
    for age = 1:j_a-1  % only takes positive values while child is at home and under the age of 17, so thats 0-16 years old or the first 3 periods of childhood.
            CTC_policy_mat(age,1) = transfer_proportion1*1000*mean_inc_norm; % max benefit per child
            CTC_policy_mat(age,2) = transfer_proportion2*1000*mean_inc_norm; % max refundable credit per child
            CTC_policy_mat(age,3) = refund_threshold*1000*mean_inc_norm; % refundability threshold
            CTC_policy_mat(age,4) = 0.15; % refundability rate
            CTC_policy_mat(age,5) = phaseout_threshold*1000*mean_inc_norm; % phaseout threshold 
            CTC_policy_mat(age,6) = 0.05; % phaseout rate
    end

end