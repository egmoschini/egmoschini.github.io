function [q_condopt,n_condopt,thetaindex_condopt,c_condopt,yd_condopt,V_condopt] = ParentConditionalMax_Speedy(par_calibration_vec,par_GE_vec,par_fixed_vec,Policy_toggle_vec,EITC_policy_mat,CTC_policy_mat,TANF_policy_mat,CCDF_policy_mat,theta_grid,theta,thetak,age,CE_scale,h_grid,Vkid,V_opt_continuation,cc_r_index,chi_c_epsval) 

EITC_toggle = Policy_toggle_vec(1); % can shut policies on and off with these toggles. 
CTC_toggle  = Policy_toggle_vec(2);
TANF_toggle = Policy_toggle_vec(3);
CCDF_toggle = Policy_toggle_vec(4);

argindex = 1;
J           = par_fixed_vec(argindex); argindex = argindex + 1;
j_a         = par_fixed_vec(argindex); argindex = argindex + 1;
j_r         = par_fixed_vec(argindex); argindex = argindex + 1;
n_types     = par_fixed_vec(argindex); argindex = argindex + 1; 
n_bins_ccsub_fc = par_fixed_vec(argindex); argindex = argindex + 1; 
n_ccsub_types = par_fixed_vec(argindex); argindex = argindex + 1; 
n_childcare = par_fixed_vec(argindex); argindex = argindex + 1; 
n_theta     = par_fixed_vec(argindex); argindex = argindex + 1; 
n_thetak    = par_fixed_vec(argindex); argindex = argindex + 1; 
n_h         = par_fixed_vec(argindex); argindex = argindex + 1; 
upsilon     = par_fixed_vec(argindex); argindex = argindex + 1; 
beta        = par_fixed_vec(argindex); argindex = argindex + 1; 
Frisch      = par_fixed_vec(argindex); argindex = argindex + 1; 
chi         = par_fixed_vec(argindex); argindex = argindex + 1; 
nu          = par_fixed_vec(argindex); argindex = argindex + 1; 
gamma       = par_fixed_vec(argindex); argindex = argindex + 1; 
OECD_child  = par_fixed_vec(argindex); argindex = argindex + 1;  
chi_u       = par_fixed_vec(argindex); argindex = argindex + 1;  
share_pension_taxed = par_fixed_vec(argindex); argindex = argindex + 1;    
beta1_wagegrowth    = par_fixed_vec(argindex); argindex = argindex + 1;  
beta2_wagegrowth    = par_fixed_vec(argindex); argindex = argindex + 1;  
beta3_wagegrowth    = par_fixed_vec(argindex); 

argindex = 1;
thetan      = par_GE_vec(argindex); argindex = argindex + 1;
pn          = par_GE_vec(argindex); argindex = argindex + 1;  
w           = par_GE_vec(argindex); argindex = argindex + 1; 
tau_c       = par_GE_vec(argindex); argindex = argindex + 1; 
tau_y       = par_GE_vec(argindex); argindex = argindex + 1; 
lambda_y    = par_GE_vec(argindex); 

argindex = 1;
b                = par_calibration_vec(argindex); argindex = argindex + 1;
lambda_I         = par_calibration_vec(argindex); argindex = argindex + 1; 
psi              = par_calibration_vec(argindex); argindex = argindex + 1; 
chi_c            = par_calibration_vec(argindex); argindex = argindex + 1;   
initial_corr_par = par_calibration_vec(argindex); argindex = argindex + 1; 
varlogthetak     = par_calibration_vec(argindex); argindex = argindex + 1; 
pension_rep_rate  = par_calibration_vec(argindex);  

        % --- Parenting productivity relationship with parent working productivity or np childcare productivity  
        par_prod = theta;   

        % --- application/receipt status flags for cost/benefits of CCDF toggles. cc_r_index ==1  is do not apply 
        flag_cc_rec_stat = (cc_r_index == 3); % apply and get it
        flag_cc_app_stat = (cc_r_index == 2 || cc_r_index == 3); % any who apply 

        % --- Fraction of chi_c paid by consumer in this policy.
        chi_c_cons = chi_c*max(chi_c_epsval-CCDF_policy_mat(7),0);  

        q_condopt          = 10^(8)*ones(n_h,1);
        n_condopt          = 10^(8)*ones(n_h,1);
        c_condopt          = 10^(8)*ones(n_h,1);
        V_condopt          = -10^(8)*ones(n_h,1);
        yd_condopt         = -10^(8)*ones(n_h,1);
        thetaindex_condopt = zeros(n_h,1);
        
        n_grid_temp = linspace(0,1,n_childcare);
        indexub     = find((theta_grid.^(1-1/chi) - (1-upsilon)*thetak^(1-1/chi)<0),1,'first')-1;
        if isempty(indexub)
            indexub = n_theta;
        end 
 
        % --- Disposible income given income level at h_value. 
        % Incorportes EITC, CTC, and TANF
        [yd_grid,~,~,~] = Tax_function(Policy_toggle_vec,EITC_policy_mat,CTC_policy_mat,TANF_policy_mat,tau_y,lambda_y,w*theta*h_grid,age); 
        h_mat  = repmat(h_grid', [1 n_childcare]);
        yd_mat = repmat(yd_grid',[1 n_childcare]);

        % CCDF eligibility and subsidy level conditional on receipt: 
        % [n_h by n_childcare] sized matrices
        CCDF_eligible  = (CCDF_toggle == 2).*(w*theta*h_mat<CCDF_policy_mat(1)).*(h_mat>0);  % evaluate at str = 2 for SF.
        tau_aux        = CCDF_policy_mat(2) + (w*theta*h_mat./CCDF_policy_mat(5)).*CCDF_policy_mat(3) + ((w*theta*h_mat./CCDF_policy_mat(5)).^(2)).*CCDF_policy_mat(4);
        tau_CCDF       = flag_cc_rec_stat.*CCDF_eligible.*max(tau_aux,0);
    
        V_grid_outcome = -10^(8)*ones(n_h,n_theta); 
        n_outcome =  -10^(8)*ones(n_h,n_theta);  
        q_outcome =  -10^(8)*ones(n_h,n_theta); 
        c_outcome =  -10^(8)*ones(n_h,n_theta); 
    
        % given labor, loop over skill outcome for kid
        for outcome_index = 1:indexub  
            I_level = (((theta_grid(outcome_index)/lambda_I)^(1-1/chi) - (1-upsilon)*thetak^(1-1/chi))/upsilon)^(chi/(chi-1)); % As opposed to: (1/lambda_I)*((((theta_grid(outcome_index))^(1-1/chi) - (1-upsilon)*thetak^(1-1/chi))/upsilon)^(chi/(chi-1))); %
            lb = find((I_level^(1-1/nu) - (1-gamma)*(thetan*n_grid_temp).^(1-1/nu)>0),1,'first'); % argument has to be >0
            
            if isempty(lb) ==0  
                % Assume we are in case where child time constraint is slack:    
                lb            = min(lb,n_childcare);
                n_grid        = linspace(n_grid_temp(lb),1,n_childcare);
                n_mat         = repmat(n_grid,[n_h 1]);
                q_mat        = (1/par_prod)*(((I_level^(1-1/nu) - (1-gamma)*(thetan*n_mat).^(1-1/nu))/gamma).^(nu/(nu-1)));
                
                % Objective function  
                c_mat         = (yd_mat - (1-tau_CCDF).*pn.*n_mat - chi_c_cons*flag_cc_app_stat)/(1+tau_c);  
                flag_feasible = (1- h_mat - q_mat>0).*(c_mat>0); % penalize if it isn't budget/parent time feasible.
                V_grid_temp   = -10^(8)*ones(n_h,n_childcare);
                V_grid_temp((flag_feasible==1)) = log(c_mat((flag_feasible==1))/(CE_scale)) - psi*((h_mat((flag_feasible==1))+q_mat((flag_feasible==1))).^(1+(1/Frisch)))/(1+(1/Frisch)) + b*Vkid(outcome_index) + beta*V_opt_continuation  - flag_cc_app_stat*chi_u;
    
                [~,argmax]  = max(V_grid_temp,[],2,'linear');  % use the linear index, then you can evaluate with just that.
                % Check that assumption of time constraint not binding is true and if it it is store the solution:
                flag_feasible = []; flag_feasible = (q_mat(argmax)+n_mat(argmax)<=1);
                n_outcome(:,outcome_index)      = n_mat(argmax).*flag_feasible - 10^(8).*(1-flag_feasible); 
                q_outcome(:,outcome_index)      = q_mat(argmax).*flag_feasible - 10^(8).*(1-flag_feasible);
                c_outcome(:,outcome_index)      = ((yd_mat(argmax) - (1-tau_CCDF(argmax)).*pn.*n_mat(argmax) - chi_c_cons*flag_cc_app_stat)/(1+tau_c)).*flag_feasible - 10^(8).*(1-flag_feasible);  
                V_grid_outcome(:,outcome_index) = V_grid_temp(argmax).*flag_feasible - 10^(8).*(1-flag_feasible);  
               
                % Find the binding time constraint combos and store them
                % when time constraint binds 
                binding_tc_hvalue_indexs = find((flag_feasible==0)==1,n_h);
                if isempty(binding_tc_hvalue_indexs) == 0
                    for haux_index = 1:length(binding_tc_hvalue_indexs)
                        h_index = binding_tc_hvalue_indexs(haux_index);
                        h_value = h_grid(h_index);
                        yd      = yd_grid(h_index);
                        q_guess     = linspace(0,1-h_value,n_childcare);
                        n_guess     = 1 - q_guess; 
                        I_implied   = (gamma*(par_prod*q_guess).^(1-1/nu) + (1-gamma)*(thetan*n_guess).^(1-1/nu)).^(nu/(nu-1)); 
                        res_binding = I_implied - I_level; 
                        sol1 = find((res_binding>0),1,'first') ;
                        sol2 = find((res_binding>0),1,'last');
                        
                        % if there are two candidate solutions find the best one:
                        if (isempty(sol1) ==0 || isempty(sol2)==0)
                            % find best of 2 solutions:
                            n_sol1 = n_guess(sol1); 
                            c_sol1 = (yd - (1-tau_CCDF(h_index,outcome_index))*pn*n_sol1 - chi_c_cons*flag_cc_app_stat)/(1+tau_c);
                            u_sol1 = log(c_sol1/CE_scale) - psi*((h_value + (1-n_sol1))^(1+(1/Frisch)))/(1+(1/Frisch)); %+ psi*log(1- h_value - (1-n_sol1));
        
                            n_sol2 = n_guess(sol2); 
                            c_sol2 = (yd - (1-tau_CCDF(h_index,outcome_index))*pn*n_sol2 - chi_c_cons*flag_cc_app_stat)/(1+tau_c);
                            u_sol2 = log(c_sol2/CE_scale) - psi*((h_value + (1-n_sol2))^(1+(1/Frisch)))/(1+(1/Frisch)); %+ psi*log(1- h_value - (1-n_sol2));
                        
                            [~,argmax] = max([u_sol1, u_sol2]);  
                            argmax = sol1*(argmax==1) + sol2*(argmax==2); 

                            % refine search grid:
                            if argmax>1 && argmax<n_childcare
                                lb_temp     = q_guess(argmax-1); ub_temp = q_guess(argmax+1); 
                            elseif argmax == 1
                                lb_temp     = 0.9*q_guess(1); ub_temp = q_guess(argmax+1); 
                            else
                                lb_temp     = q_guess(argmax-1); ub_temp = 1.1*q_guess(argmax); 
                            end
                            q_guess     = linspace(lb_temp,ub_temp,n_childcare);
                            n_guess     = 1 - q_guess; 
                            I_implied   = (gamma*(par_prod*q_guess).^(1-1/nu) + (1-gamma)*(thetan*n_guess).^(1-1/nu)).^(nu/(nu-1)); 
                            [~,argmax]  = min(abs(I_implied - I_level));

                            % If the parent time and budget constraints are satisfied, store expected value and realized consumption level:
                            if (1- h_value - q_guess(argmax)>0 && yd - (1-tau_CCDF(h_index,outcome_index))*pn*n_guess(argmax)- chi_c_cons*flag_cc_app_stat>0)  
                                
                                n_outcome(h_index,outcome_index) = n_guess(argmax); 
                                q_outcome(h_index,outcome_index) = q_guess(argmax);
        
                                c_outcome(h_index,outcome_index)  = (yd - (1-tau_CCDF(h_index,outcome_index))*pn*n_guess(argmax) - chi_c_cons*flag_cc_app_stat)/(1+tau_c);
                                V_grid_outcome(h_index,outcome_index)  = log(c_outcome(h_index,outcome_index)/CE_scale) - psi*((h_value+q_guess(argmax))^(1+(1/Frisch)))/(1+(1/Frisch)) + b*Vkid(outcome_index) + beta*V_opt_continuation  - flag_cc_app_stat*chi_u ;
        
                            end % end of conditional budget/parent time feasibility
                        end % end nonempty condition for binding contraint case.
                    end % end loop over h values where time constraint at optimal outcome binds.
                end % end condition on nonempty set of h values with binding time cosntraints at optimal outcome.
            end % end condition on nonempty n grid
        end % end child skill outcome loop 
        
        [~,argmax] = max(V_grid_outcome,[],2,'linear'); % optimal child outcome given labor choice and R uptake
        n_condopt  = n_outcome(argmax); 
        q_condopt  = q_outcome(argmax); 
        c_condopt  = c_outcome(argmax);  
        V_condopt  = V_grid_outcome(argmax); 
        yd_condopt = yd_mat(argmax); 
        [~,col_argmax] = ind2sub(size(V_grid_outcome),argmax);
        thetaindex_condopt = col_argmax;  
end