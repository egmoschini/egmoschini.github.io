% ================================================================================================================================ %
% --- MANUSCRIPT MAIN FILE: 
% (1) Taking application choice and app outcome as given, as well as initial child skill draw, chose optimal labor supply and child skill outcome.
% (2) Use these choices to construct the value of applying and being rejected, of applying and being admitted, and of not applying.
% (3) Find the expected value of applying using the probability of being rejected/rationed out and the distribution over child skill draws. EV(thetak,R|thetaa,xi)  
% (4) Choose whether or not to apply. 
% (5) Find out your application status and child's initial skill endowment. Then choose labor supply and child skill outcome/amount you want to invest in them.  
% --- OUTLINE OF CODE FILES FOR GENERATING OUTPUT: --- %
% --> Main_Calibration_Counterfactuals.m calls: Parameters_and_Calibration_targets.m (to initialize) and Solving_Equilibrium.m
%     --> Solving_Equilibrium calls: Lifecycle.m, Descriptive_Statistics_Equilibrium.m
%         --> Descriptive_Statistics_Equilibrium.m calls: weighted_correlation_coeff.m 
%         --> Lifecycle.m calls: ParentConditionalMax_Speedy.m, Tax_function.m
%             --> ParentConditionalMax_Speedy.m calls: Tax_function.m, CCDF_policy.m
%                 --> Tax_function.m calls: EITC_policy.m, CTC_policy.m, TANF_policy.m 
% Values inside EITC_policy.m, CTC_policy.m, TANF_policy.m, and CCDF_policy.m are updated in Solving_Equilibrium.m to be proportional to moments of the income distribution and uptake rates among families with young children.
% After each general equilibrium is solved --> Descriptive_Statistics_Equilibrium.m 
% ================================================================================================================================ %
run Parameters_and_Calibration_targets.m 

% ---> Toggles for tasks:  
save_output_flag          = 1;
Run_calibration           = 0;
Run_exp_size_calibration  = 0;
Run_policy_counterfactuals = 1; 

% ---> Convergence criteria, parameter output/input settings: 
res_calibration_cutoff     = 10^-3;
res_GE_cutoff              = 10^-5;
res_exp_size_equiv_cutoff  = 10^-3;
exp_size_equiv_iter_cutoff = 1;
cal_iteration_cutoff       = 30;
Cutoff_GE_iteration_count  = 25;
calib_update_rate          = 0.1;
experiments_cal_rate       = 5;

% ---> Policy pars key:  [subsidy_chic, rationing_rate, yp_cutoff, subsidy_b0, subsidy_b1, transfer_proportion1 (nonrefundable), transfer_proportion2 (refundable), refund_threshold, phaseout_threshold] Note: specific values are from CRS reports weighted with pop. fractions from Moschini (2023) or previous calibration results for the relevant experiment index.
% Note: subsidy_b1 is 0.85*reported beta_N,1 value b/c CCDF_policy.m divides by 0.85
Policy_pars_mat_inputs = [];
Policy_pars_mat_inputs(1,:)  = [0.0 0.16 0.27 0.957 -0.296 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];         % Baseline equilibrium 2015-2017 - dollars are in thousands; 55k per-adult income for 2-parent families which is the same for married filing jointly and single/head of household amount, in per-adult units.
Policy_pars_mat_inputs(2,:)  = [0.0 0.16 0.27 0.957 -0.296 2 1.4 (0.21 + 0.79*0.5)*2.5 (0.21*200 + 0.79*0.5*400)];      % 2017 TCJA expansion CTC 
Policy_pars_mat_inputs(3,:)  = [0.375 0.0 0.27 0.957 -0.296 1 1 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];          % Calibrate: Eliminate CCDF rationing (2nd element) then calibrate fixed cost subsidy to match spending from exercise 2 - > calibrates first element

% --- Policies [EITC_toggle CTC_toggle TANF_toggle CCDF_toggle] 2 is on, 1 is off. 
Policy_toggle_mat      = 2*ones(size(Policy_pars_mat_inputs,1),4); 

% --- General Equilibrium Objects that Adjust GE_toggle_mat key: 1 ==> [skill_dist adjusts, Vkid adjusts, lambda_y adjusts, pn adjusts, yp50_policy_scaling adjusts, pension_lvl adjusts]  
GE_toggle_mat = ones(size(Policy_pars_mat_inputs,1),6); % GE is default
   
% Index of GE objects for PE decompositions
PE_decomp_reference_mat = zeros(size(Policy_pars_mat_inputs,1),1);  

% Arrays of inputs for calibration targets and parameter values  
Calib_targets_mat   = repmat(DataMoment_values_benchmark(:,1),[1 size(Policy_toggle_mat,1)]);
Calib_parvalues_mat = repmat(Parameter_values_benchmark(:,1),[1 size(Policy_toggle_mat,1)]);

% Flag loops that are calibration loops; it may be that the code set has more than one.
Calibration_loop_flag_mat = zeros(1,size(Policy_toggle_mat,1));
Calibration_loop_flag_mat(1) = 1;

%  ---> For speed - initializing policy loop output (see Descriptive_Statistics_Equilibrium.m for computation of contents): 
V1_policy_mat            = zeros(n_types,size(Policy_toggle_mat,1));
Vkid_policy_mat          = zeros(n_theta,size(Policy_toggle_mat,1));
GE_objects_policy_mat    = zeros(6,size(Policy_toggle_mat,1));
GE_quantities_policy_mat = zeros(5,size(Policy_toggle_mat,1));
Exp_G_policy_mat         = zeros(3,size(Policy_toggle_mat,1));
Recipients_G_policy_mat  = zeros(2,size(Policy_toggle_mat,1));
Welfare_change_theta     = zeros(n_types,size(Policy_toggle_mat,1));
Welfare_change_pct       = zeros(1,size(Policy_toggle_mat,1));
skill_dist_policy_mat    = zeros(n_theta,size(Policy_toggle_mat,1)); 
Omega_dist_policy_mat    = zeros(n_types,J,size(Policy_toggle_mat,1));
V_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1));
V_opt_realized_policy_mat = zeros(n_types,J,size(Policy_toggle_mat,1));
theta_opt_policy_mat     = zeros(n_types,J,size(Policy_toggle_mat,1)); 
n_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
q_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
h_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
c_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
thetaa_policy_mat        = zeros(n_types,J,size(Policy_toggle_mat,1));
y_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
yd_opt_policy_mat        = zeros(n_types,J,size(Policy_toggle_mat,1)); 
ccdf_app_opt_policy_mat  = zeros(n_types,J,size(Policy_toggle_mat,1)); 
target_pct_Y_G_policy_mat         = zeros(1,size(Policy_toggle_mat,1));  
target_pct_Y_CTC_CCDF_policy_mat  = zeros(1,size(Policy_toggle_mat,1)); 
Policy_pars_mat_outputs           = 0.*Policy_pars_mat_inputs;   
gov_cc_expense_opt_policy_mat     = zeros(n_types,J,size(Policy_toggle_mat,1)); 
tax_credits_transf_opt_policy_mat = zeros(n_types,J,size(Policy_toggle_mat,1)); 
taxes_paid_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1));   
ave_fc_pct_yp50_policy_mat        = zeros(1,size(Policy_toggle_mat,1));
res_vec_policy_mat                = zeros(3,size(Policy_toggle_mat,1)); 
value_policy_equiv_par_policy_mat = zeros(1,size(Policy_toggle_mat,1));  
res_policy_equiv_policy_mat       = zeros(1,size(Policy_toggle_mat,1));

%  ---> Initialize Iteration indeces and residuals that do not change or get updated sometimes, but get printed
calibration_iter_count = 1; 
policy_iter_count      = 1; 
res_policy_equiv       = 0; 
value_policy_equiv_par = 0; 

%  ---> Begin loop
tstart_main_code = tic; 
for Policy_vec_index =  1:size(Policy_toggle_mat,1)
    
    if Policy_vec_index  == 1 || (Policy_vec_index>1 && max(Calibration_loop_flag_mat(Policy_vec_index),Run_policy_counterfactuals) == 1)  
        tstart_policyloop = tic; diary on; disp(['BEGIN POLICY INDEX #: ' num2str(Policy_vec_index)]); disp('Date and time began loop: '); disp(datetime);  diary off;

        % Open calibration targets for this Policy vector loop
        Laborsupply_target      = Calib_targets_mat(1,Policy_vec_index);
        N_hours_target          = Calib_targets_mat(2,Policy_vec_index);
        Corrincskill_target     = Calib_targets_mat(3,Policy_vec_index);
        CCDF_receipt_target     = Calib_targets_mat(4,Policy_vec_index);
        GRIDparp50p10_target    = Calib_targets_mat(5,Policy_vec_index);
        Corrinitialskill_target = Calib_targets_mat(6,Policy_vec_index);
        SS_spending_percentageY = Calib_targets_mat(7,Policy_vec_index);
        pn_ratio_observed       = Calib_targets_mat(8,Policy_vec_index);
        % Open parameter initialization for this Policy vector loop
        psi               = Calib_parvalues_mat(1,Policy_vec_index); 
        lambda_I          = Calib_parvalues_mat(2,Policy_vec_index); 
        b                 = Calib_parvalues_mat(3,Policy_vec_index); 
        chi_c_fraction    = Calib_parvalues_mat(4,Policy_vec_index); 
        varlogthetak      = Calib_parvalues_mat(5,Policy_vec_index); 
        initial_corr_par  = Calib_parvalues_mat(6,Policy_vec_index); 
        pension_rep_rate  = Calib_parvalues_mat(7,Policy_vec_index);     

        diary on;
        disp('CALIBRATION TARGETS:');
        disp(['      H   ','      N   ','  Corr(Θ,y) ','  CCDF   ','   Ineq   ','Corr(Θa,Θk)   ','SS   ']);
        disp(round(Calib_targets_mat(:,Policy_vec_index),4)');
        disp('PARAMETERIZATION INITIALIZATION:');
        disp(['      ψ   ','      λ_I   ','  χ_c/yp50   ',' b/β   ','   β_ρ   ','var(log(Θk))   ','φ_SS   ']);
        disp(round([psi lambda_I chi_c_fraction b/beta initial_corr_par varlogthetak pension_rep_rate],4));
        diary off;
    
        % Policy attributes - initialize policy loop:
        Policy_toggle_vec = Policy_toggle_mat(Policy_vec_index,:); %   
        EITC_toggle = Policy_toggle_vec(1); 
        CTC_toggle  = Policy_toggle_vec(2); 
        TANF_toggle = Policy_toggle_vec(3); 
        CCDF_toggle = Policy_toggle_vec(4);  
    
        subsidy_chic            = Policy_pars_mat_inputs(Policy_vec_index,1);  
        rationing_rate          = Policy_pars_mat_inputs(Policy_vec_index,2);  
        yp_cutoff               = Policy_pars_mat_inputs(Policy_vec_index,3); 
        subsidy_b0              = Policy_pars_mat_inputs(Policy_vec_index,4); 
        subsidy_b1              = Policy_pars_mat_inputs(Policy_vec_index,5); 
        transfer_proportion1    = Policy_pars_mat_inputs(Policy_vec_index,6); 
        transfer_proportion2    = Policy_pars_mat_inputs(Policy_vec_index,7); 
        refund_threshold        = Policy_pars_mat_inputs(Policy_vec_index,8); 
        phaseout_threshold      = Policy_pars_mat_inputs(Policy_vec_index,9); 
    end

    if Calibration_loop_flag_mat(Policy_vec_index) ==1 
        if Run_calibration == 1 && Calibration_loop_flag_mat(1) ==1 % --- Calibrate Baseline Equilibrium        
            % Calibration update rules and initializing residual: 
            res_calibration_vec = ones(1,7); 
            while max(abs(res_calibration_vec))>res_calibration_cutoff && calibration_iter_count<=cal_iteration_cutoff                         
                % Solving for GE
                diary on;
                    disp(['Calibration referencing index: ' num2str(Policy_vec_index)]); 
                    disp(['Begin Calibration index #: ' num2str(calibration_iter_count)]); 
                    disp('CALIBRATION TARGETS:');
                    disp(['      H   ','      N   ','  Corr(Θ,y) ','  CCDF   ','   Ineq   ','Corr(Θa,Θk)   ','SS   ']);
                    disp(round(Calib_targets_mat(:,Policy_vec_index),4)');
                    disp('CURRENT PARAMETERIZATION:');
                    disp(['      ψ   ','      λ_I   ','  χ_c/yp50   ',' b/β   ','   β_ρ   ','var(log(Θk))   ','φ_SS   ']);
                    disp(round([psi lambda_I chi_c_fraction b/beta initial_corr_par varlogthetak pension_rep_rate],4));
                diary off;
                tstart_EquLoop = tic;  run Solving_Equilibrium.m;  
                run Descriptive_Statistics_Equilibrium.m

                % Updated calibrated par values: 
                psi_update      = psi*(h_hours/Laborsupply_target)^(calib_update_rate); 
                lambda_I_update = lambda_I*(n_hours/N_hours_target)^(calib_update_rate);  
                b_update        = b*(abs(rho_thetay)/Corrincskill_target)^(calib_update_rate);      
                initial_corr_par_update = initial_corr_par*(rho_initialskill/Corrinitialskill_target)^(-calib_update_rate);  
                varlogthetak_update     = varlogthetak*((p50_yparGRID - p10_yparGRID)/GRIDparp50p10_target)^(-0.1*calib_update_rate);
                if CCDF_uptake>0
                    chi_c_fr_update = chi_c_fraction*(CCDF_receipt/CCDF_receipt_target)^(calib_update_rate);  
                else
                    chi_c_fr_update = chi_c_fraction*0.95;  
                end            
                pension_rep_rate_update = pension_rep_rate*(tot_G_spending_SS_policy_mat_pretax(Policy_vec_index)/SS_spending_percentageY)^(-calib_update_rate);
            
                % Calibration residuals and updating calibration pars:
                res_calibration_vec(1) = abs(h_hours - Laborsupply_target);
                res_calibration_vec(2) = abs(n_hours - N_hours_target); 
                res_calibration_vec(3) = abs(rho_thetay - Corrincskill_target);  
                res_calibration_vec(4) = abs(CCDF_receipt - CCDF_receipt_target); 
                res_calibration_vec(5) = abs(rho_initialskill - Corrinitialskill_target); 
                res_calibration_vec(6) = abs(p50_yparGRID - p10_yparGRID - GRIDparp50p10_target); 
                res_calibration_vec(7) = abs(tot_G_spending_SS_policy_mat_pretax(Policy_vec_index) - SS_spending_percentageY); 
            
                if max(abs(res_calibration_vec))>res_calibration_cutoff && calibration_iter_count<cal_iteration_cutoff % only update if it isn't the last calibration iteration loop
                    psi      = psi_update; 
                    lambda_I = lambda_I_update; 
                    b        = b_update;
                    chi_c_fraction   = chi_c_fr_update;
                    initial_corr_par = initial_corr_par_update;
                    varlogthetak     = varlogthetak_update; 
                    pension_rep_rate = pension_rep_rate_update;
                end
                calibration_iter_count = calibration_iter_count + 1;
            end
            if update_calibration_pars_toggle == 1
                output_filename = ['Raw_output/Calibration_initialization_par' num2str(Policy_vec_index) '.mat'];      
                ModelMoment_values_iter = ModelMoment_values_policy_mat(:,Policy_vec_index);
                DataMoment_values_iter  = DataMoment_values_policy_mat(:,Policy_vec_index);
                disp(['Saving calibrated parameters for index #: ' num2str(Policy_vec_index)]); save(output_filename,'psi','lambda_I','b','chi_c_fraction','initial_corr_par','varlogthetak','pension_rep_rate','DataMoment_values_iter','ModelMoment_values_iter');  
            end

        else % --- Baseline Equilibrium 
            tstart_EquLoop = tic;  run Solving_Equilibrium.m;  
            run Descriptive_Statistics_Equilibrium.m
        end

    elseif Policy_vec_index>1 && Run_policy_counterfactuals == 1  

        if Policy_vec_index ~=3  % Exercises that DO NOT calibrate policy parameters
            tstart_EquLoop = tic;  run Solving_Equilibrium.m;  
            run Descriptive_Statistics_Equilibrium.m

        else  % Exercises that DO calibrate policy parameters to hit spending level
             
            target_index = 2; % 2018 CTC expansion
            target_pct_Y_G_iter = target_pct_Y_G_policy_mat(target_index); % Govt spending target 
    
            if Run_exp_size_calibration == 1 
                policy_iter_count = 1; 
                res_policy_equiv  = 1;  
                while res_policy_equiv>res_exp_size_equiv_cutoff && policy_iter_count<=exp_size_equiv_iter_cutoff
        
                    tstart_EquLoop = tic;  run Solving_Equilibrium.m;  
                    run Descriptive_Statistics_Equilibrium.m
            
                    % Updating policy parameter based on size of total expenditure: 
                    pct_realized     = target_pct_Y_G_policy_mat(Policy_vec_index);        
                    res_policy_equiv = abs(pct_realized - target_pct_Y_G_iter);
                    
                    diary on; disp('Equiv. spending calibration: update --> '); disp(['Share of output and input pars: ' num2str([policy_iter_count, target_pct_Y_G_iter, pct_realized, res_policy_equiv, subsidy_chic, rationing_rate, yp_cutoff, subsidy_b0,subsidy_b1, transfer_proportion1, transfer_proportion2, refund_threshold, phaseout_threshold], '%0.4f ,')]); diary off;
    
                    if res_policy_equiv>res_exp_size_equiv_cutoff && policy_iter_count<exp_size_equiv_iter_cutoff && Run_exp_size_calibration ==1 % Only update parameters if the process is flagged on at the start
                        if ismember(Policy_vec_index,3)   % CCDF policy is calibrated
                            subsidy_chic = subsidy_chic*(pct_realized/target_pct_Y_G_iter).^(-1*experiments_cal_rate); 
                            value_policy_equiv_par = subsidy_chic;
                        end
                    end
                    policy_iter_count = policy_iter_count + 1;
                    diary on;disp(['Share of output and output pars: ' num2str([policy_iter_count-1, target_pct_Y_G_iter, pct_realized, res_policy_equiv, subsidy_chic, rationing_rate, yp_cutoff, subsidy_b0,subsidy_b1, transfer_proportion1, transfer_proportion2, refund_threshold, phaseout_threshold], '%0.4f ,')]); diary off;
        
                end % end policy parameter calibration + SS solution
                
                run Descriptive_Statistics_Equilibrium.m % run this one last time to store residual
           else
                tstart_EquLoop = tic;  run Solving_Equilibrium.m;  
                run Descriptive_Statistics_Equilibrium.m
           end

        end % end conditional on policy index  

    end % end calibration conditional 

    Policy_pars_mat_outputs(Policy_vec_index,:) = [subsidy_chic, rationing_rate, yp_cutoff, subsidy_b0,subsidy_b1, transfer_proportion1, transfer_proportion2, refund_threshold, phaseout_threshold];
end % end policy loop
  

%  ---> Output results
if save_output_flag == 1
    output_filename = 'Raw_output/Output_main_manuscript.mat';
    save(output_filename); 
    output_filename = 'Raw_output/Policy_pars_mat_outputs.mat';
    save(output_filename,'Policy_pars_mat_outputs'); 
end
 
diary on; disp(['Time in seconds for this main file = ' num2str(toc(tstart_main_code))] ); diary off;
disp(['MOSCHINI AND TRAN-XUAN (2025) MAIN MANUSCRIPT CODE COMPLETED. SEE DIARY FILE: ' get(0,'DiaryFile')]);
 