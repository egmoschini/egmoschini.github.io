function [V_opt,V_opt_realized,theta_opt,n_opt,q_opt,h_opt,c_opt,thetaa_opt,y_opt,yd_opt,ccdf_app_opt,ccdf_fc_opt,gov_cc_expense_opt,tax_credits_transf_opt,taxes_paid_opt,EITC_received_opt,CTC_received_opt,TANF_received_opt] = Lifecycle_utility_cost(Policy_toggle_vec,par_calibration_vec,par_GE_vec,par_fixed_vec,pension_lvl,EITC_policy_mat,CTC_policy_mat,TANF_policy_mat,CCDF_policy_mat,type_mat,theta_grid,thetak_grid,h_grid,chi_u_eps_grid,thetak_dist,Vkid)

EITC_toggle = Policy_toggle_vec(1); % cab shut on and off with this. 
CTC_toggle  = Policy_toggle_vec(2);
TANF_toggle = Policy_toggle_vec(3);
CCDF_toggle = Policy_toggle_vec(4);

argindex = 1;
J           = par_fixed_vec(argindex); argindex = argindex + 1;
j_a         = par_fixed_vec(argindex); argindex = argindex + 1;
j_r         = par_fixed_vec(argindex); argindex = argindex + 1;
n_types     = par_fixed_vec(argindex); argindex = argindex + 1; 
n_bins_ccsub_fc = par_fixed_vec(argindex); argindex = argindex + 1; 
n_ccsub_types = par_fixed_vec(argindex); argindex = argindex + 1; 
n_childcare = par_fixed_vec(argindex); argindex = argindex + 1; 
n_theta     = par_fixed_vec(argindex); argindex = argindex + 1; 
n_thetak    = par_fixed_vec(argindex); argindex = argindex + 1; 
n_h         = par_fixed_vec(argindex); argindex = argindex + 1; 
upsilon     = par_fixed_vec(argindex); argindex = argindex + 1; 
beta        = par_fixed_vec(argindex); argindex = argindex + 1; 
Frisch      = par_fixed_vec(argindex); argindex = argindex + 1; 
chi         = par_fixed_vec(argindex); argindex = argindex + 1; 
nu          = par_fixed_vec(argindex); argindex = argindex + 1; 
gamma       = par_fixed_vec(argindex); argindex = argindex + 1; 
OECD_child  = par_fixed_vec(argindex); argindex = argindex + 1;  
chi_c       = par_fixed_vec(argindex); argindex = argindex + 1;  
share_pension_taxed = par_fixed_vec(argindex); argindex = argindex + 1;    
beta1_wagegrowth    = par_fixed_vec(argindex); argindex = argindex + 1;  
beta2_wagegrowth    = par_fixed_vec(argindex); argindex = argindex + 1;  
beta3_wagegrowth    = par_fixed_vec(argindex); 

argindex = 1;
thetan      = par_GE_vec(argindex); argindex = argindex + 1;
pn          = par_GE_vec(argindex); argindex = argindex + 1;  
w           = par_GE_vec(argindex); argindex = argindex + 1; 
tau_c       = par_GE_vec(argindex); argindex = argindex + 1; 
tau_y       = par_GE_vec(argindex); argindex = argindex + 1; 
lambda_y    = par_GE_vec(argindex);   

argindex = 1;
b                = par_calibration_vec(argindex); argindex = argindex + 1;
lambda_I         = par_calibration_vec(argindex); argindex = argindex + 1; 
psi              = par_calibration_vec(argindex); argindex = argindex + 1; 
chi_u            = par_calibration_vec(argindex); argindex = argindex + 1;   
initial_corr_par = par_calibration_vec(argindex); argindex = argindex + 1; 
varlogthetak     = par_calibration_vec(argindex); argindex = argindex + 1; 
pension_rep_rate  = par_calibration_vec(argindex);  

V_opt                  = -10^(8)*ones(n_types,J); 
n_opt                  = zeros(n_types,J); 
q_opt                  = zeros(n_types,J); 
h_opt                  = zeros(n_types,J); 
c_opt                  = zeros(n_types,J); 
y_opt                  = zeros(n_types,J); 
yd_opt                 = zeros(n_types,J); 
theta_opt              = zeros(n_types,J); 
gov_cc_expense_opt     = zeros(n_types,J); 
tax_credits_transf_opt = zeros(n_types,J); 
taxes_paid_opt         = zeros(n_types,J); 
EITC_received_opt = zeros(n_types,J); 
CTC_received_opt  = zeros(n_types,J); 
TANF_received_opt = zeros(n_types,J);  
ccdf_app_opt     = ones(n_types,J);
ccdf_fc_opt      = zeros(n_types,J);
V_opt_realized     = ones(n_types,J); 

theta_profile_grid = zeros(n_theta,J);

     for theta_index = 1:n_theta  
            for age = 1:J
                labor_eff_units = theta_grid(theta_index);
                wage_growth_age = beta1_wagegrowth*(age-1) + beta2_wagegrowth*(age-1)^2 + beta3_wagegrowth*(age-1)^3;
                theta_profile_grid(theta_index,age) = labor_eff_units*(1+wage_growth_age);
            end
     end 

    parfor type_index = 1:n_types
        theta_index  = type_mat(type_index,1); 
        thetak_index = type_mat(type_index,2);
        cc_a_r_index = type_mat(type_index,3);
        cc_fc_index  = type_mat(type_index,4); 

        theta        = theta_grid(type_mat(type_index,1)); % NOTE!!! scales for wages and parenting productivity
        thetak       = thetak_grid(type_mat(type_index,2));  
        chi_u_epsval = chi_u_eps_grid(type_mat(type_index,4));

        V_profile        = -10^(8)*ones(1,J); 
        n_profile        = zeros(1,J); 
        q_profile        = zeros(1,J); 
        h_profile        = zeros(1,J); 
        y_profile        = zeros(1,J); 
        yd_profile       = zeros(1,J); 
        c_profile        = zeros(1,J); 
        thetaa_profile   = zeros(1,J); 
        tax_paid_profile = zeros(1,J); 
        thetaindex_profile         = zeros(1,J); 
        gov_cc_expense_profile     = zeros(1,J); 
        tax_credits_transf_profile = zeros(1,J); 
        EITC_profile     = zeros(1,J); 
        CTC_profile      = zeros(1,J); 
        TANF_profile     = zeros(1,J); 


        for age = J:-1:1 
            y_grid = w*theta_profile_grid(theta_index,age)*h_grid;
            CE_scale = 1 + OECD_child*(age<=j_a);

            if age == J   % retired
                    h_profile(age)                  = 0;
                    y_profile(age)                  = 0;  
                    yd_profile(age)                 = (1-share_pension_taxed)*pension_lvl(type_index) + lambda_y*(share_pension_taxed*pension_lvl(type_index))^(1-tau_y);
                    c_profile(age)                  = yd_profile(age)/(1+tau_c);  
                    thetaa_profile(age)             = theta_profile_grid(theta_index,age);
                    tax_paid_profile(age)           = pension_lvl(type_index) - yd_profile(age);
                    tax_credits_transf_profile(age) = yd_profile(age); 
                    EITC_profile(age)               = 0;
                    CTC_profile(age)                = 0;
                    TANF_profile(age)               = 0;
                    V_profile(age)                  = log(yd_profile(age)/((1+tau_c)*CE_scale)) - psi*(0.^(1+(1/Frisch)))./(1+(1/Frisch)); 
            elseif age >=j_r % retired
                    h_profile(age)                  = 0;
                    y_profile(age)                  = 0;  
                    yd_profile(age)                 = (1-share_pension_taxed)*pension_lvl(type_index) + lambda_y*(share_pension_taxed*pension_lvl(type_index))^(1-tau_y);
                    c_profile(age)                  = yd_profile(age)/(1+tau_c);  
                    thetaa_profile(age)             = theta_profile_grid(theta_index,age);
                    tax_paid_profile(age)           = pension_lvl(type_index) - yd_profile(age);
                    tax_credits_transf_profile(age) = yd_profile(age); 
                    EITC_profile(age)               = 0;
                    CTC_profile(age)                = 0;
                    TANF_profile(age)               = 0;
                    V_profile(age)                  = log(yd_profile(age)/((1+tau_c)*CE_scale)) - psi*(0.^(1+(1/Frisch)))./(1+(1/Frisch)) + (age<J)*beta*V_profile(age+1); 
            elseif age>1  
                    [yd_grid,EITC_grid,CTC_grid,TANF_grid]  = Tax_function(Policy_toggle_vec,EITC_policy_mat,CTC_policy_mat,TANF_policy_mat,tau_y,lambda_y,y_grid,age); 
                    V_grid     = log(yd_grid/((1+tau_c)*CE_scale)) - psi*(h_grid.^(1+(1/Frisch)))./(1+(1/Frisch)) + beta*V_profile(age+1) ;
                    [~,argmax] = max(V_grid); % best labor choice. 
                    h_profile(age)                  = h_grid(argmax);
                    y_profile(age)                  = y_grid(argmax);
                    yd_profile(age)                 = yd_grid(argmax);
                    c_profile(age)                  = yd_grid(argmax)/(1+tau_c);
                    thetaa_profile(age)             = theta_profile_grid(theta_index,age);
                    tax_paid_profile(age)           = y_grid(argmax) - yd_grid(argmax);
                    tax_credits_transf_profile(age) = yd_profile(age) - lambda_y*y_profile(age)^(1-tau_y);
                    EITC_profile(age)               = EITC_grid(argmax);
                    CTC_profile(age)                = CTC_grid(argmax);
                    TANF_profile(age)               = TANF_grid(argmax);
                    V_profile(age)                  = V_grid(argmax); 
            elseif age == 1   
                [q_condopt,n_condopt,thetaindex_condopt,c_condopt,yd_condopt,V_condopt] = ParentConditionalMax_Speedy_utility_cost(par_calibration_vec,par_GE_vec,par_fixed_vec,Policy_toggle_vec,EITC_policy_mat,CTC_policy_mat,TANF_policy_mat,CCDF_policy_mat,theta_grid,theta_profile_grid(theta_index,age),thetak,age,CE_scale,h_grid,Vkid,V_profile(age+1),cc_a_r_index,chi_u_epsval);
                [~,EITC_grid,CTC_grid,TANF_grid]= Tax_function(Policy_toggle_vec,EITC_policy_mat,CTC_policy_mat,TANF_policy_mat,tau_y,lambda_y,y_grid,age); 
                [~,argmax] = max(V_condopt);
                h_profile(age)                  = h_grid(argmax);
                y_profile(age)                  = y_grid(argmax);  
                yd_profile(age)                 = yd_condopt(argmax);
                c_profile(age)                  = c_condopt(argmax);
                thetaa_profile(age)             = theta_profile_grid(theta_index,age);
                n_profile(age)                  = n_condopt(argmax); 
                q_profile(age)                  = q_condopt(argmax); 
                thetaindex_profile(age)         = thetaindex_condopt(argmax); 
                tax_paid_profile(age)           = y_profile(age) - yd_profile(age);
                tax_credits_transf_profile(age) = yd_profile(age) - lambda_y*y_profile(age)^(1-tau_y);
                EITC_profile(age)               = EITC_grid(argmax);
                CTC_profile(age)                = CTC_grid(argmax);
                TANF_profile(age)               = TANF_grid(argmax); 
                CCDF_eligible                   = (CCDF_toggle ==2 && y_profile(age)<CCDF_policy_mat(1) && h_profile(age)>0);
                tau_aux                         = CCDF_policy_mat(2) + (y_profile(age)./CCDF_policy_mat(5)).*CCDF_policy_mat(3) + (y_profile(age)./CCDF_policy_mat(5)).^(2).*CCDF_policy_mat(4);
                tau_CCDF                        = CCDF_eligible.*max(tau_aux,0);
                gov_cc_expense_profile(age)     = CCDF_eligible.*((cc_a_r_index==3).*tau_CCDF*n_profile(age)*pn) + (cc_a_r_index==2 || cc_a_r_index==3).*chi_c; 
                V_profile(age)                  = V_condopt(argmax);  
    
            end % end age conditional
        end % end age loop
    
        h_opt(type_index,:)                  = h_profile;
        c_opt(type_index,:)                  = c_profile;
        y_opt(type_index,:)                  = y_profile; 
        yd_opt(type_index,:)                 = yd_profile;
        n_opt(type_index,:)                  = n_profile; 
        q_opt(type_index,:)                  = q_profile; 
        thetaa_opt(type_index,:)             = thetaa_profile;
        theta_opt(type_index,:)              = thetaindex_profile;
        ccdf_fc_opt(type_index,1)            = (cc_a_r_index==2 || cc_a_r_index==3).*chi_c;
        gov_cc_expense_opt(type_index,:)     = gov_cc_expense_profile ;   
        tax_credits_transf_opt(type_index,:) = tax_credits_transf_profile;
        taxes_paid_opt(type_index,:)         = tax_paid_profile;
        EITC_received_opt(type_index,:)      = EITC_profile;
        CTC_received_opt(type_index,:)       = CTC_profile;
        TANF_received_opt(type_index,:)      = TANF_profile;
        V_opt(type_index,:)                  = V_profile;
        
    end % end type loop
    
    % -- Optimal choice of applying for CC: 

    % Reshaping objects so that taking expectations is easier.
    options_temp = zeros(n_theta,n_thetak,n_ccsub_types);
    for type_index = 1:n_types
        theta_index  = type_mat(type_index,1); 
        thetak_index = type_mat(type_index,2);
        cc_a_r_index = type_mat(type_index,3);
        cc_fc_index  = type_mat(type_index,4);
        options_temp(theta_index,thetak_index,cc_a_r_index,cc_fc_index) = V_opt(type_index,1);
        c_temp(theta_index,thetak_index,cc_a_r_index,cc_fc_index) = c_opt(type_index,1);
        h_temp(theta_index,thetak_index,cc_a_r_index,cc_fc_index) = h_opt(type_index,1);
        q_temp(theta_index,thetak_index,cc_a_r_index,cc_fc_index) = q_opt(type_index,1);
        n_temp(theta_index,thetak_index,cc_a_r_index,cc_fc_index) = n_opt(type_index,1);
    end
    ccdf_app_opt_aux = []; V_opt_realized_aux = [];

    % This version chooses delta* by comparing expected value over thetak and R
    for theta_index = 1:n_theta
        %for thetak_index = 1:n_thetak
            for cc_fc_index = 1:n_bins_ccsub_fc
                EV_noapp = sum(thetak_dist(theta_index,:).*options_temp(theta_index,:,1,cc_fc_index)); % don't apply
                EV_app = (1-CCDF_policy_mat(6))*sum(thetak_dist(theta_index,:).*options_temp(theta_index,:,2,cc_fc_index)) + CCDF_policy_mat(6)*sum(thetak_dist(theta_index,:).*options_temp(theta_index,:,3,cc_fc_index));
                if EV_app-EV_noapp> 10^-8
                    argmax = 2; maxval = EV_app;
                else
                    argmax = 1; maxval = EV_noapp;
                end
                %[maxval,argmax] = max([EV_noapp EV_app]); % argmax has value of 2 if apply, value of 1 if do not apply
                ccdf_app_opt_aux(theta_index,cc_fc_index) = argmax;
                V_opt_realized_aux(theta_index,cc_fc_index) = maxval;
                EV_noapp_aux(theta_index,cc_fc_index) = EV_noapp;
                EV_app_aux(theta_index,cc_fc_index) = EV_app;
            end
        %end
    end 
    for type_index = 1:n_types
        theta_index  = type_mat(type_index,1); 
        thetak_index = type_mat(type_index,2);
        cc_a_r_index = type_mat(type_index,3);
        cc_fc_index  = type_mat(type_index,4);

        ccdf_app_opt(type_index,1) = ccdf_app_opt_aux(theta_index,cc_fc_index);
        V_opt_realized(type_index,1) = V_opt_realized_aux(theta_index,cc_fc_index);
        V_opt_realized(type_index,2:end) = V_opt(type_index,2:end);  
    end
  
end