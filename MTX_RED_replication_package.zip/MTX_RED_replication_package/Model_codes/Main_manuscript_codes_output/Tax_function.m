function [yd_grid,EITC_grid,CTC_grid,TANF_grid] = Tax_function(Policy_toggle_vec,EITC_policy_mat,CTC_policy_mat,TANF_policy_mat,tau_y,lambda_y,y_grid,age)
    
    EITC_toggle = Policy_toggle_vec(1); % cab shut on and off with this. 
    CTC_toggle  = Policy_toggle_vec(2);
    TANF_toggle = Policy_toggle_vec(3);
    CCDF_toggle = Policy_toggle_vec(4); 

    % Extract appropriate EITC policy parameters given family type
    max_credit_EITC    = EITC_policy_mat(age,1); % max credit amount
    earned_y_EITC      = EITC_policy_mat(age,2); % earned income amount <-- I think this is redundant with max credit
    phaseout_y_EITC    = EITC_policy_mat(age,3); % phaseout threshold amount
    zero_credit_y_EITC = EITC_policy_mat(age,4); % zero credit threshold amount <-- I think this is redundant with phaseout threshold and phaseout rate credit
    credit_rate_EITC   = EITC_policy_mat(age,5); % credit rate
    phaseout_rate_EITC = EITC_policy_mat(age,6); % phaseout rate
    
    % Extract appropriate CTC policy parameters given family type
    max_ben_CTC       = CTC_policy_mat(age,1); % max benefit per child
    max_refundben_CTC = CTC_policy_mat(age,2); % max refundable credit per child
    refund_y_CTC      = CTC_policy_mat(age,3); % refundability threshold
    refund_rate_CTC   = CTC_policy_mat(age,4); % refundability rate
    phaseout_y_CTC    = CTC_policy_mat(age,5); % phaseout threshold
    phaseout_rate_CTC = CTC_policy_mat(age,6); % phaseout rate
    
    % Extract appropriate TANF policy parameters given family type
    transfer_TANF = TANF_policy_mat(age,1);
    y_ub_TANF     = TANF_policy_mat(age,2); 
       
    % Income tax
    y_aftx_grid        = lambda_y*y_grid.^(1-tau_y);
    tax_liability_grid = y_grid - y_aftx_grid;
    
    % ---- > PER CHILD
    % EITC          
    EITC_constraint1 = max_credit_EITC.*(y_grid>=0) - (y_grid>phaseout_y_EITC).*phaseout_rate_EITC.*(y_grid - phaseout_y_EITC);
    EITC_constraint2 = credit_rate_EITC.*y_grid;
    EITC_grid = min(EITC_constraint1,EITC_constraint2); 
    EITC_grid = max(EITC_grid,0);         

    % CTC -> careful, cannot be negative.
%     nonrefundable_benefit_grid = 0.*y_grid;
%     nonrefundable_benefit_grid(y_grid<phaseout_y_CTC)  = max_ben_CTC;
%     nonrefundable_benefit_grid(y_grid>=phaseout_y_CTC) = max_ben_CTC - phaseout_rate_CTC*max(y_grid - phaseout_y_CTC);
%     nonrefundable_benefit_grid                         = nonrefundable_benefit_grid.*(nonrefundable_benefit_grid>=0);
%     CTC_grid_temp  = 0.*y_grid;
%     CTC_grid_temp(tax_liability_grid>0)  = min(nonrefundable_benefit_grid(tax_liability_grid>0),tax_liability_grid(tax_liability_grid>0)); % non-refundable portion
%     
%     ACTC_max       = min(nonrefundable_benefit_grid - CTC_grid_temp,max_refundben_CTC);
%     flag_phasein   = (y_grid>=refund_y_CTC);
%     ACTC_grid_temp = 0.*y_grid;
%     ACTC_grid_temp(flag_phasein==1) = min(refund_rate_CTC.*(y_grid(flag_phasein==1)-refund_y_CTC),ACTC_max(flag_phasein==1)); % refundable portion
%     
%     CTC_grid2       = CTC_grid_temp + ACTC_grid_temp;

    nonrefundable_benefit_grid = 0.*y_grid;
    nonrefundable_benefit_grid = max_ben_CTC.*(y_grid>=0) - phaseout_rate_CTC*max(y_grid - phaseout_y_CTC).*(y_grid>=phaseout_y_CTC);
    nonrefundable_benefit_grid = max(nonrefundable_benefit_grid,0); 
    
    CTC_grid_temp  = 0.*y_grid;
    CTC_grid_temp  = min(tax_liability_grid,nonrefundable_benefit_grid); 
    CTC_grid_temp  = max(CTC_grid_temp,0);

    ACTC_grid_temp = 0.*y_grid;
    ACTC_constraint1 = nonrefundable_benefit_grid - CTC_grid_temp;
    ACTC_constraint2 = min(refund_rate_CTC*(y_grid-refund_y_CTC),max_refundben_CTC.*(y_grid>=0));
    ACTC_grid_temp   = min(ACTC_constraint1,ACTC_constraint2); 
    ACTC_grid_temp   = max(ACTC_grid_temp,0);

    CTC_grid       = CTC_grid_temp + ACTC_grid_temp;
 
    % TANF 
    TANF_grid = 0*y_grid;    
    TANF_grid((y_grid<=y_ub_TANF)) = transfer_TANF;

    % Incorporating policy toggles
    EITC_grid = (EITC_toggle - 1)*EITC_grid;
    CTC_grid  = (CTC_toggle - 1)*CTC_grid;
    TANF_grid = (TANF_toggle - 1).*TANF_grid; 
 
    % Disposible income: 
    yd_grid   = y_grid - tax_liability_grid + (y_grid>0).*(EITC_grid + CTC_grid) + TANF_grid ;

end