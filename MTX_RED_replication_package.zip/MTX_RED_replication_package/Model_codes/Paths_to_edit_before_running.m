clear all; close all; clc; 
cd(fileparts(which(matlab.desktop.editor.getActiveFilename))); 

% --- Begin: paths to edit to match your computer
replication_package_path = 'C:\Users\egmoschini\Dropbox\Personal MTX CC Subsidies\RED_cond_acc_replication\';
% --- End: paths to edit to match your computer 

% Defining referenced paths: 
main_manuscript_path = [replication_package_path 'Model_codes\Main_manuscript_codes_output\']; % Location of main manuscript codes and output
online_appendix_path = [replication_package_path 'Model_codes\Online_appendix_codes_output\']; % Location of online appendix codes and output
draft_output_path    = [replication_package_path 'Model_codes\Tables_and_figures\'];           % Location of figures and tables to replicate the paper
data_path            = [replication_package_path 'Data_codes\CPS_CCDF_estimations\Results\'];  % Location of estimated spending distributions
