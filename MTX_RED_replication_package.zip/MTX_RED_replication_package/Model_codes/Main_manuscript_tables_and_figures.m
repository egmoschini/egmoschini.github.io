%% --- Section 2: Policy environment
close all; clc;
% ---> Figure 1: CTC and CCDF recipient distribution data
hFig = figure(1);   
subplot(1,2,1);
b1 = bar([sharespendingctc(:) sharespendingccdf(:)  ],0.8,"FaceAlpha",0.5,'FaceColor','flat' ); 
grid on;  axis square;
xlabel('Pretax income bin','Interpreter','latex'); 
ylim([0 1.0]); ylabel('Share of spending','Interpreter','latex'); ytickformat('%.1f'); 
hleglines = [b1(1) b1(2)];
b1(1).CData = 0.6*[0 0.6 0.3];
lgd = legend(hleglines,'CTC','CCDF', 'Interpreter','latex','Location','NorthEast','NumColumns',1,'FontSize',14); 
legend boxoff;
title('\textbf{Spending}');
set(gca,'Fontsize',14,'FontName',font_name,'xcolor','k','ycolor','k','TickLength',[0.0,0.0]);
subplot(1,2,2);
b1 = bar([sharereceiptctc(:) sharereceiptccdf(:)  ],0.8,"FaceAlpha",0.5,'FaceColor','flat' ); 
grid on;  axis square;
xlabel('Pretax income bin','Interpreter','latex'); 
ylim([0 1.0]); ylabel('Share of recipients','Interpreter','latex'); ytickformat('%.1f');  
b1(1).CData = 0.6*[0 0.6 0.3]; 
title('\textbf{Recipients}');
set(gca,'Fontsize',14,'FontName',font_name,'xcolor','k','ycolor','k','TickLength',[0.0,0.0]); 
filename_temp = strcat(draft_output_path,'CCDF_CTC_both_ybin_data.png');
delete(filename_temp);
pause(5);
exportgraphics(hFig,filename_temp); 

%% --- Section 3 Model: 
n_bins = 10000; 
income = linspace(0,550000,n_bins);  

% ---> Figure 3: CCDF transfer stylized figure 
US_median_wage = US_yp50/(52*Laborsupply_target);
US_pn = US_median_wage*pn_ratio_observed; % uses ratio for all moms of wages to price of childcare
USy_p27 = (27/50)*US_yp50;
 
hFig=figure(2);
top_index = 600;
taunccdf = []; taunccdf = (0.7  - 0.6*income/US_yp50).*(income<USy_p27); % stylized
cutoff_positive = find((taunccdf>0),1,'last');
h5 = plot([income(1) ], [taunccdf(1)], 'square', 'MarkerSize', 8, 'LineWidth', 2,'Color', [0.85 0.325 0.098]);hold on;  
h1 = plot(income(5:cutoff_positive-5),taunccdf(5:cutoff_positive-5),'LineWidth',2.0,'Color', [0.85 0.325 0.098]); 
h6 = plot([income(cutoff_positive-1) ], [taunccdf(cutoff_positive-1)], 'o', 'MarkerSize', 6, 'LineWidth', 2,'Color', [0.85 0.325 0.098] );  
h2 = plot(income(cutoff_positive+1), taunccdf(cutoff_positive+1), '.', 'MarkerSize', 25, 'LineWidth', 2 ,'Color', [0.85 0.325 0.098]); 
h3 = plot([0], [0], 'square', 'MarkerSize', 8, 'LineWidth', 2,'MarkerFaceColor', [0.85 0.325 0.098],'Color', [0.85 0.325 0.098]); 
h4 = plot(income(cutoff_positive+1:top_index),taunccdf(cutoff_positive+1:top_index),'LineWidth',2.0,'Color', [0.85 0.325 0.098]);   
ylabel({'$I_{y\in \left(0,\overline{y}_{N}\right)} \tau_{N}\left(y \mid \vec{\pi}_{N}\right)$' },'Color','k','Interpreter','latex','FontSize',17);  hold off; 
set(gca, 'XColor','k', 'YColor','k') 
hleglines = [h1(1) h5(1) h3(1)];
lgd=legend('Eligibility lower bound at $y=0$','Subsidy rate $\tau_{N}$ when $y\in \left(0,\overline{y}_{N}\right)$','Eligibility upper bound at $y=\overline{y}_{N}$','Location','North','NumColumns',1,'Interpreter','latex','FontSize',14); 
set(lgd,'Box','off'); axis square;
xlabel({'Pretax income level $y$'},'Interpreter','latex','FontSize',17); 
xlim([0,income(top_index)]);
xticks(''); xticklabels({'' }); 
yticks('');  yticklabels(0); ylim([0 0.95]); 
ax= gca;
ax.YAxis.FontSize = 17;
ax.XAxis.FontSize = 17;
filename_temp = strcat(draft_output_path,'model_CCDF_structure_stylized.png');
delete(filename_temp);
pause(5);
exportgraphics(hFig,filename_temp);

% ---> Figure 4: CTC transfer stylized figure 
% CTC + ACTC after 2018 reform - CTC and ACTC CRS R41873 Table 1
lambda_y_ctc = (US_yp50*(GE_objects_policy_mat(5,1)^(1/tau_y))/GE_objects_policy_mat(4,1))^(tau_y); 
tax_liability = max(income - lambda_y_ctc*(income).^(1-tau_y),0);
tax_liability = max(tax_liability,0);

% Income tax net of CTC and EITC
tau_progressivity = 0.06; 

% Policy:
max_benefit_per_child = 1000;
max_refundable_credit_per_child = 1000;
refundability_threshold = 1815;
refundability_rate = 0.15;
phaseout_threshold = 59200;
phaseout_rate = 0.05;
ylim_min = 0;
ylim_max = 1500;
xlim_min = 0;
xlim_max = 130000;   

CTC_level = []; ACTC_level= []; CTC_tot= []; residual = []; ctc_step1_graphing= [];
for index = 1:n_bins        
    if  income(index)< phaseout_threshold              
        ctc_step1             = max_benefit_per_child;       
    elseif income(index) >= phaseout_threshold         
        ctc_step1             = max(max_benefit_per_child - phaseout_rate*(income(index) - phaseout_threshold ),0);
    end       
    ctc_step1_graphing(index) = ctc_step1;
    CTC_level(index)  = max(min(tax_liability(index),ctc_step1),0); % in case tax liability is negative; otherwise, the total CTC blue line won't be the sum of the ACTC and CTC lines.
    residual(index) = max(ctc_step1 - CTC_level(index),0);
    if income(index) >= refundability_threshold && ctc_step1 > CTC_level(index)
        ctc_step2             = min(ctc_step1 - CTC_level(index),max_refundable_credit_per_child);
        ACTC_level(index) = min(refundability_rate*(income(index) - refundability_threshold),ctc_step2);
    else 
        ACTC_level(index) = 0;
    end 
    CTC_tot(index)    = CTC_level(index) + ACTC_level(index);
end 

% Figure 4(a)
% Total credit  
close(figure(3)); hFig=figure(3);
h1 = plot(income,CTC_level(:)+ACTC_level(:),'LineWidth',2.0,'Color', [0 0.6 0.3]);hold on;
h2 = plot(income,CTC_level(:),'LineWidth',3.0,'Color',[0.4 0.4 0.4],'LineStyle',":");  h2.Color(4) = 0.5; 
h3 = plot(income,ACTC_level(:),'LineWidth',3.0,'Color',[0.4 0.4 0.4],'LineStyle',"-.");   h3.Color(4) = 0.5; 
ylim([ylim_min,ylim_max]); xlim([xlim_min,xlim_max]); 
lgd=legend('Total $CTC=CTC_{n} + CTC_r$','Nonrefundable component $CTC_{n}$','Refundable component $CTC_{r}$','Location','NorthWest','NumColumns',1,'Interpreter','latex','FontSize',14); 
set(lgd,'Box','off'); axis square;
ylabel('Credit level','Interpreter','latex','FontSize',17); 
xlabel('Pretax income $y$','Interpreter','latex','FontSize',17); 
xticks(''); xticklabels({'' });
yticks(0);  
ax= gca;
ax.YAxis.FontSize = 17;
ax.XAxis.FontSize = 17;
filename_temp = strcat(draft_output_path,'constructingCTC_ACTCtotal_stylized.png');
delete(filename_temp);
pause(5);
exportgraphics(hFig,filename_temp); 

% Figure 4(b)
close(figure(4)); hFig=figure(4);
h3 = plot(income,CTC_level(:),'LineWidth',6.0,'Color',[0.4 0.4 0.4]);  h3.Color(4) = 0.4; hold on; 
h1 = plot(income,ctc_step1_graphing(:),'LineWidth',2.0,'LineStyle',":"); h1.Color(4) = 1.0;  
h2 = plot(income,tax_liability,'LineWidth',2.0,'Color',[0.6350 0.0780 0.1840],'LineStyle',"-.");  h2.Color(4) = 1.0; 
ylim([ylim_min,ylim_max]); xlim([xlim_min,xlim_max]);  
lgd = legend('$CTC_{n}$','Max nonrefundable credit' ,'Tax liability' ,'Location','NorthEast','NumColumns',1,'FontSize',14); 
set(lgd,'Box','off'); axis square;
ylabel('Credit level','Interpreter','latex','FontSize',17); 
xlabel('Pretax income $y$','Interpreter','latex','FontSize',17); 
xticks(''); xticklabels({'' });
yticks(0); 
ax= gca;
ax.YAxis.FontSize = 17;
ax.XAxis.FontSize = 17;
filename_temp = strcat(draft_output_path,'constructingCTCnonrefundable_stylized.png');
delete(filename_temp);
pause(5);
exportgraphics(hFig,filename_temp); 

% Figure 4(c)
close(figure(5)); hFig=figure(5);
h4 = plot(income,ACTC_level(:),'LineWidth',6.0,'Color',[0.4 0.4 0.4]);   h4.Color(4) = 0.4; hold on;     
h1 = plot(income,(0*income + 1).*max_refundable_credit_per_child,'LineWidth',2.0,'LineStyle',":"); 
h2 = plot(income,residual(:),'LineWidth',2.0,'Color',[0.6350 0.0780 0.1840],'LineStyle',"-.");  
h3 = plot(income,max(refundability_rate*(income - refundability_threshold),0),'LineWidth',2.0,'Color',[0.4940 0.1840 0.5560],'LineStyle',":");  
ylim([ylim_min,ylim_max]); xlim([xlim_min,xlim_max]); 
lgd=legend('$CTC_{r}$','Max refundable credit' ,'Residual nonrefundable credit' ,'Phase-in refundable amount','Location','NorthEast','NumColumns',1,'FontSize',14); 
set(lgd,'Box','off'); axis square;
ylabel('Credit level','Interpreter','latex','FontSize',17); 
xlabel('Pretax income $y$','Interpreter','latex','FontSize',17); 
xticks(''); xticklabels({'' });
yticks(0); 
ax= gca;
ax.YAxis.FontSize = 17;
ax.XAxis.FontSize = 17;
filename_temp = strcat(draft_output_path,'constructingACTCrefundable_stylized.png');
delete(filename_temp);
pause(5);
exportgraphics(hFig,filename_temp); 

%% --- Section 4 Parameterization
% ---> Table 2: Internally calibrated parameters  
Panel_label_text           = {'\textbf{Panel A: Jointly}', '\textbf{calibrated}', '', '', '', '','','\midrule \textbf{Panel B: Set}', '\textbf{proportionally}'}';
Parameter_Symbol_text      = {'$\psi$','$\lambda_{\theta}$','$b$','$\mu_{N}$','$\sigma_{k}^{2}$','$\rho_{k}$','$\zeta_{P}$','$\theta_{n}$','$\eta$'}';
Parameter_Description_text = {'Marginal disutility non-leisure time','Skill scaling factor','Altruism coefficient (share $\beta$)','Ave. application cost (share $\overline{y}_{pop}$)','Variance of $\log\left(\theta_{k}\right)$','Intergenerational persistence of skill','SS replacement rate','Childcare productivity','Childcare pre-policy price ratio'}';
Moment_Description_text    = {'Age 25-55 average hours labor $\ell$','Age 20 average hours childcare $n$','Age 20 Corr$\left(\theta_{k}^{a*}, y^{*}\right)$','Age 20 share receiving CCDF','Age 25-34 $\log\left(y\right)$ p50-p10','Age 20 Corr$\left(\theta_{k},\theta_{a}\right)$','SS spending (share output)','Age 20 workers ave. log prod. ratio','Age 20 workers price ratio'};
DataMoment_values_print  = DataMoment_values_policy_mat(:,Baseline_index)'; DataMoment_values_print(7) = 0.01*DataMoment_values_print(7);
ModelMoment_values_print = ModelMoment_values_policy_mat(:,Baseline_index)';  
Parameter_values_print  = [psi lambda_I b/beta chi_c_fraction varlogthetak initial_corr_par pension_rep_rate thetan_policy_mat(1,1,Baseline_index) pn_ratio_adjusted_policy_mat(1,1,Baseline_index)]';
T_tex= []; T_tex = table(Panel_label_text(:),Parameter_Symbol_text(:),Parameter_Description_text(:),Parameter_values_print(:),Moment_Description_text(:),DataMoment_values_print(:),ModelMoment_values_print(:),...
    'VariableNames',{'\textbf{Category}','\textbf{Sym.}','\textbf{Parameter description}','\textbf{Value}','\textbf{Moment description}','\textbf{Data}','\textbf{Model}'});
% For tex file called by manuscript:
texfilename_temp = strcat(draft_output_path,'Draft_tables_main_internally_calibrated.tex');
delete(texfilename_temp);
table2latex_formatted_egm(T_tex,7,tex_table_number_format,0,texfilename_temp);
disp('   '); disp('Table 2'); disp('   ');  disp(T_tex); 

%% --- Section 5 Model Fit: Figures 4 and 5 and Table 3
% ---> Figure 6 (a) and (b): Application and receipt: 2-D conditional rates. Don't show eligibility, it is a weird object.
% CCDF eligibility/application/receipt heatmaps
% binning_variable_index = 1: Bin1 = Thetaa , Bin2 = thetak
% binning_variable_index = 2: Bin1 = y , Bin2 = thetak
% binning_variable_index = 3: Bin1 = thetaa , Bin2 = fc
% binning_variable_index = 4: Bin1 = y , Bin2 = fc 
 
x_discrete = repmat(linspace(1,number_bins,number_bins),[number_bins 1]); 
x_discrete = x_discrete(:);
y_discrete = repmat(linspace(1,number_bins,number_bins),[1 number_bins])';

for binning_variable_index = [1 3]
    hFig = figure(binning_variable_index*10);
    if binning_variable_index == 1
        filename_temp = strcat(draft_output_path,'FigCCDF_thetaa_thetak.png');
    elseif binning_variable_index == 3
        filename_temp = strcat(draft_output_path,'FigCCDF_thetaa_fixedcost.png');
    end  
    for graphing_var_index = 1:3          
        subplot(1,3,graphing_var_index);
        if binning_variable_index == 1 
            xlabeltext = 'Adult skill'; ylabeltext = 'Child skill endowment'; 
        elseif binning_variable_index == 3
            xlabeltext = 'Adult skill'; ylabeltext = 'Application cost'; 
        end  
        if graphing_var_index == 1
            CCDF_pct_bin_temp = 100*squeeze(share_eligible_ccdf_2bin(binning_variable_index,:,:,1))'; % orginal: row is thetaa/incq, column is thetak; this makes row thetak, column thetaa/incq
            texttitle = 'Eligible (fixed labor)';
        elseif graphing_var_index == 2
            CCDF_pct_bin_temp = 100*squeeze(share_apply_ccdf_wfc_2bin(binning_variable_index,:,:,1))'; % orginal: row is thetaa/incq, column is thetak; this makes row thetak, column thetaa/incq
            texttitle = 'Applied';
        else
            CCDF_pct_bin_temp = 100*squeeze(share_received_ccdf_2bin(binning_variable_index,:,:,1))'; % orginal: row is thetaa/incq, column is thetak; this makes row thetak, column thetaa/incq
            texttitle = 'Received';
        end
        tbl = table(x_discrete,y_discrete,CCDF_pct_bin_temp(:), 'VariableNames', {'x', 'y', 'z'}); 
        h = heatmap(tbl,'x','y','ColorVariable','z','ColorMethod','mean', 'FontName', 'Times New Roman');xlabel(xlabeltext); ylabel(ylabeltext); 
        set(gcf, 'Position',  [100,100,1100,350]);
        h.ColorbarVisible = 'off';
        h.NodeChildren(3).YDir='normal';  
        h.MissingDataLabel = ' ';
        h.MissingDataColor = [1 1 1];
        h.CellLabelFormat = '%.0f'; 
        h.Title = texttitle;
        h.FontSize = 18; 
        h.FontName = font_name;     
    end
    delete(filename_temp); 
    pause(5) 
    exportgraphics(hFig,filename_temp);
end

% ---> Figure 7: CTC and CCDF distribution of spending and recipients, model v data 
% Figure 3(a): CTC distribution of spending and recipients in model v data
hFig = figure(6);   
subplot(1,2,1);
b1 = bar([ squeeze(amt_ctc_bin(4,:,1,1)./sum(amt_ctc_bin(4,:,1,1)))'  sharespendingctc(:) ],0.8,"FaceAlpha",0.5,'FaceColor','flat' ); 
grid on;  axis square;
xlabel('Pretax income bin','Interpreter','latex'); 
ylim([0 1.0]); ylabel('Share of spending','Interpreter','latex'); ytickformat('%.1f'); 
set(gca,'Fontsize',fontsz,'FontName',font_name,'xcolor','k','ycolor','k','TickLength',[0.0,0.0]);
hleglines = [b1(1) b1(2)]; 
title('\textbf{Share of spending}');
b1(2).CData =  0.6*[0 0.6 0.3];  
lgd = legend(hleglines,'Model','Data','Interpreter','latex','Location','NorthEast','NumColumns',1,'FontSize',12);
legend boxoff;
subplot(1,2,2);
CTC_share_bin_temp = squeeze(mass_ctc_bin(4,:,1,1))';
CTC_share_bin_temp = CTC_share_bin_temp./sum(CTC_share_bin_temp(:));
b1 = bar([CTC_share_bin_temp sharereceiptctc(:) ],0.8,"FaceAlpha",0.5,'FaceColor','flat' ); 
grid on;  axis square;
xlabel('Pretax income bin','Interpreter','latex'); 
ylim([0 1]); ylabel('Share of recipients','Interpreter','latex'); ytickformat('%.1f'); 
set(gca,'Fontsize',fontsz,'FontName',font_name,'xcolor','k','ycolor','k','TickLength',[0.0,0.0]);
hleglines = [b1(1) b1(2)]; 
b1(2).CData =  0.6*[0 0.6 0.3];  
title('\textbf{Share of recipients}'); 
lgd = legend(hleglines,'Model','Data','Interpreter','latex','Location','NorthEast','NumColumns',1,'FontSize',12); 
legend boxoff;
filename_temp = strcat(draft_output_path,'FigCTC_SpendingShare_ybin_data_and_model.png');
delete(filename_temp);
pause(5);
exportgraphics(hFig,filename_temp); 
% Figure 3(b): CCDF distribution of spending and recipients in model v data
hFig = figure(7);   
subplot(1,2,1);
b1 = bar([ squeeze(amt_ccdf_bin(4,:,1,1)./sum(amt_ccdf_bin(4,:,1,1)))'  sharespendingccdf(:) ],0.8,"FaceAlpha",0.5,'FaceColor','flat' ); 
grid on;  axis square;
xlabel('Pretax income bin','Interpreter','latex'); 
ylim([0 1]); ylabel('Share of spending','Interpreter','latex'); ytickformat('%.1f'); 
set(gca,'Fontsize',fontsz,'FontName',font_name,'xcolor','k','ycolor','k','TickLength',[0.0,0.0]);
hleglines = [b1(1) b1(2)]; 
title('\textbf{Share of spending}');
lgd = legend(hleglines,'Model','Data','Interpreter','latex','Location','NorthEast','NumColumns',1,'FontSize',12);
legend boxoff;
subplot(1,2,2);
CCDF_share_bin_temp = squeeze(mass_ccdf_bin(4,:,1,1))';
CCDF_share_bin_temp = CCDF_share_bin_temp./sum(CCDF_share_bin_temp(:));
b1 = bar([CCDF_share_bin_temp sharereceiptccdf(:) ],0.8,"FaceAlpha",0.5,'FaceColor','flat' ); 
grid on;  axis square;
xlabel('Pretax income bin','Interpreter','latex'); 
ylim([0 1]); ylabel('Share of recipients','Interpreter','latex'); ytickformat('%.1f'); 
set(gca,'Fontsize',fontsz,'FontName',font_name,'xcolor','k','ycolor','k','TickLength',[0.0,0.0]);
hleglines = [b1(1) b1(2)]; 
title('\textbf{Share of recipients}'); 
lgd = legend(hleglines,'Model','Data','Interpreter','latex','Location','NorthEast','NumColumns',1,'FontSize',12); 
legend boxoff;
filename_temp = strcat(draft_output_path,'FigCCDF_SpendingShare_ybin_data_and_model.png');
delete(filename_temp);
pause(5);
exportgraphics(hFig,filename_temp); 

% ---> Table 3: Spending size model baseline
Data_source_text = {'\citetalias{IRSSOIT332017}','\citet{HHS2019a,HHS2019b,HHS2020}','\citetalias{IRSSOIT332017}','\citet{TANFReport2015}'};
Row_label_text = {'Child Tax Credit (CTC)','Child Care and Development Fund (CCDF)','Earned Income Tax Credit (EITC)','Temporary Assistance for Needy Families (TANF)'};
DataMoment_values_print  = [0.27 0.03 0.36  0.02];
ModelMoment_values_print = [Spending_pctage_of_GDP_policy_mat([3 1 2 4],Baseline_index)]';
T_tex= []; T_tex = table(Row_label_text(:),DataMoment_values_print(:),ModelMoment_values_print(:),Data_source_text(:),'VariableNames',{'\textbf{Policy}','\textbf{Data}','\textbf{Model}','\textbf{Data source}'});
% For tex file called by manuscript:
texfilename_temp = strcat(draft_output_path,'DraftTablesSpendingSize.tex');
delete(texfilename_temp);
table2latex_formatted_egm(T_tex,5,tex_table_number_format,0,texfilename_temp);
disp('   '); disp('Table 3'); disp('   '); disp(T_tex); 
%% --- Section 6: Figure 8, Tables 4, 5, 6 and 7
% ---> Figure 8: CTC 2017 TCJA expansion (stylized) 
% Use input parameters to make transfers in dollar amounts as a function of income in dollar amounts
n_bins_temp = 10000;
income = linspace(0,550000,n_bins_temp);  
% CTC using model parameterization - per child per year 
refundability_rate = 0.15;
phaseout_rate      = 0.05;
lambda_y_ctc = (US_yp50*(GE_objects_policy_mat(5,1)^(1/tau_y))/GE_objects_policy_mat(4,1))^(tau_y); % break-even income level at the model baseline using model output with model yp50 and US median income if 57617.  
tax_liability  = max(income - lambda_y_ctc*(income).^(1-tau_y),0);
CTC_level = []; ACTC_level= []; CTC_tot= []; residual = []; ctc_step1_graphing= [];
for policy_index = 1:2
    if policy_index == 1
        % Model baseline parameters weighting across family structures:
        max_benefit_per_child(policy_index) = 1000 ;
        max_refundable_credit_per_child(policy_index) = 1000 ;
        refundability_threshold(policy_index) = 3000 ;
        phaseout_threshold(policy_index)  = 1000*(0.21*75  + 0.79*0.5*110);
    else
        % 2018 expansion parameters: 
        max_benefit_per_child(policy_index) = 2000;
        max_refundable_credit_per_child(policy_index) = 1400;
        refundability_threshold(policy_index) = 2500;
        phaseout_threshold(policy_index) = 200000;
    end
    % Nonrefundable 
    constraint_1             = max_benefit_per_child(policy_index) - phaseout_rate.*(income - phaseout_threshold(policy_index)).*(income>= phaseout_threshold(policy_index));
    constraint_2             = tax_liability; 
    CTC_level(:,policy_index) = max(min(constraint_1(:),constraint_2(:)),0);
    % Refundable
    constraint_3(:,policy_index) = max(constraint_1(:) - CTC_level(:,policy_index),0);
    constraint_4(:,policy_index) = max_refundable_credit_per_child(policy_index)*ones(n_bins_temp,1);
    constraint_5(:,policy_index) = refundability_rate*income(:);
    constraint3_4_aux = min(constraint_3(:,policy_index),constraint_4(:,policy_index));
    ACTC_level(:,policy_index) = max(min(constraint3_4_aux,constraint_5(:,policy_index)),0);
    % total
    CTC_tot(:,policy_index)    = CTC_level(:,policy_index) + ACTC_level(:,policy_index);
end 
 
close all;
hFig=figure(8); 
h1 = plot(income,CTC_tot(:,1),'LineWidth',2.0,'Color', [0 0.6 0.3]);  
hold on; ylabel({'Annual dollars per child' },'Color','k','Interpreter','latex','FontSize',17);  
set(gca, 'XColor','k', 'YColor','k')
h2 = plot(income,CTC_tot(:,2),'LineWidth',2.0,'Color', [0 0.6 0.3],'LineStyle',":");  hold on;   
ylim([0,3500]);  yticks([0 1000 2000 3000 ]);  yticklabels({0 '1k' '2k' '3k' });  
xlim([0,255000]); xticks(1000*[0 50  150  250  ]);  xticklabels({'0' '50k' '150k'  '250k'  });   xlabel({'Pretax income'},'Interpreter','latex','FontSize',17); 
set(gca,'Fontsize',20,'FontName',font_name,'xcolor','k','ycolor','k' ); 
lgd=legend('Baseline','Expansion','Location','NorthEast','NumColumns',1,'Interpreter','latex','FontSize',17); 
title(lgd,'\underline{\textbf{CTC policy}}','FontWeight','bold','FontSize',17);
set(lgd,'Box','off'); axis square  ; % grid on;
filename_temp = strcat(draft_output_path,'Figillustration_CTC_expansion.png');
delete(filename_temp);
pause(5);
exportgraphics(hFig,filename_temp);

% ---> Table 4: Main policy experiment table stationary steady state changes
% For tex file called by manuscript:
Atemp = []; Atemp =  round(Array_Policy_counterfactuals(Array_rows_vec_draft,[Baseline_index 2 3]),tex_table_number_rounding); % rounding avoids have "-0.00" as a value, instead it is just 0.
T_tex= []; T_tex = table(Rownames_AggregatesPanels',Rownames_AggregatesVars',Atemp(:,1),Atemp(:,2),Atemp(:,3),'VariableNames',Columnnames_Aggregates); 
texfilename_temp = strcat(draft_output_path,'DraftTablesAggChanges.tex');
delete(texfilename_temp);
table2latex_formatted_egm(T_tex,3,tex_table_number_format,0,texfilename_temp);
disp('   '); disp('Table 4'); disp('   ');disp(T_tex);disp(T_tex);   

% ---> Table 5: Main experiment skill distribution 
% For tex file called by manuscript:
Atemp = []; Atemp =  round(Array_Policy_counterfactuals(Array_rows_vec_skilldist,[Baseline_index 2 3]),3); % a little more precision than aggregate changes
T_tex= []; T_tex = table(Rownames_SkillDistPanels',Rownames_SkillDistVars',Atemp(:,1),Atemp(:,2),Atemp(:,3),'VariableNames',Columnnames_Aggregates); 
texfilename_temp = strcat(draft_output_path,'DraftTablesSkillDist.tex');
delete(texfilename_temp);
table2latex_formatted_egm(T_tex,3,'%.3f',0,texfilename_temp);
 disp('   '); disp('Table 5'); disp('   '); disp(T_tex); 

% ---> Table 6: Decomposition of newborn and new adult welfare changes
% ---> Welfare change decomposition for main experiments 
V_J = []; V_A = []; V_L = []; V_tot =[];
EV_baseline = [];EV_J=[];   EV_A= []; EV_L=[]; EV_P=[]; EV_D = []; EV_tot=[]; 
kappa_adults = []; ave_share_kappa_vec=[]; Welfareadults_kappas = [];
kappa_nb = []; ave_share_kappa_nb_ave_vec= []; Wnewborns_kappas=[];
dist_check_mat = [];

for Policy_vec_index = [Baseline_index 2 3]  

    % Joint distribution with old policy functions and adult skill distribution but new family policy rules
    Omega_dist_temp = zeros(n_types,J);
    for type_index = 1:n_types 
        theta_index  = type_mat(type_index,1);
        thetak_index = type_mat(type_index,2); 
        cc_r_index   = type_mat(type_index,3); 
        cc_fc_index  = type_mat(type_index,4);  
        for age = 1:J  
            if cc_r_index == 1 % incorporate application choices into distribution over ccdf application/receipt/no app distribution
                probccstatus = (ccdf_app_opt_policy_mat(type_index,age,Baseline_index) == 1); % did not apply 
            elseif cc_r_index == 2
                probccstatus = (1-CCDF_opt_policy_mat(1,6,Policy_vec_index))*(ccdf_app_opt_policy_mat(type_index,age,Baseline_index) == 2); % prob. did not receive || applied
            else  
                probccstatus = CCDF_opt_policy_mat(1,6,Policy_vec_index)*(ccdf_app_opt_policy_mat(type_index,age,Baseline_index)  == 2); % prob. did receive || applied  
            end
            probkid    = thetak_dist(theta_index,thetak_index);
            probparent = skill_dist_policy_mat(theta_index,Baseline_index);
            probage    = 1/J;
            probfc     = chi_c_eps_dist(cc_fc_index);
            Omega_dist_temp(type_index,age) = probfc*probccstatus*probkid*probparent*probage;
        end
    end
    Omega_dist_new_policy_rules_policy_mat(:,:,Policy_vec_index) = Omega_dist_temp;

    % Joint distribution with old adult skill distribution but new family policy rules and new application choice
    Omega_dist_temp = zeros(n_types,J);
    for type_index = 1:n_types 
        theta_index  = type_mat(type_index,1);
        thetak_index = type_mat(type_index,2); 
        cc_r_index   = type_mat(type_index,3); 
        cc_fc_index  = type_mat(type_index,4);  
        for age = 1:J  
            if cc_r_index == 1 % incorporate application choices into distribution over ccdf application/receipt/no app distribution
                probccstatus = (ccdf_app_opt_policy_mat(type_index,age,Policy_vec_index) == 1); % did not apply 
            elseif cc_r_index == 2
                probccstatus = (1-CCDF_opt_policy_mat(1,6,Policy_vec_index))*(ccdf_app_opt_policy_mat(type_index,age,Policy_vec_index) == 2); % prob. did not receive || applied
            else  
                probccstatus = CCDF_opt_policy_mat(1,6,Policy_vec_index)*(ccdf_app_opt_policy_mat(type_index,age,Policy_vec_index)  == 2); % prob. did receive || applied  
            end
            probkid    = thetak_dist(theta_index,thetak_index);
            probparent = skill_dist_policy_mat(theta_index,Baseline_index);
            probage    = 1/J;
            probfc     = chi_c_eps_dist(cc_fc_index);
            Omega_dist_temp(type_index,age) = probfc*probccstatus*probkid*probparent*probage;
        end
    end
    Omega_dist_new_app_choice_and_policy_rules_policy_mat(:,:,Policy_vec_index) = Omega_dist_temp;

    % Joint distribution with all changes
    Omega_dist_temp = zeros(n_types,J);
    for type_index = 1:n_types 
        theta_index  = type_mat(type_index,1);
        thetak_index = type_mat(type_index,2); 
        cc_r_index   = type_mat(type_index,3); 
        cc_fc_index  = type_mat(type_index,4);  
        for age = 1:J  
            if cc_r_index == 1 % incorporate application choices into distribution over ccdf application/receipt/no app distribution
                probccstatus = (ccdf_app_opt_policy_mat(type_index,age,Policy_vec_index) == 1); % did not apply 
            elseif cc_r_index == 2
                probccstatus = (1-CCDF_opt_policy_mat(1,6,Policy_vec_index))*(ccdf_app_opt_policy_mat(type_index,age,Policy_vec_index) == 2); % prob. did not receive || applied
            else  
                probccstatus = CCDF_opt_policy_mat(1,6,Policy_vec_index)*(ccdf_app_opt_policy_mat(type_index,age,Policy_vec_index)  == 2); % prob. did receive || applied  
            end
            probkid    = thetak_dist(theta_index,thetak_index);
            probparent = skill_dist_policy_mat(theta_index,Policy_vec_index);
            probage    = 1/J;
            probfc     = chi_c_eps_dist(cc_fc_index);
            Omega_dist_temp(type_index,age) = probfc*probccstatus*probkid*probparent*probage;
        end
    end
    Omega_dist_check_policy_mat(:,:,Policy_vec_index) = Omega_dist_temp;
    dist_check_mat(Policy_vec_index) = max(max(abs(Omega_dist_check_policy_mat(:,:,Policy_vec_index) - Omega_dist_policy_mat(:,:,Policy_vec_index))));

    % Aggregate averages:
    C_ave_policy_mat(Policy_vec_index)   = sum(Omega_dist_policy_mat(:,:,Policy_vec_index).*c_opt_policy_mat(:,:,Policy_vec_index),'all');
    Q_ave_policy_mat(Policy_vec_index)   = sum(Omega_dist_policy_mat(:,:,Policy_vec_index).*q_opt_policy_mat(:,:,Policy_vec_index),'all');
    H_ave_policy_mat(Policy_vec_index)   = sum(Omega_dist_policy_mat(:,:,Policy_vec_index).*h_opt_policy_mat(:,:,Policy_vec_index),'all');    

    % Age profile of consumption
    C_ave_age_policy_mat(:,Policy_vec_index) = sum(Omega_dist_policy_mat(:,:,Baseline_index).*c_opt_policy_mat(:,:,Policy_vec_index),1);
    C_ave_age_dist_policy_mat(:,Policy_vec_index) = C_ave_age_policy_mat(:,Policy_vec_index)/sum(C_ave_age_policy_mat(:,Policy_vec_index),1);

    % New quantities for counterfactual outcomes
    Vkidterm_policy_mat(:,Policy_vec_index)     = Vkid_policy_mat(theta_opt_policy_mat(:,1,Policy_vec_index),Policy_vec_index);
    Vkidterm_ave_theta_only_policy_mat(:,Policy_vec_index) = sum(J*Omega_dist_policy_mat(:,1,Policy_vec_index).*Vkid_policy_mat(theta_opt_policy_mat(:,1,Policy_vec_index),Baseline_index));
 
    for age = 1:J
        hat_J_c_opt_policy_mat(:,age,Policy_vec_index) = max(c_opt_policy_mat(:,age,Baseline_index).*C_ave_age_dist_policy_mat(age,Policy_vec_index)./C_ave_age_dist_policy_mat(age,Baseline_index),0);
        if age<10
            hat_J_h_opt_policy_mat(:,age,Policy_vec_index) = h_opt_policy_mat(:,age,Baseline_index);
            hat_J_q_opt_policy_mat(:,age,Policy_vec_index) = q_opt_policy_mat(:,age,Baseline_index);
        else
            hat_J_h_opt_policy_mat(:,age,Policy_vec_index) = 0*h_opt_policy_mat(:,age,Baseline_index);
            hat_J_q_opt_policy_mat(:,age,Policy_vec_index) = 0*q_opt_policy_mat(:,age,Baseline_index);
        end
    end
    hat_J_Vkidterm_policy_mat(:,Policy_vec_index)      = Vkidterm_policy_mat(:,Baseline_index);
    
    recursive_c_temp = hat_J_c_opt_policy_mat(:,:,Policy_vec_index);
    recursive_h_temp = hat_J_h_opt_policy_mat(:,:,Policy_vec_index);
    recursive_q_temp = hat_J_q_opt_policy_mat(:,:,Policy_vec_index);
    recursive_Vk_temp = hat_J_Vkidterm_policy_mat(:,Policy_vec_index);

    % Marginal effect of change in average level of child skill outcome in addition to change in age distribution and average level of consumption
    for age = 1:J
        hat_A_c_opt_policy_mat(:,age,Policy_vec_index) = recursive_c_temp(:,age);
        if age<10
            hat_A_h_opt_policy_mat(:,age,Policy_vec_index) = recursive_h_temp(:,age);
            hat_A_q_opt_policy_mat(:,age,Policy_vec_index) = recursive_q_temp(:,age);
        else
            hat_A_h_opt_policy_mat(:,age,Policy_vec_index) = 0*recursive_h_temp(:,age);
            hat_A_q_opt_policy_mat(:,age,Policy_vec_index) = 0*recursive_q_temp(:,age);
        end
    end
    hat_A_Vkidterm_policy_mat(:,Policy_vec_index)      = recursive_Vk_temp(:).*Vkidterm_ave_theta_only_policy_mat(:,Policy_vec_index)./Vkidterm_ave_theta_only_policy_mat(:,Baseline_index);
    
    recursive_c_temp = hat_A_c_opt_policy_mat(:,:,Policy_vec_index);
    recursive_h_temp = hat_A_h_opt_policy_mat(:,:,Policy_vec_index);
    recursive_q_temp = hat_A_q_opt_policy_mat(:,:,Policy_vec_index);
    recursive_Vk_temp = hat_A_Vkidterm_policy_mat(:,Policy_vec_index);
    
    % Marginal effect of change in average level of consumption c, work h, and q
    for age = 1:J
        hat_L_c_opt_policy_mat(:,age,Policy_vec_index) = recursive_c_temp(:,age).*(C_ave_policy_mat(Policy_vec_index)/C_ave_policy_mat(Baseline_index));
        if age<10
            hat_L_h_opt_policy_mat(:,age,Policy_vec_index) = recursive_h_temp(:,age).*(H_ave_policy_mat(Policy_vec_index)/H_ave_policy_mat(Baseline_index));
            hat_L_q_opt_policy_mat(:,age,Policy_vec_index) = recursive_q_temp(:,age).*(Q_ave_policy_mat(Policy_vec_index)/Q_ave_policy_mat(Baseline_index));
        else
            hat_L_h_opt_policy_mat(:,age,Policy_vec_index) = 0*recursive_h_temp(:,age);
            hat_L_q_opt_policy_mat(:,age,Policy_vec_index) = 0*recursive_q_temp(:,age);
        end
    end
    hat_L_Vkidterm_policy_mat(:,Policy_vec_index)      = recursive_Vk_temp(:);

    % Constructing value function  
    for age = 1:J
        flag_feasible = (hat_J_c_opt_policy_mat(:,age,Policy_vec_index)>0).*(hat_J_h_opt_policy_mat(:,age,Policy_vec_index)+hat_J_q_opt_policy_mat(:,age,Policy_vec_index)<=1);
        utility_J(:,age,Policy_vec_index) = -10^8;
        utility_J(flag_feasible==1,age,Policy_vec_index)   = log(hat_J_c_opt_policy_mat(flag_feasible==1,age,Policy_vec_index)/((1+0.3*(age<=4)))) - (psi/(1+(1/Frisch)))*(hat_J_h_opt_policy_mat(flag_feasible==1,age,Policy_vec_index)+hat_J_q_opt_policy_mat(flag_feasible==1,age,Policy_vec_index)).^(1+(1/Frisch)) + (age==1)*b*hat_J_Vkidterm_policy_mat(flag_feasible==1,Baseline_index);
        
        flag_feasible = (hat_A_c_opt_policy_mat(:,age,Policy_vec_index)>0).*(hat_A_h_opt_policy_mat(:,age,Policy_vec_index)+hat_A_q_opt_policy_mat(:,age,Policy_vec_index)<=1);
        utility_A(:,age,Policy_vec_index)    = -10^8;
        utility_A(flag_feasible==1,age,Policy_vec_index)   = log(hat_A_c_opt_policy_mat(flag_feasible==1,age,Policy_vec_index)/((1+0.3*(age<=4)))) - (psi/(1+(1/Frisch)))*(hat_A_h_opt_policy_mat(flag_feasible==1,age,Policy_vec_index)+hat_A_q_opt_policy_mat(flag_feasible==1,age,Policy_vec_index)).^(1+(1/Frisch)) + (age==1)*b*hat_A_Vkidterm_policy_mat(flag_feasible==1,Policy_vec_index);            
        
        flag_feasible = (hat_L_c_opt_policy_mat(:,age,Policy_vec_index)>0).*(hat_L_h_opt_policy_mat(:,age,Policy_vec_index)+hat_L_q_opt_policy_mat(:,age,Policy_vec_index)<=1);
        utility_L(:,age,Policy_vec_index)    = -10^8;
        utility_L(flag_feasible==1,age,Policy_vec_index)   = log(hat_L_c_opt_policy_mat(flag_feasible==1,age,Policy_vec_index)/((1+0.3*(age<=4)))) - (psi/(1+(1/Frisch)))*(hat_L_h_opt_policy_mat(flag_feasible==1,age,Policy_vec_index)+hat_L_q_opt_policy_mat(flag_feasible==1,age,Policy_vec_index)).^(1+(1/Frisch)) + (age==1)*b*hat_L_Vkidterm_policy_mat(flag_feasible==1,Policy_vec_index);
        
        flag_feasible = (c_opt_policy_mat(:,age,Policy_vec_index)>0).*(h_opt_policy_mat(:,age,Policy_vec_index)+q_opt_policy_mat(:,age,Policy_vec_index)<=1);
        utility_tot(flag_feasible==1,age,Policy_vec_index) = -10^8;
        utility_tot(flag_feasible==1,age,Policy_vec_index) = log(c_opt_policy_mat(flag_feasible==1,age,Policy_vec_index)/((1+0.3*(age<=4)))) - (psi/(1+(1/Frisch)))*(h_opt_policy_mat(flag_feasible==1,age,Policy_vec_index)+q_opt_policy_mat(flag_feasible==1,age,Policy_vec_index)).^(1+(1/Frisch)) + (age==1)*b*Vkidterm_policy_mat(flag_feasible==1,Policy_vec_index);
    end

    V_J(:,J,Policy_vec_index) = utility_J(:,J,Policy_vec_index);
    V_A(:,J,Policy_vec_index) = utility_A(:,J,Policy_vec_index);
    V_L(:,J,Policy_vec_index) = utility_L(:,J,Policy_vec_index);
    V_tot(:,J,Policy_vec_index) = utility_tot(:,J,Policy_vec_index);
    for age = J-1:-1:1
        V_J(:,age,Policy_vec_index) = utility_J(:,age,Policy_vec_index)+ beta*V_J(:,age+1,Policy_vec_index);
        V_A(:,age,Policy_vec_index) = utility_A(:,age,Policy_vec_index)+ beta*V_A(:,age+1,Policy_vec_index);
        V_L(:,age,Policy_vec_index) = utility_L(:,age,Policy_vec_index)+ beta*V_L(:,age+1,Policy_vec_index);
        V_tot(:,age,Policy_vec_index) = utility_tot(:,age,Policy_vec_index)+ beta*V_tot(:,age+1,Policy_vec_index);
    end
    
    for age = 1:J
        EV_baseline(age,Policy_vec_index) = sum(J*Omega_dist_policy_mat(:,age,Baseline_index).*V_opt_realized_policy_mat(:,age,Baseline_index),'all');
        EV_J(age,Policy_vec_index)        = sum(J*Omega_dist_policy_mat(:,age,Baseline_index).*V_J(:,age,Policy_vec_index),'all');
        EV_A(age,Policy_vec_index)        = sum(J*Omega_dist_policy_mat(:,age,Baseline_index).*V_A(:,age,Policy_vec_index),'all');
        EV_L(age,Policy_vec_index)        = sum(J*Omega_dist_policy_mat(:,age,Baseline_index).*V_L(:,age,Policy_vec_index),'all');
        EV_P(age,Policy_vec_index)        = sum(J*Omega_dist_new_app_choice_and_policy_rules_policy_mat(:,age,Policy_vec_index).*V_opt_realized_policy_mat(:,age,Policy_vec_index),'all');
        EV_D(age,Policy_vec_index)        = sum(J*Omega_dist_policy_mat(:,age,Policy_vec_index).*V_opt_realized_policy_mat(:,age,Policy_vec_index),'all');
        EV_tot(age,Policy_vec_index)      = sum(J*Omega_dist_policy_mat(:,age,Policy_vec_index).*V_opt_realized_policy_mat(:,age,Policy_vec_index),'all');
    end
    EV_mat(1,:) = EV_J(:,Policy_vec_index);
    EV_mat(2,:) = EV_A(:,Policy_vec_index);
    EV_mat(3,:) = EV_L(:,Policy_vec_index);
    EV_mat(4,:) = EV_D(:,Policy_vec_index);
    EV_mat(5,:) = EV_D(:,Policy_vec_index);

    % Welfare changes for adults by age : 
    for age = 1:J
        kappa_adults(1,age,Policy_vec_index)     = exp((EV_mat(1,age)-EV_baseline(age,Baseline_index))/denomW(age)) - 1;
        kappa_adults(2,age,Policy_vec_index)     = exp((EV_mat(2,age)-EV_mat(1,age))/denomW(age)) - 1;
        kappa_adults(3,age,Policy_vec_index)     = exp((EV_mat(3,age)-EV_mat(2,age))/denomW(age)) - 1;
        kappa_adults(4,age,Policy_vec_index)     = exp((EV_mat(4,age)-EV_mat(3,age))/denomW(age)) - 1;
        kappa_adults(5,age,Policy_vec_index)     = exp((EV_mat(5,age)-EV_mat(4,age))/denomW(age)) - 1;
        kappa_adults(6,age,Policy_vec_index)     = (1+kappa_adults(1,age,Policy_vec_index))*(1+kappa_adults(2,age,Policy_vec_index))*(1+kappa_adults(3,age,Policy_vec_index))*(1+kappa_adults(4,age,Policy_vec_index))*(1+kappa_adults(5,age,Policy_vec_index))  -1;
        kappa_adults(7,age,Policy_vec_index)     = exp((EV_tot(age,Policy_vec_index)-EV_baseline(age,Baseline_index))/denomW(age)) - 1;          
        ave_share_kappa_vec(:,age,Policy_vec_index) = kappa_adults(:,age,Policy_vec_index)/abs(kappa_adults(end,age,Policy_vec_index));  % use abs=magnitude so that sign of share is contribution to total magnitude
        Welfareadults_kappas(:,age,Policy_vec_index)     = 100*kappa_adults(:,age,Policy_vec_index);
    end

    % Welfare changes for newborns - doe sthe same decomposition make sense as for adults? I'm not sure. It's not clear 
    % ==> Measure #2: Newborns (should be the same as adults age 1)   
    kappa_nb(1,Policy_vec_index)     = exp((EV_J(1,Policy_vec_index)-EV_baseline(1,Baseline_index))/denomW(1)) -1;
    kappa_nb(2,Policy_vec_index)     = exp((EV_A(1,Policy_vec_index)-EV_J(1,Policy_vec_index))/denomW(1)) -1;
    kappa_nb(3,Policy_vec_index)     = exp((EV_L(1,Policy_vec_index)-EV_A(1,Policy_vec_index))/denomW(1)) -1;
    kappa_nb(4,Policy_vec_index)     = exp((EV_P(1,Policy_vec_index)-EV_L(1,Policy_vec_index))/denomW(1)) -1;
    kappa_nb(5,Policy_vec_index)     = exp((EV_D(1,Policy_vec_index)-EV_P(1,Policy_vec_index))/denomW(1)) -1;
    kappa_nb(6,Policy_vec_index)     = (1+kappa_nb(1,Policy_vec_index))*(1+kappa_nb(2,Policy_vec_index))*(1+kappa_nb(3,Policy_vec_index))*(1+kappa_nb(4,Policy_vec_index))*(1+kappa_nb(5,Policy_vec_index)) - 1;  
    kappa_nb(7,Policy_vec_index)     = exp((EV_tot(1,Policy_vec_index)-EV_baseline(1,Baseline_index))/denomW(1)) -1;
    ave_share_kappa_nb_ave_vec(:,Policy_vec_index) = kappa_nb(:,Policy_vec_index)/abs(kappa_nb(end,Policy_vec_index)); 
    Wnewborns_kappas(:,Policy_vec_index) = 100*kappa_nb(:,Policy_vec_index); 

    % Check aggregate consumption 
    C_agg(1,Policy_vec_index) = sum(J*Omega_dist_policy_mat(:,:,Baseline_index).*hat_J_c_opt_policy_mat(:,:,Policy_vec_index),'all'); 
    C_agg(2,Policy_vec_index) = sum(J*Omega_dist_policy_mat(:,:,Baseline_index).*hat_A_c_opt_policy_mat(:,:,Policy_vec_index),'all'); 
    C_agg(3,Policy_vec_index) = sum(J*Omega_dist_policy_mat(:,:,Baseline_index).*hat_L_c_opt_policy_mat(:,:,Policy_vec_index),'all'); 
    C_agg(4,Policy_vec_index) = sum(J*Omega_dist_policy_mat(:,:,Policy_vec_index).*c_opt_policy_mat(:,:,Policy_vec_index),'all'); 
    C_agg(5,Policy_vec_index) = sum(J*Omega_dist_policy_mat(:,:,Policy_vec_index).*c_opt_policy_mat(:,:,Policy_vec_index),'all'); 
    C_agg(6,Policy_vec_index) = sum(J*Omega_dist_policy_mat(:,:,Baseline_index).*c_opt_policy_mat(:,:,Baseline_index),'all'); 
    C_agg(7,Policy_vec_index) = sum(J*Omega_dist_policy_mat(:,:,Policy_vec_index).*c_opt_policy_mat(:,:,Policy_vec_index),'all'); 
end 
squeeze(ave_share_kappa_vec(1:7,1,[2 3]));
ave_share_kappa_nb_ave_vec(1:7,[2 3]); 

T_NA = table(ave_share_kappa_vec([1 2 3 4 6],1,2),ave_share_kappa_vec([1 2 3 4 6],1,3),'RowNames',{'\textbf{Average age profile}','\textbf{Average child outcome}','}\textbf{Average levels}','\textbf{Distribution}','\textbf{Total}'},'VariableNames',{'\textbf{CTC}','\textbf{CCDF}'});
% For tex file called by manuscript:
model_output_temp = [ave_share_kappa_vec(:,1,2)';ave_share_kappa_vec(:,1,3)'];
RowNames_Decomp = {'\textbf{New adults}','\textbf{New adults}'}';
ColumnNames_Decomop = {'\textbf{Policy}','\textbf{(i) Age}','\textbf{(ii) Child}','\textbf{(iii) Levels}','\textbf{(iv) Dist.}','\textbf{Total}'};
Policy_description_text = {'\textbf{CTC}','\textbf{CCDF}'}'; 
% For tex file called by manuscript:
T_tex= []; T_tex = table(Policy_description_text,model_output_temp(:,1),model_output_temp(:,2),model_output_temp(:,3),model_output_temp(:,4),model_output_temp(:,6),'VariableNames',ColumnNames_Decomop); 
texfilename_temp = strcat(draft_output_path,'DraftTableWelfareDecompNB_NA.tex');
delete(texfilename_temp);
table2latex_formatted_egm(T_tex,2,tex_table_number_format,0,texfilename_temp);
disp('Welfare decomposition:'); disp('   '); disp('Table 6'); disp('   '); disp(T_tex); 
  