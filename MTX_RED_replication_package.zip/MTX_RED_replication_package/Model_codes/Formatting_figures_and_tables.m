% Loading processed code output:  
load([main_manuscript_path 'Processed_output\Processed_SteadyState_Output_Draft.mat']); % SS output
load([online_appendix_path 'Processed_output_online_appendix\Array_Policy_counterfactuals_C2_C3.mat']); % Array of App C.3 exercises
load([online_appendix_path 'Processed_output_online_appendix\Array_Policy_counterfactuals_C4.mat']); % Array of App C.4 exercises
load([online_appendix_path 'Processed_output_online_appendix\Array_Policy_counterfactuals_C5_1_and_2.mat']); % Array of App C.5 subsection 1 and 2 recalibration exercises (same model as benchmark but different targets)
load([online_appendix_path 'Processed_output_online_appendix\Array_Policy_counterfactuals_C5_3.mat']); % Array of App C.5 subsection 3 recalibration exercises (utility cost specification results)
load([online_appendix_path 'Processed_output_online_appendix\Array_CompStats_C1.mat']); % Calibration comparative statics
load([online_appendix_path 'Processed_output_online_appendix\Combined_array_tp_C3_6.mat']); % Transition path output

% Load empirical output in csv form
filename_temp = []; filename_temp = data_path + "share_spending_ccdf.csv"; Tccdf = []; Tccdf = readtable(filename_temp);
filename_temp = []; filename_temp = data_path + "share_spending_eitc.csv"; Teitc = []; Teitc = readtable(filename_temp);
filename_temp = []; filename_temp = data_path + "share_spending_ctc.csv"; Tctc = []; Tctc = readtable(filename_temp);
filename_temp = []; filename_temp = data_path + "share_recipients_ccdf.csv"; Tccdf_receipt = []; Tccdf_receipt = readtable(filename_temp);
filename_temp = []; filename_temp = data_path + "share_receipt_ctc.csv"; Tctc_receipt = []; Tctc_receipt = readtable(filename_temp);
filename_temp = []; filename_temp = data_path + "share_receipt_eitc.csv"; Teitc_receipt = []; Teitc_receipt = readtable(filename_temp);
filename_temp = []; filename_temp = data_path + "stats_yngch_cps_ccdf_recipients.csv"; Tcpsccdf = []; Tcpsccdf = readtable(filename_temp);

% Assign number of spending dist. bins
number_bins = size(Tctc,1); % the CTC has all the bins by construction  

% Create arrays from tables for graphing, spending and receipt distributions
sharespendingeitc  = zeros(number_bins,1); sharespendingeitc = table2array(Teitc(:,2));
sharespendingctc   = zeros(number_bins,1); sharespendingctc = table2array(Tctc(:,2));
sharespendingccdf  = zeros(number_bins,1); sharespendingccdf(1:size(Tccdf,1),1) = table2array(Tccdf(:,2)); % this data object only has values up to the bin represented in admin data

sharereceiptctc   = zeros(number_bins,1); sharereceiptctc(1:size(Tccdf,1),1) = table2array(Tctc_receipt(:,2));  
sharereceipteitc  = zeros(number_bins,1); sharereceipteitc(1:size(Tccdf,1),1) = table2array(Teitc_receipt(:,2));  
sharereceiptccdf  = zeros(number_bins,1); sharereceiptccdf(1:size(Tccdf,1),1) = table2array(Tccdf_receipt(:,2)); % this data object only has values up to the bin represented in admin data

% Figure formatting parameters:
fontsz = 15;
paper_unit = 'inches'; % 'inches', 'normalized', 'centimeters', 'points'
paper_size = [4 3]; % [width height]
paper_position = [0 0 4 3]; % [left bottom width height].
paper_orientation = 'landscape'; % 'portrait (default)', 'landscape'
font_name = 'Times New Roman'; % 'Helvetica', 'Times New Roman'
color_graph = [0.2 0.5 1.0];
color_mark  = [0.2 0.5 1.0];
set(groot,'DefaultAxesTickLabelInterpreter','latex');  
set(groot, 'DefaultTextInterpreter', 'latex')
set(groot, 'DefaultLegendInterpreter', 'latex')
set(groot, 'DefaultAxesTickLabelInterpreter', 'latex')
set(gca,'fontsize', fontsz)  
close all;

% Calibration comparative static: number of values per parameter
numexpar = 2;

% Table setup 
Baseline_index = 1;  

% ---> Select the rows you want to report; remember to adjust RowNames accordingly
Array_rows_vec           = [1 2 13 6 7 8 21 22 23 27 28 29 30 31 32]; 
Array_rows_vec_draft     = [1 2 5 6 7 8 21 22 23 27 30]; 
Array_rows_vec_skilldist = [13 15 10 11 12];  % Don't know whether to use logs or levels...  
rounding_parameter = 4; 
tex_table_number_format = '%.2f';
tex_table_number_rounding = 2;
 

% General objects for tabulations of multiple outputs
Rownames_AggregatesPanels = {'\textbf{Panel A: Government}','{\fontsize{7}{7}\selectfont $\Delta$ units: percentage point change}', '\midrule \textbf{Panel B: Aggregate quantities}','{\fontsize{7}{7}\selectfont  $\Delta$ units: percent change}',' ',' ','\midrule \textbf{Panel C: Welfare change in levels}','{\fontsize{7}{7}\selectfont  $\Delta$ units: percent of lifetime consumption}',' ','\midrule \textbf{Panel D: Share who gain}','{\fontsize{7}{7}\selectfont $\Delta$ units: share of group}'};
Rownames_AggregatesVars   = {'Government expenditures','Average tax rate ({\tiny at $y_{ave}$ baseline SS})', 'Average adult skill','Labor supply','Output','Consumption','Behind the veil of ignorance','New adults','All adults','New adults','All adults'};
Columnnames_Aggregates    = {'\textbf{Variable category}','\textbf{Variable description}','\textbf{Baseline}','\textbf{(1) CTC}','\textbf{(2) CCDF}'};

Rownames_AggregatesPanels_abbreviated = {'\textbf{Panel A: Government}','{\fontsize{7}{7}\selectfont $\Delta$ units: percentage point change}', '\midrule \textbf{Panel B: Agg. quantities}','{\fontsize{7}{7}\selectfont  $\Delta$ units: percent change}',' ',' ','\midrule \textbf{Panel C: $\Delta$ W in levels}','{\fontsize{7}{7}\selectfont  $\Delta$ units: percent of lifetime consumption}',' ','\midrule \textbf{Panel D: Share who gain}','{\fontsize{7}{7}\selectfont $\Delta$ units: share of group}'};
Rownames_AggregatesVars_abbreviated   = {'Govt. expenditures','Ave. tax rate ({\tiny at $y_{ave}$ baseline SS})', 'Ave. adult skill','Labor supply','Output','Consumption','Behind the veil of ignorance','New adults','All adults','New adults','All adults'};

Rownames_SkillDistPanels = {'\textbf{Panel A: Mean and overall inequality}','{\fontsize{7}{7}\selectfont $\Delta$ units: percent change (average) and levels (variance of log)}','\midrule \textbf{Panel B: Decile dispersion (log skill)}','{\tiny $\Delta$ units: levels}',' '};
Rownames_SkillDistVars   = {'Average','Variance of log','10th-1st','10th-5th','5th-1st'};
Columnnames_SkillDist    = {'\textbf{Variable category}','\textbf{Variable description}','\textbf{Baseline}','\textbf{(1) CTC}','\textbf{(2) CCDF}'};

Rownames_PEPanels = {'\textbf{Panel A: Levels}','{\fontsize{7}{7}\selectfont $\Delta$ units: percent change}', '\midrule \textbf{Panel B: Overall inequality}','{\tiny $\Delta$ units: levels}',' ','\midrule \textbf{Panel C: log(skill) percentile ratios}','{\tiny $\Delta$ units: levels}',' '};
Rownames_PEVars   = {'Behind the veil of ignorance','New adults','All adults'};
Columnnames_PECTC = {'\multicolumn{1}{l}{\textbf{Panel A: CTC}}','\multicolumn{1}{c}{\textbf{(1) GE}}','\multicolumn{1}{c}{\textbf{(2) PE}}','\multicolumn{1}{c}{\textbf{(3) $\mu\left(\theta_{a}\right)$}}','\multicolumn{1}{c}{\textbf{(4) $V_{k}^{a}$}}','\multicolumn{1}{c}{\textbf{(5) $\lambda_y$}}','\multicolumn{1}{c}{\textbf{(6) $p$}}','\multicolumn{1}{c}{\textbf{(7) Scaling}}','\multicolumn{1}{c}{\textbf{(8) Pension}}'};
Columnnames_PECCDF = {'\multicolumn{1}{l}{\textbf{Panel B: CCDF}}','\multicolumn{1}{c}{\textbf{(1) GE}}','\multicolumn{1}{c}{\textbf{(2) PE}}','\multicolumn{1}{c}{\textbf{(3) $\mu\left(\theta_{a}\right)$}}','\multicolumn{1}{c}{\textbf{(4) $V_{k}^{a}$}}','\multicolumn{1}{c}{\textbf{(5) $\lambda_y$}}','\multicolumn{1}{c}{\textbf{(6) $p$}}','\multicolumn{1}{c}{\textbf{(7) Scaling}}','\multicolumn{1}{c}{\textbf{(8) Pension}}'};
