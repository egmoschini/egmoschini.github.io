close all; clc;

%% APPENDIX C.1 - CALIBRATION COMPARATIVE STATICS
% Ordering of objects: 
% [h_hours n_hours rho_thetay CCDF_receipt p50_yparGRID - p10_yparGRID rho_initialskill 0.01*tot_G_spending_SS_policy_mat_pretax(Policy_vec_index) 0.000 pn/(sum(par_weights(:).*wage_aftx(:))/sum(par_weights(:).*(1-subsidy_correction(:))))]
% [psi lambda_I b chi_c_fraction varlogthetak initial_corr_par pension_rep_rate]
pct_change_model_moment = []; pct_change_model_moment = 100*(CalCompStat_Results_policy_mat_C1(1:7,:)./CalCompStat_Results_policy_mat_C1(1:7,1)-1);
pct_change_parameter = []; pct_change_parameter = 100*(CalCompStat_Parameters_policy_mat_C1./CalCompStat_Parameters_policy_mat_C1(:,1)-1);

vec_ex = []; ylim_mat = [];  xticks_mat = []; yticks_mat = [];
for index = 1:7
    min_vec_ex = numexpar*(index-1)+1; lower_vec = linspace(min_vec_ex,min_vec_ex-1+numexpar/2,numexpar/2);
    max_vec_ex = numexpar*index; upper_vec = linspace(max(lower_vec)+1,max_vec_ex,numexpar/2);
    vec_ex(index,:) = 1 + [lower_vec 0 upper_vec];
    ylim_mat(index,1) = 1.1*min(pct_change_model_moment(index,vec_ex(index,[1 numexpar+1])));
    ylim_mat(index,2) = 1.1*max(pct_change_model_moment(index,vec_ex(index,[1 numexpar+1])));
    if index == 1 % this one is too small for the proportion to give enough space
        ylim_mat(index,1) = -2+min(pct_change_model_moment(index,vec_ex(index,[1 numexpar+1])));
        ylim_mat(index,2) = 2+max(pct_change_model_moment(index,vec_ex(index,[1 numexpar+1])));
    end
    xticks_mat(index,:) = [-20 20];
    yticks_mat(index,:) = linspace(ylim_mat(index,1),0.99*ylim_mat(index,2),4);
end 
ylabel_vec = []; ylabel_vec = {'Labor supply','Childcare hours','Corr$(\theta_{k}^{a,*},Y)$','Share CCDF','p50-p10','Corr$(\theta_{k},\theta_{a})$','SS spending'};
xlabel_vec = []; xlabel_vec = {'$\psi$','$\lambda_{\theta}$ ','$b$','$\xi_{c}$','$\sigma^{2}_{k}$','$\rho_{k}$','$\zeta_{P}$'};

% ---> Figure C.1: Comparative static all
hFig = figure(20);
for j = 1:7
    subplot(2,4,j); 
    bar(pct_change_parameter(j,vec_ex(j,[1 numexpar+1])),pct_change_model_moment(j,vec_ex(j,[1 numexpar+1])),'LineWidth',1.2);  
    xlim([-50,50]); ylim([ylim_mat(j,1),ylim_mat(j,2)]);
    ytickformat('%.0f'); yticks([yticks_mat(j,:)]);  
    set(gca,'xtick',[xticks_mat(j,:)],'xticklabel',{'$-20\%$','$+20\%$'},'fontsize',14,'FontWeight','bold');
    title(ylabel_vec(j),'Interpreter','latex','FontSize',17);  
    ylabel('\% change','Interpreter','latex','FontSize',14); 
    xlabel(xlabel_vec(j),'Interpreter','latex','FontSize',14); 
    axis square; 
end
fontname(gcf,'Times');
hFig.WindowState = 'maximized';
filename_temp = strcat(draft_output_path,'CalibrationComparativeStaticsGE.png');
exportgraphics(hFig,filename_temp);  
close all;

%% Appendix C.2 - use baseline output from main exercises
% --> Table for intuition: CCDF recipient attributes vs. data
% This section of the code makes 2 tables for the draft. 1 is about sorting by model types in the baseline. 2 is about comparing relative attributes of CCDF recipients to the population of kids with similar age, the average subsidy rate among
% recipients, and the dollar value of CCDF in the Admin data (can also use aggregate spending data). 
% ---> Intuition for discussion in Section 5: CCDF uptake attributes in model baseline - evidence for selection along theta_a, theta_k, and fixed cost 
Columnnames   = {'\multicolumn{1}{l}{\textbf{Panel A: CTC}}', '\multicolumn{1}{c}{\textbf{5}}','\multicolumn{1}{c}{\textbf{25}}','\multicolumn{1}{c}{\textbf{45}}','\multicolumn{1}{c}{\textbf{65}}','\multicolumn{1}{c}{\textbf{85}}','\multicolumn{1}{c}{\textbf{105}}','\multicolumn{1}{c}{\textbf{Final}}'};
Rowvariables        = {'\multicolumn{1}{l}{{Application cost}}','\multicolumn{1}{l}{{Adult skill}}','\multicolumn{1}{l}{{Child initial skill}}'};
T_aux = []; T_aux = [ave_fixed_cost_AppC2_C3(:,1,1),ave_thetaa_AppC2_C3(:,1,1),ave_thetak_AppC2_C3(:,1,1) ]'; T_aux = round(T_aux,rounding_parameter); 
T = table(T_aux(:,1),T_aux(:,2),T_aux(:,3),T_aux(:,4),'RowNames',{'Application cost','Adult skill','Child initial skill'},'VariableNames',{'\multicolumn{1}{l}{{Pop}}','\multicolumn{1}{l}{{El}}','\multicolumn{1}{l}{{App}}','\multicolumn{1}{l}{{Recpt}}'});
T.Properties.DimensionNames(1) = "Sorting into CCDF application/receipt";
disp('   '); disp('Sorting into CCDF application/receipt'); disp('   '); disp(T); 

% ---> Table C.13: Attributes of CCDF recipients model vs data
T_aux = []; T_aux = [CCDF_attributes_AppC2_C3(1,:);CCDF_attributes_AppC2_C3(2,:)]'; T_aux = round(T_aux,rounding_parameter); T_aux(3,:) = T_aux(3,:)/1000; 
% For tex file called by manuscript:
Rownames_vec = {'\textbf{Average income as a share of pop. average}','\textbf{Average subsidy rate}','\textbf{Average transfer (1000s USD, per year per child)}'}';
Taux_tex = table(Rownames_vec,T_aux(:,1),T_aux(:,2),'VariableNames',{'\textbf{Variable description}','\multicolumn{1}{r}{\textbf{Data}}','\multicolumn{1}{r}{\textbf{Model}}'});
texfilename_temp = strcat(draft_output_path,'CCDFSelectionAttributesComparison.tex');
table2latex_formatted_egm(Taux_tex,2,'%.2f',0,texfilename_temp);
disp('   '); disp('Table C.13: Attributes of CCDF recipients: Data vs. Model'); disp('   '); disp(Taux_tex); 

% --> Figure C.2(a): Baseline investment by thetak and thetaa bin 
number_bins= 4;
hFig = figure(21);  
for j = 1:4
    subplot(1,4,j);
    if j<=4
        h = bar(linspace(1,number_bins,number_bins), normalized_ave_inv_2bin_AppC2_C3(:,j)',0.8,"FaceAlpha",0.5,'FaceColor','flat' ); 
        title_text = strcat('$\theta_{a}$ bin = ', num2str(j));
        ylim([-120,120]); 
        h(1).FaceColor  =  0.3*[0 0.6 0.3]; 
    end        
    xlim([0.5,number_bins+0.5]);      
    axis square; grid on;
    ylabel({'Diff. from $\theta_{a}$ bin mean (pp)' },'Color','k','Interpreter','latex','FontSize',12);  
    xlabel({'$\theta_{k}$ bin'},'Interpreter','latex','FontSize',12); 
    title(title_text);
    set(gca,'Fontsize',fontsz,'FontName',font_name,'xcolor','k','ycolor','k' );    
end
hFig.WindowState = 'maximized';
filename_temp = strcat(draft_output_path,'FigSkillinvestmentlevelby_endowmenttheta_baseline.png');
delete(filename_temp);
pause(4);
exportgraphics(hFig,filename_temp); 

% --> Figure C.2(b): Baseline skill outcome by thetak and thetaa bin 
hFig = figure(22);  
for j = 1:4
    subplot(1,4,j);
    if j<=4
        h = bar(linspace(1,number_bins,number_bins), normalized_ave_thetaka_2bin_AppC2_C3(:,j)',0.8,"FaceAlpha",0.5,'FaceColor','flat' ); 
        title_text = strcat('$\theta_{a}$ bin = ', num2str(j));
        ylim([-120,120]); 
        h(1).FaceColor  =  0.3*[0 0.6 0.3]; 
    end        
    xlim([0.5,number_bins+0.5]);      
    axis square; grid on;
    ylabel({'Diff. from $\theta_{a}$ bin mean (pp)' },'Color','k','Interpreter','latex','FontSize',12);  
    xlabel({'$\theta_{k}$ bin'},'Interpreter','latex','FontSize',12); 
    title(title_text);
    set(gca,'Fontsize',fontsz,'FontName',font_name,'xcolor','k','ycolor','k' );    
end
hFig.WindowState = 'maximized';
filename_temp = strcat(draft_output_path,'FigSkilloutcomelevelby_endowmenttheta_baseline.png');
delete(filename_temp);
pause(4);
exportgraphics(hFig,filename_temp); 
close all;

% ---> Statistic quoted Appendix C.2.2: Fixed cost value among applicants
disp(' '); disp('Average fixed cost paid by applicants in USD'); disp(' '); disp(ave_fc_paid_CCDF_applicants_inUSD_AppC2_C3)
 
% ---> Table C.14: Share of population receiving aid in model versus data
Data_source_text_app = {'\citetalias{IRSSOIT332017}','\citetalias{IRSSOIT252017}'};
Row_label_text = {'Child Tax Credit (CTC)','Earned Income Tax Credit (EITC)'};
DataMoment_values_print  = [0.15 0.18 ];
ModelMoment_values_print = round(0.01*[Spending_pctage_of_pop_receiving_policy_mat_AppC2_C3([2 3],Baseline_index)]',tex_table_number_rounding);
T_tex = table(Row_label_text(:),DataMoment_values_print(:),ModelMoment_values_print(:),'VariableNames',{'\textbf{Policy}','\textbf{Data}','\textbf{Model}'});
% For tex file called by manuscript:
texfilename_temp = strcat(draft_output_path,'ShareRecipients.tex');
delete(texfilename_temp);
table2latex_formatted_egm(T_tex,5,tex_table_number_format,0,texfilename_temp);
disp(' '); disp('Table C.14'); disp(' '); disp(T_tex)

% ---> Figure C.3: EITC distribution of spending and recipients in model v data --> keep for appendix? 
hFig = figure(23);   
subplot(1,2,1);
b1 = bar([ squeeze(amt_eitc_bin_AppC2_C3(4,:,1,Baseline_index)./sum(amt_eitc_bin_AppC2_C3(4,:,1,Baseline_index)))'  sharespendingeitc(:) ],0.8,"FaceAlpha",0.5,'FaceColor','flat' ); 
grid on;  axis square;
xlabel('Pretax income bin','Interpreter','latex'); 
ylim([0 1.1]); ylabel('Share of spending','Interpreter','latex'); ytickformat('%.1f'); 
set(gca,'Fontsize',fontsz,'FontName',font_name,'xcolor','k','ycolor','k','TickLength',[0.0,0.0]);
hleglines = [b1(1) b1(2)]; 
title('\textbf{Share of spending}');
b1(2).CData =  [0.3 0.3 0.3];  
lgd = legend(hleglines,'Model','Data','Interpreter','latex','Location','NorthEast','NumColumns',1,'FontSize',12); 
legend boxoff;
subplot(1,2,2);
EITC_share_bin_temp = squeeze(mass_eitc_bin_AppC2_C3(4,:,1,Baseline_index))';
EITC_share_bin_temp = EITC_share_bin_temp./sum(EITC_share_bin_temp(:));
b1 = bar([EITC_share_bin_temp sharereceipteitc(:) ],0.8,"FaceAlpha",0.5,'FaceColor','flat' ); 
grid on;  axis square;
xlabel('Pretax income bin','Interpreter','latex'); 
ylim([0 1.1]); ylabel('Share of recipients','Interpreter','latex'); ytickformat('%.1f'); 
set(gca,'Fontsize',fontsz,'FontName',font_name,'xcolor','k','ycolor','k','TickLength',[0.0,0.0]);
hleglines = [b1(1) b1(2)]; 
b1(2).CData =  [0.3 0.3 0.3];  
title('\textbf{Share of recipients}'); 
lgd = legend(hleglines,'Model','Data','Interpreter','latex','Location','NorthEast','NumColumns',1,'FontSize',12); 
legend boxoff;
filename_temp = strcat(draft_output_path,'FigEITC_SpendingShare_ybin_data_and_model.png');
delete(filename_temp);
pause(5);
exportgraphics(hFig,filename_temp);
close all;
%% Appendix C.3
% ---> Figure C.4b and C.5b: Inflows to CCDF uptake in GE expansion of CCDF
% binning_variable_index = 1: Bin1 = Thetaa , Bin2 = thetak
% binning_variable_index = 2: Bin1 = y , Bin2 = thetak
% binning_variable_index = 3: Bin1 = thetaa , Bin2 = fc
% binning_variable_index = 4: Bin1 = y , Bin2 = fc 
binning_var_index = 2;


x_discrete = repmat(linspace(1,number_bins,number_bins),[number_bins 1]); 
x_discrete = x_discrete(:);
y_discrete = repmat(linspace(1,number_bins,number_bins),[1 number_bins])';

%  Application, receipt: 2-D conditional rates 
for binning_variable_index = [1 3]  
    for Policy_vec_index = 3
        close all;
        hFig = figure(20+binning_variable_index*Policy_vec_index);
        if binning_variable_index == 1
            xlabeltext =  'Adult skill'; ylabeltext = 'Child skill endowment'; 
            filename_temp = strcat(draft_output_path,'AppGECCDF_thetaa_thetak',num2str(Policy_vec_index),'.png');
        elseif binning_variable_index == 3
            xlabeltext =  'Adult skill'; ylabeltext = 'Application cost'; 
            filename_temp = strcat(draft_output_path,'AppGECCDF_thetaa_fixedcost',num2str(Policy_vec_index),'.png');
        end 
        for graphing_var_index = 1:3          
            subplot(1,3,graphing_var_index);             
            if graphing_var_index == 1
                CCDF_pct_bin_temp      = 100*squeeze(share_eligible_ccdf_2bin_AppC2_C3(binning_variable_index,:,:,Policy_vec_index))'; % orginal: row is thetaa/incq, column is thetak; this makes row thetak, column thetaa/incq
                texttitle = 'Eligible (fixed labor)'; 
            elseif graphing_var_index == 2
                CCDF_pct_bin_temp      = 100*squeeze(share_apply_ccdf_wfc_2bin_AppC2_C3(binning_variable_index,:,:,Policy_vec_index))'; % orginal: row is thetaa/incq, column is thetak; this makes row thetak, column thetaa/incq
                texttitle = 'Applied';
            else
                CCDF_pct_bin_temp      = 100*squeeze(share_received_ccdf_2bin_AppC2_C3(binning_variable_index,:,:,Policy_vec_index))'; % orginal: row is thetaa/incq, column is thetak; this makes row thetak, column thetaa/incq
                texttitle = 'Received';
            end
            tbl = table(x_discrete,y_discrete,CCDF_pct_bin_temp(:)  , 'VariableNames', {'x', 'y', 'z'}); 
            h = heatmap(tbl,'x','y','ColorVariable','z','ColorMethod','mean', 'FontName', 'Times New Roman'); xlabel(xlabeltext); ylabel(ylabeltext); 
            set(gcf, 'Position',  [100,100,1100,350]);
            h.ColorbarVisible = 'off';
            h.NodeChildren(3).YDir='normal';  
            h.MissingDataLabel = ' ';
            h.MissingDataColor = [1 1 1];
            h.CellLabelFormat = '%.0f';
            h.Title = texttitle;
            h.FontSize = 18; 
            h.FontName = font_name;     
        end
        delete(filename_temp);
        pause(4) 
        exportgraphics(hFig,filename_temp);
    end 
end 

% --> Figure C.6: change in outcome by initial skill endowment bin **and** parent adult skill level bin, in PE and GE
hFig = figure(24);  
for j = 1:8
    subplot(2,4,j);
    if j<=4
        h = bar(linspace(1,number_bins,number_bins), squeeze(pct_changethetaak_2bin_AppC2_C3(j,:,[14 2])),0.8,"FaceAlpha",0.5,'FaceColor','flat' ); 
        title_text = strcat('$\theta_{a}$ quartile = ', num2str(j));
        ylim([-2,40]); 
        h(1).FaceColor  =  0.3*[0 0.6 0.3];
        h(2).FaceColor  =  [0 0.6 0.3];
    else
        h = bar(linspace(1,number_bins,number_bins), squeeze(pct_changethetaak_2bin_AppC2_C3(j-4,:,[21 3])),0.8,"FaceAlpha",0.5,'FaceColor','flat' ); 
        title_text = strcat('$\theta_{a}$ quartile = ', num2str(j-4));
        ylim([-2,40]); 
        h(1).FaceColor  =  0.3*[0.85 0.325 0.098]; 
        h(2).FaceColor  =  [0.85 0.325 0.098]; 
    end        
    xlim([0.5,number_bins+0.5]);      
    axis square; grid on;
    ylabel({'Percent change' },'Color','k','Interpreter','latex','FontSize',12);  
    xlabel({'$\theta_{k}$ quartile'},'Interpreter','latex','FontSize',12); 
    title(title_text);
    set(gca,'Fontsize',fontsz,'FontName',font_name,'xcolor','k','ycolor','k' ); 
    if j==1
        lgd=legend('Partial','General','Location','NorthWest','NumColumns',1,'Interpreter','latex','FontSize',11);  
        title(lgd,'\underline{\textbf{CTC}}','FontWeight','bold','FontSize',12);  
        set(lgd,'Box','off'); 
    elseif j == 5
        lgd=legend('Partial','General','Location','NorthWest','NumColumns',1,'Interpreter','latex','FontSize',11);  
        title(lgd,'\underline{\textbf{CCDF}}','FontWeight','bold','FontSize',12);  
        set(lgd,'Box','off');   
    end 
end
hFig.WindowState = 'maximized';
filename_temp = strcat(draft_output_path,'FigSkilloutcomechangesby_endowmenttheta_binsPEGE.png');
delete(filename_temp);
pause(4);
exportgraphics(hFig,filename_temp); 
close all;

% ---> Figure C.7 
% Changes for the no-means-testing expansion to illustrate it is not a policy constraint that restricts growth to low-theta_a types.
% ---> Child skill outcomes by initial skill endowment and parent skill bin 
% --> Figure: CCDF expansion + eliminating means-testing change in outcome by initial skill endowment bin **and** parent adult skill level bin, in PE and GE
hFig = figure(25);  
for j = 1:4
    subplot(1,4,j);
    if j<=4
        h = bar(linspace(1,number_bins,number_bins), squeeze(pct_changethetaak_2bin_AppC2_C3(j,:,[3 4])),0.8,"FaceAlpha",0.5,'FaceColor','flat' ); 
        title_text = strcat('$\theta_{a}$ quartile = ', num2str(j));
        ylim([-2,40]); 
        h(1).FaceColor  =  [0.85 0.325 0.098];
        h(2).FaceColor  =  0.3*[0 0.6 0.3];
    end        
    xlim([0.5,number_bins+0.5]);      
    axis square; grid on;
    ylabel({'Percent change' },'Color','k','Interpreter','latex','FontSize',12);  
    xlabel({'$\theta_{k}$ quartile'},'Interpreter','latex','FontSize',12); 
    title(title_text);
    set(gca,'Fontsize',fontsz,'FontName',font_name,'xcolor','k','ycolor','k' ); 
    if j==3
        lgd=legend('Main text gen. equ.','... + no means-testing','Total','Location','NorthWest','NumColumns',1,'Interpreter','latex','FontSize',11);  
        title(lgd,'\underline{\textbf{CCDF expansion}}','FontWeight','bold','FontSize',12);  
        set(lgd,'Box','off');   
    end 
end
hFig.WindowState = 'maximized';
filename_temp = strcat(draft_output_path,'FigSkilloutcomechangesby_endowmenttheta_binsGEMarginalNMT.png');
delete(filename_temp);
pause(4);
exportgraphics(hFig,filename_temp); 
close all;

% ---> Table C.15: Decomposition of 2017 TCJA CTC expansion into its component margins
% For tex file called by manuscript
Columnnames_temp    = {'\textbf{Variable category}','\textbf{Variable description}','\textbf{Baseline}','\textbf{(1) CTC}','\textbf{(2) $\overline{\kappa}$}','\textbf{(3) $\underline{y}$}','\textbf{(4) $\overline{y}$}'};
Atemp = []; Atemp =  round(Array_Policy_counterfactuals_C2_C3(Array_rows_vec_draft,[Baseline_index 2 11 10 9]),tex_table_number_rounding); % rounding avoids have "-0.00" as a value, instead it is just 0.
T_tex= []; T_tex = table(Rownames_AggregatesPanels',Rownames_AggregatesVars',Atemp(:,1),Atemp(:,2),Atemp(:,3),Atemp(:,4),Atemp(:,5),'VariableNames',Columnnames_temp); 
texfilename_temp = strcat(draft_output_path,'CTCMainMarginsDecomp.tex');
delete(texfilename_temp);
table2latex_formatted_egm(T_tex,3,tex_table_number_format,0,texfilename_temp);
disp(' '); disp('Table C.15'); disp(' '); disp(T_tex)

% ---> Table C.16: Decomposition of CCDF expansion benchmark (2017 TCJA CTC expansion equiv) into its component margins
% For tex file called by manuscript:
Columnnames_temp    = {'\textbf{Variable category}','\textbf{Variable description}','\textbf{Baseline}','\textbf{(1) CCDF}','\textbf{(2) $\phi_{N}$}','\textbf{(3) $\kappa_{N}$}'}';
Atemp = []; Atemp =  round(Array_Policy_counterfactuals_C2_C3(Array_rows_vec_draft,[Baseline_index 3 12 13]),tex_table_number_rounding); % rounding avoids have "-0.00" as a value, instead it is just 0.
T_tex= []; T_tex = table(Rownames_AggregatesPanels',Rownames_AggregatesVars',Atemp(:,1),Atemp(:,2),Atemp(:,3),Atemp(:,4),'VariableNames',Columnnames_temp); 
texfilename_temp = strcat(draft_output_path,'CCDFMainMarginsDecomp.tex');
delete(texfilename_temp);
table2latex_formatted_egm(T_tex,3,tex_table_number_format,0,texfilename_temp);
disp(' '); disp('Table C.16'); disp(' '); disp(T_tex)

% ---> Table C.17: Motivation of choice for CCDF policy margins - eliminating rationing & spending-equivalent alternative expansions of CCDF 
% For tex file called by manuscript:
Columnnames_Aggregates    = {'\textbf{Variable category}','\textbf{Variable description}','\textbf{Baseline}','\textbf{(1) $\phi_{N}$}','\textbf{(2) $\beta_{N,0}$}','\textbf{(3) $\beta_{N,1}$}','\textbf{(4) No $\overline{y}_{N}$}'};
Atemp = []; Atemp =  round(Array_Policy_counterfactuals_C2_C3(Array_rows_vec_draft,[Baseline_index 5 6 7 8]),tex_table_number_rounding); % rounding avoids have "-0.00" as a value, instead it is just 0.
T_tex= []; T_tex = table(Rownames_AggregatesPanels_abbreviated',Rownames_AggregatesVars_abbreviated',Atemp(:,1),Atemp(:,2),Atemp(:,3),Atemp(:,4),Atemp(:,5),'VariableNames',Columnnames_Aggregates); 
texfilename_temp = strcat(draft_output_path,'AlternativeCCDFexp.tex');
delete(texfilename_temp);
table2latex_formatted_egm(T_tex,3,tex_table_number_format,0,texfilename_temp);
disp(' '); disp('Table C.17'); disp(' '); disp(T_tex)

% ---> Table C.18: Main experiment PE decomposition 
% CTC - For tex file called by manuscript:
Atemp = []; Atemp =  round(Array_Policy_counterfactuals_C2_C3([21 22 23],[2 14 15 16 17 18 19 20]),tex_table_number_rounding);
T_tex= []; T_tex = table(Rownames_PEVars',Atemp(:,1),Atemp(:,2),Atemp(:,3),Atemp(:,4),Atemp(:,5),Atemp(:,6),Atemp(:,7),Atemp(:,8),'VariableNames',Columnnames_PECTC); 
texfilename_temp = strcat(draft_output_path,'DraftTablesPEDecompCTC.tex');
table2latex_formatted_egm(T_tex,2,tex_table_number_format,1,texfilename_temp);
disp(' '); disp('Table C.18 - CTC'); disp(' '); disp(T_tex)
% CCDF - For tex file called by manuscript:
Atemp = []; Atemp =  round(Array_Policy_counterfactuals_C2_C3([21 22 23],[3 21 22 23 24 25 26 27]),tex_table_number_rounding);
T_tex= []; T_tex= []; T_tex = table(Rownames_PEVars',Atemp(:,1),Atemp(:,2),Atemp(:,3),Atemp(:,4),Atemp(:,5),Atemp(:,6),Atemp(:,7),Atemp(:,8),'VariableNames',Columnnames_PECCDF); 
texfilename_temp = strcat(draft_output_path,'DraftTablesPEDEcompCCDF.tex');
table2latex_formatted_egm(T_tex,2,tex_table_number_format,2,texfilename_temp);
disp(' '); disp('Table C.18 - CCDF'); disp(' '); disp(T_tex)

% ---> Table C.19: Transition path dynamics
%  path periods
period1 = 5/5+1;
period2 = 25/5+1;
period3 = 45/5+1;
period4 = 65/5+1; 
period5 = 85/5+1;
period6 = 105/5+1;
period7 = 120/5+1;

Columnnames_TPCTC   = {'\multicolumn{1}{l}{\textbf{Panel A: CTC}}', '\multicolumn{1}{c}{\textbf{5}}','\multicolumn{1}{c}{\textbf{25}}','\multicolumn{1}{c}{\textbf{45}}','\multicolumn{1}{c}{\textbf{Final}}'};
Columnnames_TPCCDF   = {'\multicolumn{1}{l}{\textbf{Panel B: CCDF}}', '\multicolumn{1}{c}{\textbf{5}}','\multicolumn{1}{c}{\textbf{25}}','\multicolumn{1}{c}{\textbf{45}}','\multicolumn{1}{c}{\textbf{Final}}'};
Rowvariables    = {'\multicolumn{1}{l}{{Behind the veil of ignorance}}','\multicolumn{1}{l}{{New adults}}','\multicolumn{1}{l}{{ - Share who gain}}','\multicolumn{1}{l}{{All adults}}','\multicolumn{1}{l}{{ - Share who gain}}'};
T_auxGECTC= []; T_auxGECTC   = squeeze(ALL_array_policy_t([21 22 27 23 29],[period1 period2 period3 end],1))'; T_auxGECTC = round(T_auxGECTC,tex_table_number_rounding);
T_auxGECCDF= []; T_auxGECCDF = squeeze(ALL_array_policy_t([21 22 27 23 29],[period1 period2 period3 end],2))'; T_auxGECCDF = round(T_auxGECCDF,tex_table_number_rounding);  % rounding avoids printing "-0.00" as a value, instead it is just 0.
T_tex= []; T_tex= []; T_tex = table(Rowvariables',T_auxGECTC(1,:)',T_auxGECTC(2,:)',T_auxGECTC(3,:)',T_auxGECTC(4,:)','VariableNames',Columnnames_TPCTC);
texfilename_temp = strcat(draft_output_path,'DraftTablesTPCTC.tex');
table2latex_formatted_egm(T_tex,2,tex_table_number_format,1,texfilename_temp);
disp(' '); disp('Table C.19 - CTC'); disp(' '); disp(T_tex)
T_tex= []; T_tex= []; T_tex = table(Rowvariables',T_auxGECCDF(1,:)',T_auxGECCDF(2,:)',T_auxGECCDF(3,:)',T_auxGECCDF(4,:)','VariableNames',Columnnames_TPCCDF);
texfilename_temp = strcat(draft_output_path,'DraftTablesTPCCDF.tex');
table2latex_formatted_egm(T_tex,2,tex_table_number_format,2,texfilename_temp);
disp(' '); disp('Table C.19 - CCDF'); disp(' '); disp(T_tex)

%% Appendix C.4 
% ---> Figure C.8: gradual GE expansions of CTC and CCDF 
array_vec_temp_CTCGE1  = [1 11 12 13 14 15 16 17]; 
array_vec_temp_CCDFGE1  = [1 6 7 8 9 10]; 
Welfare_measure_temp = NaN(size(Array_Policy_counterfactuals_C4,2),3);
Welfare_measure_temp(:,1) = Array_Policy_counterfactuals_C4(21,:); %W_change_bvi_ave(1,:);  
Welfare_measure_temp(:,2) = Array_Policy_counterfactuals_C4(22,:); %W_change_adults_ave(1,:);  
Welfare_measure_temp(:,3) = Array_Policy_counterfactuals_C4(23,:); %sum(W_change_adults_ave,1)/J ;  

plot_vecy_CTC3 = [Welfare_measure_temp(array_vec_temp_CTCGE1,:)]; 
plot_vecx_CTC3 = target_pct_Y_G_policy_mat_C4(array_vec_temp_CTCGE1) - target_pct_Y_G_policy_mat_C4(1);

plot_vecy_CCDF3 = [Welfare_measure_temp(array_vec_temp_CCDFGE1,:)]; 
plot_vecx_CCDF3 = target_pct_Y_G_policy_mat_C4(array_vec_temp_CCDFGE1) - target_pct_Y_G_policy_mat_C4(1);
  
hFig = figure(1);
for graphing_index = 1:3    
    subplot(1,3,graphing_index)
    % Lines 
    b1 = plot(plot_vecx_CTC3,plot_vecy_CTC3(:,graphing_index),'LineWidth',1.3,'Color', [0 0.6 0.3]);   hold on;     
    b2 = plot(plot_vecx_CCDF3,plot_vecy_CCDF3(:,graphing_index),'LineWidth',1.3,'Color', [0.85 0.325 0.098]);   
    % Dots on end of each line 
    plot(plot_vecx_CTC3(end),plot_vecy_CTC3(end,graphing_index),'o','MarkerSize',5, 'MarkerFaceColor',[0 0.6 0.3],'MarkerEdgeColor',[0 0.6 0.3]);
    plot(plot_vecx_CCDF3(end),plot_vecy_CCDF3(end,graphing_index),'o','MarkerSize',5, 'MarkerFaceColor',[0.85 0.325 0.098],'MarkerEdgeColor',[0.85 0.325 0.098]);
    % Axes formatting
    xticks([0   0.5   1.0  1.50  2.0]); xticklabels({ '0.00' ; '0.50';   '1.00'; '1.50';'2.00'});
    ylim([1.8*min([plot_vecy_CTC3(:)]),1.2*max([plot_vecy_CCDF3(:)])])
    xlim([0,1.1*max([plot_vecx_CTC3(:) ;plot_vecx_CCDF3(:)])])
    xlabel('Change in govt. spending (pp)'); 
    ylabel('Percent of lifetime consumption');  
    if graphing_index == 1
        title('\textbf{Behind the veil of ignorance}')
    elseif graphing_index == 2
        title('\textbf{Average new adults}'); 
    else
        title('\textbf{Average all adults}'); 
    end
    % Legend
    if graphing_index == 2 
        hleglines = [ b1(1) b2(1)   ]; 
        lgd = legend(hleglines,'CTC','CCDF','Interpreter','latex','Location','North','NumColumns',1,'FontSize',12);
        title(lgd,'\underline{\textbf{Policy being expanded}}','FontWeight','bold','FontSize',12); 
        legend boxoff;
    end
    set(gca,'Fontsize',fontsz,'FontName',font_name);
    axis square; grid on; 
end 
hFig.WindowState = 'maximized';
filename_temp = strcat(draft_output_path,'FigGradual_Expansion_CCDFCTC_appendixWelfareAll.png');
delete(filename_temp);
pause(4);
exportgraphics(hFig,filename_temp); 
hold off;
close all;

% ---> Table C.20: CCDF main experiment with and without eliminating rationing and in comparison to traditional expansion
% For tex file called by manuscript:
Columnnames_Aggregates    = {'\textbf{Variable category}','\textbf{Variable description}','\textbf{Baseline}','\textbf{(1) CTC}','\textbf{(2) CCDF}','\textbf{(3) $\kappa_{N}$}','\textbf{(4) Trad.}'};
Atemp = []; Atemp =  round(Array_Policy_counterfactuals_C4(Array_rows_vec_draft,[Baseline_index 2 3 4 5]),tex_table_number_rounding); % rounding avoids have "-0.00" as a value, instead it is just 0.
T_tex= []; T_tex = table(Rownames_AggregatesPanels_abbreviated',Rownames_AggregatesVars_abbreviated',Atemp(:,1),Atemp(:,2),Atemp(:,3),Atemp(:,4),Atemp(:,5),'VariableNames',Columnnames_Aggregates); 
texfilename_temp = strcat(draft_output_path,'AlternativeCCDFMain.tex');
delete(texfilename_temp);
table2latex_formatted_egm(T_tex,3,tex_table_number_format,0,texfilename_temp);
disp(' '); disp('Table C.20'); disp(' '); disp(T_tex)

% ---> Figure C.9(b) and C.10(b)
% more on traditional expansion of Table C.20 ---> why such low welfare gains?
% Composition of new CCDF recipients is high-theta, low fixed cost, so big skill changes don't happen and many low-theta now pay higher taxes.
% binning_variable_index = 1: Bin1 = Thetaa , Bin2 = thetak
% binning_variable_index = 2: Bin1 = y , Bin2 = thetak
% binning_variable_index = 3: Bin1 = thetaa , Bin2 = fc
% binning_variable_index = 4: Bin1 = y , Bin2 = fc 
Policy_vec_index = 5; % Traditional expansion index in C4 exercises

x_discrete = repmat(linspace(1,number_bins,number_bins),[number_bins 1]); 
x_discrete = x_discrete(:);
y_discrete = repmat(linspace(1,number_bins,number_bins),[1 number_bins])';
for binning_variable_index = [1 3]
    hFig = figure(binning_variable_index);
    if binning_variable_index == 1
        filename_temp = strcat(draft_output_path,'FigCCDF_thetaa_thetak_traditional.png');
    elseif binning_variable_index == 3
        filename_temp = strcat(draft_output_path,'FigCCDF_thetaa_fixedcost_traditional.png');
    end  
    for graphing_var_index = 1:3          
        subplot(1,3,graphing_var_index);
        if binning_variable_index == 1 
            xlabeltext = 'Adult skill'; ylabeltext = 'Child skill endowment'; 
        elseif binning_variable_index == 3
            xlabeltext = 'Adult skill'; ylabeltext = 'Application cost'; 
        end  
        if graphing_var_index == 1
            CCDF_pct_bin_temp = 100*squeeze(share_eligible_ccdf_2bin_C4(binning_variable_index,:,:,Policy_vec_index))'; % orginal: row is thetaa/incq, column is thetak; this makes row thetak, column thetaa/incq
            texttitle = 'Eligible (fixed labor)';
        elseif graphing_var_index == 2
            CCDF_pct_bin_temp = 100*squeeze(share_apply_ccdf_wfc_2bin_C4(binning_variable_index,:,:,Policy_vec_index))'; % orginal: row is thetaa/incq, column is thetak; this makes row thetak, column thetaa/incq
            texttitle = 'Applied';
        else
            CCDF_pct_bin_temp = 100*squeeze(share_received_ccdf_2bin_C4(binning_variable_index,:,:,Policy_vec_index))'; % orginal: row is thetaa/incq, column is thetak; this makes row thetak, column thetaa/incq
            texttitle = 'Received'; 
        end
        tbl = table(x_discrete,y_discrete,CCDF_pct_bin_temp(:), 'VariableNames', {'x', 'y', 'z'}); 
        h = heatmap(tbl,'x','y','ColorVariable','z','ColorMethod','mean', 'FontName', 'Times New Roman');xlabel(xlabeltext); ylabel(ylabeltext); 
        set(gcf, 'Position',  [100,100,1100,350]);
        h.ColorbarVisible = 'off';
        h.NodeChildren(3).YDir='normal';
        h.MissingDataLabel = ' ';
        h.MissingDataColor = [1 1 1];
        h.CellLabelFormat = '%.0f';
        h.Title = texttitle;
        h.FontSize = 18; 
        h.FontName = font_name;     
    end
    delete(filename_temp); 
    pause(5) 
    exportgraphics(hFig,filename_temp);
end
close all; 

%% Appendix C.5 
% ---> Table C.21: Parameterization - internal calibration results for higher correlation of child skill endowment with parent skill
% DataMoment_values_policy_mat  = [Laborsupply_target N_hours_target Corrincskill_target CCDF_receipt_target GRIDparp50p10_target Corrinitialskill_target SS_spending_percentageY 0.000 pn_ratio_observed]';
% ModelMoment_values_policy_mat = [h_hours n_hours rho_thetay CCDF_receipt p50_yparGRID - p10_yparGRID rho_initialskill 0.01*tot_G_spending_SS_policy_mat_pretax(Policy_vec_index) 0.000 pn/(sum(par_weights(:).*wage_aftx(:))/sum(par_weights(:).*(1-subsidy_correction(:))))]';
% Parameter_values_policy_mat   = [psi lambda_I b/beta chi_c_fraction varlogthetak initial_corr_par pension_rep_rate thetan pn_ratio_adjusted]';
% For tex file called by manuscript:
Panel_label_text           = {'\textbf{Panel A: Jointly}', '\textbf{calibrated}', '', '', '', '','','\midrule \textbf{Panel B: Set}', '\textbf{proportionally}'}';
Parameter_Symbol_text      = {'$\psi$','$\lambda_{\theta}$','$b$','$\mu_{N}$','$\sigma_{k}^{2}$','$\rho_{k}$','$\zeta_{P}$','$\theta_{n}$','$\eta$'}';
Parameter_Description_text = {'Marginal disutility labor','Skill scaling factor','Altruism coefficient (share $\beta$)','Ave. app. cost (share $\overline{y}_{pop}$)','Variance of $\log\left(\theta_{k}\right)$','Intergen. persistence of skill','SS replacement rate','Childcare productivity','Childcare pre-policy price ratio'}';
Moment_Description_text    = {'Age 25-55 average hours labor $h$','Age 20 average hours childcare $n$','Age 20 Corr$\left(\theta_{k}^{a*}, y^{*}\right)$','Age 20 share receiving CCDF','Age 25-34 $\log\left(y\right)$ p50-p10','Age 20 Corr$\left(\theta_{k},\theta_{a}\right)$','SS spending (share output)','Age 20 workers ave. log prod. ratio','Age 20 workers price ratio'};
DataMoment_values_print  = DataMoment_values_policy_mat_C5_1_and_2(:,1)'; DataMoment_values_print(7) = 0.01*DataMoment_values_print(7);
ModelMoment_values_print = ModelMoment_values_policy_mat_C5_1_and_2(:,1)';  
Parameter_values_print  = [Parameter_values_policy_mat_C5_1_and_2(1:8,1); Parameter_values_policy_mat_C5_1_and_2(10,1)]';
T_tex= []; T_tex = table(Panel_label_text(:),Parameter_Symbol_text(:),Parameter_Description_text(:),Parameter_values_print(:),Moment_Description_text(:),DataMoment_values_print(:),ModelMoment_values_print(:),...
    'VariableNames',{'\textbf{Category}','\textbf{Sym.}','\textbf{Parameter description}','\textbf{Value}','\textbf{Moment description}','\textbf{Data}','\textbf{Model}'});
texfilename_temp = strcat(draft_output_path,'Pars_calibrated_RecalRobustnessHigherIGPersistenceSkill.tex');
delete(texfilename_temp);
table2latex_formatted_egm(T_tex,7,tex_table_number_format,0,texfilename_temp);
disp(' '); disp('Table C.21'); disp(' '); disp(T_tex)

% ---> Table C.22: Higher correlation of child skill endowment with parent skill 
% For tex file called by manuscript:
Atemp = []; Atemp = round(Array_Policy_counterfactuals_C5_1_and_2,tex_table_number_rounding);
T_tex= []; T_tex = table(Rownames_AggregatesPanels',Rownames_AggregatesVars',Atemp(Array_rows_vec_draft,1),Atemp(Array_rows_vec_draft,3),Atemp(Array_rows_vec_draft,5),Atemp(Array_rows_vec_draft,7),...
    'VariableNames',{'\textbf{Variable category}','\textbf{Variable description}','\textbf{Baseline}','\textbf{(1) CTC}','\textbf{(2) CCDF}','\textbf{(3) Traditional}'}); 
texfilename_temp = strcat(draft_output_path,'RecalRobustnessHigherIGPersistenceSkill.tex');
delete(texfilename_temp);
table2latex_formatted_egm(T_tex,3,tex_table_number_format,0,texfilename_temp);
disp(' '); disp('Table C.22'); disp(' '); disp(T_tex)

% ---> Table C.23: Parameterization - internal calibration results for targeting Chetty rank-rank target
% DataMoment_values_policy_mat  = [Laborsupply_target N_hours_target Corrincskill_target CCDF_receipt_target GRIDparp50p10_target Corrinitialskill_target SS_spending_percentageY 0.000 pn_ratio_observed]';
% ModelMoment_values_policy_mat = [h_hours n_hours rho_thetay CCDF_receipt p50_yparGRID - p10_yparGRID rho_initialskill 0.01*tot_G_spending_SS_policy_mat_pretax(Policy_vec_index) 0.000 pn/(sum(par_weights(:).*wage_aftx(:))/sum(par_weights(:).*(1-subsidy_correction(:))))]';
% Parameter_values_policy_mat   = [psi lambda_I b/beta chi_c_fraction varlogthetak initial_corr_par pension_rep_rate thetan pn_ratio_adjusted]';
Panel_label_text           = {'\textbf{Panel A: Jointly}', '\textbf{calibrated}', '', '', '', '','','\midrule \textbf{Panel B: Set}', '\textbf{proportionally}'}';
Parameter_Symbol_text      = {'$\psi$','$\lambda_{\theta}$','$b$','$\mu_{N}$','$\sigma_{k}^{2}$','$\rho_{k}$','$\zeta_{P}$','$\theta_{n}$','$\eta$'}';
Parameter_Description_text = {'Marginal disutility labor','Skill scaling factor','Altruism coefficient (share $\beta$)','Ave. app. cost (share $\overline{y}_{pop}$)','Variance of $\log\left(\theta_{k}\right)$','Intergen. persistence of skill','SS replacement rate','Childcare productivity','Childcare pre-policy price ratio'}';
Moment_Description_text    = {'Age 25-55 average hours labor $h$','Age 20 average hours childcare $n$','Rank-rank corr Chetty 2014','Age 20 share receiving CCDF','Age 25-34 $\log\left(y\right)$ p50-p10','Age 20 Corr$\left(\theta_{k},\theta_{a}\right)$','SS spending (share output)','Age 20 workers ave. log prod. ratio','Age 20 workers price ratio'};
DataMoment_values_print  = DataMoment_values_policy_mat_C5_1_and_2(:,2)'; DataMoment_values_print(7) = 0.01*DataMoment_values_print(7); DataMoment_values_print(3) = 0.34;
ModelMoment_values_print = ModelMoment_values_policy_mat_C5_1_and_2(:,2)';  
Parameter_values_print  = [Parameter_values_policy_mat_C5_1_and_2(1:8,2); Parameter_values_policy_mat_C5_1_and_2(10,2)]';
T_tex= []; T_tex = table(Panel_label_text(:),Parameter_Symbol_text(:),Parameter_Description_text(:),Parameter_values_print(:),Moment_Description_text(:),DataMoment_values_print(:),ModelMoment_values_print(:),...
    'VariableNames',{'\textbf{Category}','\textbf{Sym.}','\textbf{Parameter description}','\textbf{Value}','\textbf{Moment description}','\textbf{Data}','\textbf{Model}'});
% For tex file called by manuscript:
texfilename_temp = strcat(draft_output_path,'\Pars_calibrated_RecalRobustnessRankRank.tex');
delete(texfilename_temp);
table2latex_formatted_egm(T_tex,7,tex_table_number_format,0,texfilename_temp);
disp(' '); disp('Table C.23'); disp(' '); disp(T_tex)

% ---> Table C.24: more intergenerational mobility, targeting Chetty rank-rank
% For tex file called by manuscript:
Atemp = []; Atemp = round(Array_Policy_counterfactuals_C5_1_and_2,tex_table_number_rounding);
T_tex= []; T_tex = table(Rownames_AggregatesPanels',Rownames_AggregatesVars',Atemp(Array_rows_vec_draft,2),Atemp(Array_rows_vec_draft,4),Atemp(Array_rows_vec_draft,6),...
    'VariableNames',{'\textbf{Variable category}','\textbf{Variable description}','\textbf{Baseline}','\textbf{(1) CTC}','\textbf{(2) CCDF}'}); 
texfilename_temp = strcat(draft_output_path,'RecalRobustnessRankRank.tex');
delete(texfilename_temp);
table2latex_formatted_egm(T_tex,3,tex_table_number_format,0,texfilename_temp);
disp(' '); disp('Table C.24'); disp(' '); disp(T_tex)

% ---> Table C.25: Parameterization - internal calibration results for utility cost specification
% DataMoment_values_policy_mat  = [Laborsupply_target N_hours_target Corrincskill_target CCDF_receipt_target GRIDparp50p10_target Corrinitialskill_target SS_spending_percentageY 0.000 pn_ratio_observed]';
% ModelMoment_values_policy_mat = [h_hours n_hours rho_thetay CCDF_receipt p50_yparGRID - p10_yparGRID rho_initialskill 0.01*tot_G_spending_SS_policy_mat_pretax(Policy_vec_index) 0.000 pn/(sum(par_weights(:).*wage_aftx(:))/sum(par_weights(:).*(1-subsidy_correction(:))))]';
% Parameter_values_policy_mat   = [psi lambda_I b/beta chi_c_fraction varlogthetak initial_corr_par pension_rep_rate thetan pn_ratio_adjusted]';
Panel_label_text           = {'\textbf{Panel A: Jointly}', '\textbf{calibrated}', '', '', '', '','','\midrule \textbf{Panel B: Set}', '\textbf{proportionally}'}';
Parameter_Symbol_text      = {'$\psi$','$\lambda_{\theta}$','$b$','$\mu_{N,u}$','$\sigma_{k}^{2}$','$\rho_{k}$','$\zeta_{P}$','$\theta_{n}$','$\eta$'}';
Parameter_Description_text = {'Marginal disutility labor','Skill scaling factor','Altruism coefficient (share $\beta$)','Ave. app. cost in utils','Variance of $\log\left(\theta_{k}\right)$','Intergen. persistence of skill','SS replacement rate','Childcare productivity','Childcare pre-policy price ratio'};
Moment_Description_text    = {'Age 25-55 average hours labor $h$','Age 20 average hours childcare $n$','Age 20 Corr$\left(\theta_{k}^{a*}, y^{*}\right)$','Age 20 share receiving CCDF','Age 25-34 $\log\left(y\right)$ p50-p10','Age 20 Corr$\left(\theta_{k},\theta_{a}\right)$','SS spending (share output)','Age 20 workers ave. log prod. ratio','Age 20 workers price ratio'};
DataMoment_values_print  = DataMoment_values_policy_mat_C5_3(:,1)'; DataMoment_values_print(7) = 0.01*DataMoment_values_print(7);
ModelMoment_values_print = ModelMoment_values_policy_mat_C5_3(:,1)'; 
Parameter_values_print  = [Parameter_values_policy_mat_C5_3(1:8,1); Parameter_values_policy_mat_C5_3(10,1)]';
T_tex= []; T_tex = table(Panel_label_text(:),Parameter_Symbol_text(:),Parameter_Description_text(:),Parameter_values_print(:),Moment_Description_text(:),DataMoment_values_print(:),ModelMoment_values_print(:),...
    'VariableNames',{'\textbf{Category}','\textbf{Sym.}','\textbf{Parameter description}','\textbf{Value}','\textbf{Moment description}','\textbf{Data}','\textbf{Model}'});
% For tex file called by manuscript:
texfilename_temp = strcat(draft_output_path,'Pars_calibrated_utilitycost.tex');
delete(texfilename_temp);
table2latex_formatted_egm(T_tex,7,tex_table_number_format,0,texfilename_temp);
disp(' '); disp('Table C.25'); disp(' '); disp(T_tex)

% ---> Table C.26: utility cost specification  
% For tex file called by manuscript:
Atemp = []; Atemp = round(Array_Policy_counterfactuals_C5_3,tex_table_number_rounding);
T_tex= []; T_tex = table(Rownames_AggregatesPanels',Rownames_AggregatesVars',Atemp(Array_rows_vec_draft,1),Atemp(Array_rows_vec_draft,2),Atemp(Array_rows_vec_draft,4),...
    'VariableNames',{'\textbf{Variable category}','\textbf{Variable description}','\textbf{Baseline}','\textbf{(1) CTC}','\textbf{(2) CCDF}'}); 
texfilename_temp = strcat(draft_output_path,'UtilityCostRobustness.tex');
delete(texfilename_temp);
table2latex_formatted_egm(T_tex,3,tex_table_number_format,0,texfilename_temp);
disp(' '); disp('Table C.26'); disp(' '); disp(T_tex)

% ---> Figure C.11(a) and (b) - utility cost specification CCDF application
% and receipt by thetaa and thetak before and after expansion
% Composition of new CCDF recipients is high-theta, low fixed cost, so big skill changes don't happen and many low-theta now pay higher taxes.
% binning_variable_index = 1: Bin1 = Thetaa , Bin2 = thetak
% binning_variable_index = 2: Bin1 = y , Bin2 = thetak
% binning_variable_index = 3: Bin1 = thetaa , Bin2 = fc
% binning_variable_index = 4: Bin1 = y , Bin2 = fc 
close all;  
x_discrete = repmat(linspace(1,number_bins,number_bins),[number_bins 1]); 
x_discrete = x_discrete(:);
y_discrete = repmat(linspace(1,number_bins,number_bins),[1 number_bins])';

for Policy_vec_index = [1 4]
for binning_variable_index = 1
    hFig = figure(binning_variable_index);
    if binning_variable_index == 1
        filename_temp = strcat(draft_output_path,'FigCCDF_thetaa_thetak_C5', num2str(Policy_vec_index),'.png');
    elseif binning_variable_index == 3
        filename_temp = strcat(draft_output_path,'FigCCDF_thetaa_fixedcost_C5', num2str(Policy_vec_index),'.png');
    end  
    for graphing_var_index = 1:3          
        subplot(1,3,graphing_var_index);
        if binning_variable_index == 1 
            xlabeltext = 'Adult skill'; ylabeltext = 'Child skill endowment'; 
        elseif binning_variable_index == 3
            xlabeltext = 'Adult skill'; ylabeltext = 'Application cost'; 
        end  
        if graphing_var_index == 1
            CCDF_pct_bin_temp = 100*squeeze(share_eligible_ccdf_2bin_C5_3(binning_variable_index,:,:,Policy_vec_index))'; % orginal: row is thetaa/incq, column is thetak; this makes row thetak, column thetaa/incq
            texttitle = 'Eligible (fixed labor)';
        elseif graphing_var_index == 2
            CCDF_pct_bin_temp = 100*squeeze(share_apply_ccdf_wfc_2bin_C5_3(binning_variable_index,:,:,Policy_vec_index))'; % orginal: row is thetaa/incq, column is thetak; this makes row thetak, column thetaa/incq
            texttitle = 'Applied';
        else
            CCDF_pct_bin_temp = 100*squeeze(share_received_ccdf_2bin_C5_3(binning_variable_index,:,:,Policy_vec_index))'; % orginal: row is thetaa/incq, column is thetak; this makes row thetak, column thetaa/incq
            texttitle = 'Received';
        end
        tbl = table(x_discrete,y_discrete,CCDF_pct_bin_temp(:), 'VariableNames', {'x', 'y', 'z'}); 
        h = heatmap(tbl,'x','y','ColorVariable','z','ColorMethod','mean', 'FontName', 'Times New Roman');xlabel(xlabeltext); ylabel(ylabeltext); 
        set(gcf, 'Position',  [100,100,1100,350]);
        h.ColorbarVisible = 'off';
        h.NodeChildren(3).YDir='normal';
        h.MissingDataLabel = ' ';
        h.MissingDataColor = [1 1 1];
        h.CellLabelFormat = '%.0f';
        h.Title = texttitle;
        h.FontSize = 18; 
        h.FontName = font_name;     
    end
    delete(filename_temp); 
    pause(5) 
    exportgraphics(hFig,filename_temp);
    
end
end
close all;
% ---> Figure C.12(a): CTC distribution of spending and recipients, model v data 
% CTC distribution of spending and recipients in model v data
hFig = figure(4);   
subplot(1,2,1);
b1 = bar([ squeeze(amt_ctc_bin_C5_3(4,:,1,1)./sum(amt_ctc_bin_C5_3(4,:,1,1)))'  sharespendingctc(:) ],0.8,"FaceAlpha",0.5,'FaceColor','flat' ); 
grid on;  axis square;
xlabel('Pretax income bin','Interpreter','latex'); 
ylim([0 1]); ylabel('Share of spending','Interpreter','latex'); ytickformat('%.1f'); 
set(gca,'Fontsize',fontsz,'FontName',font_name,'xcolor','k','ycolor','k','TickLength',[0.0,0.0]);
hleglines = [b1(1) b1(2)]; 
title('Share of spending');
b1(2).CData =  0.6*[0 0.6 0.3];  
lgd = legend(hleglines,'Model','Data','Interpreter','latex','Location','NorthEast','NumColumns',1,'FontSize',12);
legend boxoff;
subplot(1,2,2);
CTC_share_bin_temp = squeeze(mass_ctc_bin_C5_3(4,:,1,1))';
CTC_share_bin_temp = CTC_share_bin_temp./sum(CTC_share_bin_temp(:));
b1 = bar([CTC_share_bin_temp sharereceiptctc(:) ],0.8,"FaceAlpha",0.5,'FaceColor','flat' ); 
grid on;  axis square;
xlabel('Pretax income bin','Interpreter','latex'); 
ylim([0 1]); ylabel('Share of recipients','Interpreter','latex'); ytickformat('%.1f'); 
set(gca,'Fontsize',fontsz,'FontName',font_name,'xcolor','k','ycolor','k','TickLength',[0.0,0.0]);
hleglines = [b1(1) b1(2)]; 
b1(2).CData =  0.6*[0 0.6 0.3];  
title('Share of recipients'); 
lgd = legend(hleglines,'Model','Data','Interpreter','latex','Location','NorthEast','NumColumns',1,'FontSize',12);
% title(lgd,'\underline{\textbf{Source:}}','FontWeight','bold','FontSize',12); 
legend boxoff;
filename_temp = strcat(draft_output_path,'FigCTC_SpendingShare_ybin_data_and_modelUC.png');
delete(filename_temp);
pause(5);
exportgraphics(hFig,filename_temp); 
close all;

% --> Figure C.12(b) CCDF distribution of spending and recipients in model v data
hFig = figure(5);   
subplot(1,2,1);
b1 = bar([ squeeze(amt_ccdf_bin_C5_3(4,:,1,1)./sum(amt_ccdf_bin_C5_3(4,:,1,1)))'  sharespendingccdf(:) ],0.8,"FaceAlpha",0.5,'FaceColor','flat' ); 
grid on;  axis square;
xlabel('Pretax income bin','Interpreter','latex'); 
ylim([0 1]); ylabel('Share of spending','Interpreter','latex'); ytickformat('%.1f'); 
set(gca,'Fontsize',fontsz,'FontName',font_name,'xcolor','k','ycolor','k','TickLength',[0.0,0.0]);
hleglines = [b1(1) b1(2)]; 
title('Share of spending');
lgd = legend(hleglines,'Model','Data','Interpreter','latex','Location','NorthEast','NumColumns',1,'FontSize',12);
legend boxoff;
subplot(1,2,2);
CCDF_share_bin_temp = squeeze(mass_ccdf_bin_C5_3(4,:,1,1))';
CCDF_share_bin_temp = CCDF_share_bin_temp./sum(CCDF_share_bin_temp(:));
b1 = bar([CCDF_share_bin_temp sharereceiptccdf(:) ],0.8,"FaceAlpha",0.5,'FaceColor','flat' ); 
grid on;  axis square;
xlabel('Pretax income bin','Interpreter','latex'); 
ylim([0 1]); ylabel('Share of recipients','Interpreter','latex'); ytickformat('%.1f'); 
set(gca,'Fontsize',fontsz,'FontName',font_name,'xcolor','k','ycolor','k','TickLength',[0.0,0.0]);
hleglines = [b1(1) b1(2)]; 
title('Share of recipients'); 
lgd = legend(hleglines,'Model','Data','Interpreter','latex','Location','NorthEast','NumColumns',1,'FontSize',12);
% title(lgd,'\underline{\textbf{Source:}}','FontWeight','bold','FontSize',12); 
legend boxoff;
filename_temp = strcat(draft_output_path,'FigCCDF_SpendingShare_ybin_data_and_modelUC.png');
delete(filename_temp);
pause(5);
exportgraphics(hFig,filename_temp); 
close all;
  