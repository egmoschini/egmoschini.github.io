Paper title: Family Policies and Child Skill Accumulation
Authors: Emily G. Moschini (corresponding author) and Monica Tran-Xuan  

Download and extract the zipped replication package at: https://egmoschini.github.io/MTX_RED_replication_package.zip
 
Directions for replication:  
* For each Figure, Table, etc. Replication_outline.xlsx maps to a file in the replication package or directs you to citation in the text. 
* When appropriate, open indicated file and follow directions.
* Replication package contains processed MATLAB output and final empirical estimation results used in the paper. Raw data and raw MATLAB output are not included.
* Memory requirement with all raw data and MATLAB output: 1.55 GB.

Raw data:   
* 2 public datasets need to be downloaded to re-run full set of Stata codes. 
* If this is necessary to download this data to replicate the desired output, it will be noted and directions provided by the replication file indicated in Replication_outline.xlsx. 

Raw MATLAB output:
* To re-generate raw MATLAB output, re-run the set of codes associated with the desired output. 
* If the codes call output from another set which needs to be run first, it will be noted in the MATLAB code explanation in Replication_outline.xlsx  

Software, operating system, and runtimes:  

MATLAB   
* Software: MATLAB 2022b with Parallel computing toolbox, using 64 workers 
* Processor: Desktop PC Intel Xeon Gold 6130 CPU @ 2.10GHz (2 processors) 
* Operating system: 64-bit Windows 10 Enterprise OS build 19043.1348   
* Runtime: main text exercises take 45 mins, with more details in tab "Guide to Model_codes folder" of Replication_outline.xlsx. Runtimes may vary across computers    

Stata   
* Software: Stata 18 SE
* Processor: Intel(R) Core(TM) Ultra 7 165U @ 1.70 GHz
* Operating system: 64-bit Windows 11 Pro build 22631.4602   
* Runtime: about 2 minutes for longest-running set of Stata file    