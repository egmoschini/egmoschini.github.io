To get CPI go here: https://data.bls.gov/cgi-bin/srgate

Enter the series nam: CUUR0000SA0

Choose the years, select HTML table and annual, download the excel file provided on the next page. 
