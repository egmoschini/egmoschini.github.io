%% Wage growth - Panel B, table 3 Lagakos et al 2018, and Figure 1 
close all; clear all; clc;
annual_growth = 0.05;
wage_growth_lifecycle_aux = .8; 
beta1 = 0.425;
beta2 = -0.0605;
beta3 =  0.001;
% Targets from Panel B, table 3
target1 = 42.4;  
target2 = 93.2;  
target3 = 96.7;   
n_theta = 1;
theta_grid = 0.1; %linspace(0.01,2,n_theta);
J = 11; j_r=9; j_a=4;
res = 1;
while max(res)>10^-4
    theta_profile_grid = zeros(n_theta,J);
    for theta_index = 1:n_theta 
        theta_profile_grid(theta_index,1) = theta_grid(theta_index);
        wage_growth_age_mat(theta_index,1) = 0;
            for age = 2:J
                wage_growth_age = beta1*(age-1)+beta2*(age-1)^2+beta3*(age-1)^3; %beta1*(age-1)^beta2; %beta1*(age-1)^beta2; %w
                theta_profile_grid(theta_index,age) =  theta_profile_grid(theta_index,1)*(1+wage_growth_age);
%                 wage_growth_age_mat(theta_index,age) = 100*(theta_profile_grid(theta_index,age)/theta_profile_grid(theta_index,1) - 1);
%                 period_growth_mat(theta_index,age) = 100*(theta_profile_grid(theta_index,age)/theta_profile_grid(theta_index,age-1) - 1);
%                 period_growth_old_mat(theta_index,age) = 100*wage_growth_lifecycle_aux^(age-1);
            end 
    end

    period_growth_mat1 = 100*(theta_profile_grid(1,2)/theta_profile_grid(1,1) - 1); % 36.6
    period_growth_mat2 = 100*(theta_profile_grid(1,5)/theta_profile_grid(1,1) - 1); % 88.7
    period_growth_mat3 = 100*(theta_profile_grid(1,8)/theta_profile_grid(1,1) - 1); % 88.1
    
    res = abs([period_growth_mat1 - target1 (period_growth_mat2 - target2) (period_growth_mat3 - target3)]);
    beta1 = beta1*(period_growth_mat1/target1)^(-0.1);
    beta2 = beta2*(period_growth_mat2/target2)^(0.1);
    beta3 = beta3*(period_growth_mat3/target3)^(-0.1); 
    
    disp(res);
end
disp('========')
disp(['Parameter values     : ' num2str(beta1,'  %0.7f, ') num2str(beta2,'%0.7f, ') num2str(beta3,'  %0.7f ') ]);
disp(['Lagakos et al Table 2: ' num2str(target1,'  %0.1f, ') num2str(target2,'%0.1f, ') num2str(target3,'  %0.1f ') ])
disp(['Output moments compar: ' num2str(period_growth_mat1,'  %0.1f, ') num2str(period_growth_mat2,'%0.1f, ') num2str(period_growth_mat3,'  %0.1f ') ])
  

