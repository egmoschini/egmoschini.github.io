% This uses Table D.3 in the Online appendix of Guzman 2019 

% The application rates across states in 1999 and 2002, and the means in each year are: 
close all; 
vec_99 = [0.11 0.1 0.11 0.13 0.17 0.13 0.17 0.08 0.09 0.13 0.06 0.18 0.15];
mean_99 = 0.12;
vec_02 = [.11 0.06 0.12 0.11 0.14 0.09 0.16 0.10 0.08 0.09 0.06 0.18 0.08];
mean_02 = 0.10;

% the variance around the mean in each year is: 
var(vec_99./mean_99)
var(vec_02./mean_02)

% The average of the variance around the mean across the two years is; 
disp(0.5*(var(vec_99./mean_99) + var(vec_02./mean_02))) % which is 0.1135.

