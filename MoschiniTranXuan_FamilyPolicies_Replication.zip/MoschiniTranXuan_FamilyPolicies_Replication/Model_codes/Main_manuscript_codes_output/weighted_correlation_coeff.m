function [rho] = weighted_correlation_coeff(x_var,y_var,w_var)
wmean_x = sum(x_var(:,1).*w_var);
wmean_y = sum(y_var(:,1).*w_var); 
wcov_xy= sum(w_var.*(x_var-wmean_x).*(y_var-wmean_y),'all');
wcov_yy = sum(w_var.*(y_var-wmean_y).*(y_var-wmean_y),'all');
wcov_xx = sum(w_var.*(x_var-wmean_x).*(x_var-wmean_x),'all');
rho = wcov_xy/((wcov_xx*wcov_yy)^(0.5));   
end