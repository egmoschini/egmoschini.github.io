diary on; 

if Policy_vec_index>1
    disp(['POLICY COUNTERFACTUAL COMPLETED. Total time: ' num2str(toc(tstart_EquLoop)) ' , ' num2str(Policy_vec_index) ', ' num2str(policy_iter_count)]); diary off;
elseif Run_calibration ==1 
    disp(['CALIBRATION ITERATION COMPLETED. Total time: ' num2str(toc(tstart_EquLoop)) ' , ' num2str(Policy_vec_index) ', ' num2str(calibration_iter_count) ', ' num2str(policy_iter_count)]); diary off;
else
    disp(['BASELINE EQUILIBRIUM COMPLETED. Total time: ' num2str(toc(tstart_EquLoop)) ' , ' num2str(Policy_vec_index) ', ' num2str(policy_iter_count)]); diary off;    
end

% checking investment aggregation:  
% par_prod = theta_grid(type_mat(:,1))';
% n_prod = thetan;
% inv_check = (((theta_grid(theta_opt(:,1))'./lambda_I).^(1-1/chi) - (1-upsilon)*thetak_grid(type_mat(:,2))'.^(1-1/chi))/upsilon).^(chi/(chi-1));
% inv_real  = (gamma*(par_prod.*q_opt(:,1)).^(1-1/nu) + (1-gamma)*(n_prod.*n_opt(:,1)).^(1-1/nu)).^(nu/(nu-1));
% binding_time = (q_opt(:,1) + n_opt(:,1)==1);
% resinv = (inv_check - inv_real); 

% Calibration moments values
par_weights  = Omega_dist(:,1)/sum(Omega_dist(:,1));
prime_working_age_weights = Omega_dist(:,2:7)./sum(Omega_dist(:,2:7),'all'); % ages 25 - 55 to match CPS and GRID moments
h_hours      = sum(h_opt(:,2:7).*prime_working_age_weights,'all');  
n_hours      = sum(n_opt(:,1).*par_weights(:)); 
q_hours      = sum(q_opt(:,1).*par_weights(:)); 
qn_ratio     = sum(q_opt(:,1).*par_weights(:)./n_opt(:,1)); 
[rho_thetay] = weighted_correlation_coeff(y_opt(:,1),theta_opt(:,1),par_weights);
CCDF_receipt  = sum((gov_cc_expense_opt(:,1)>0).*par_weights);
CCDF_eligible = sum((CCDF_toggle == 2).*(y_opt(:,1)<=CCDF_policy_mat(1)).*(h_opt(:,1)>0).*par_weights);   
CCDF_uptake   = CCDF_receipt/CCDF_eligible;
[rho_initialskill] = weighted_correlation_coeff(theta_grid(type_mat(:,1))',thetak_grid(type_mat(:,2))',par_weights);
 
% rank-rank correlation (Chetty et al 2014)  
% Need to take expectation over child income as adult conditional on adult type over
% own child type and subsidy receipt.
parent_j = j_a; % SEE SECTION iv.a PAGE 1569 IN CHETTY ET AL 2014
kid_j = 3;
y_par_theta = zeros(n_theta,n_thetak,n_ccsub_types); 
y_kid_theta = zeros(n_theta,n_thetak,n_ccsub_types); 
weight_ykid = zeros(n_theta,n_thetak,n_ccsub_types);

for type_index = 1:n_types
    theta_index  = type_mat(type_index,1);
    thetak_index = type_mat(type_index,2); 
    cc_r_index   = type_mat(type_index,3);  
    cc_fc_index  = type_mat(type_index,4); 
    y_par_theta(theta_index,thetak_index,cc_r_index,cc_fc_index) = y_opt(type_index,parent_j); 
    y_kid_theta(theta_index,thetak_index,cc_r_index,cc_fc_index) = y_opt(type_index,kid_j); 
    weight_ykid(theta_index,thetak_index,cc_r_index,cc_fc_index) = Omega_dist(type_index,kid_j);    
end

for theta_index = 1:n_theta
    weight_ykid(theta_index,:,:,:) = weight_ykid(theta_index,:,:,:)./sum(weight_ykid(theta_index,:,:,:),'all');
end
wy_kid_theta = weight_ykid.*y_kid_theta;
rrcorr_dist      = zeros(n_types,5);  
for type_index = 1:n_types
    theta_index  = type_mat(type_index,1);
    thetak_index = type_mat(type_index,2); 
    cc_r_index   = type_mat(type_index,3);
    cc_fc_index  = type_mat(type_index,4); 
    rrcorr_dist(type_index,1) = y_par_theta(theta_index,thetak_index,cc_r_index,cc_fc_index);
    rrcorr_dist(type_index,2) = sum(wy_kid_theta(theta_opt(type_index,1),:,:),'all'); % expected income
    rrcorr_dist(type_index,3) = par_weights(type_index);
end 
 
rrcorr_dist      = sortrows(rrcorr_dist,1);
for order_index = 1:n_types
    rrcorr_dist(order_index,4) = order_index;
end
 
rrcorr_dist      = sortrows(rrcorr_dist,2);
for order_index = 1:n_types
    rrcorr_dist(order_index,5) = order_index;
end
[rho_rry] = weighted_correlation_coeff(rrcorr_dist(:,4),rrcorr_dist(:,5),rrcorr_dist(:,3));

% Note on GRID methodology: for inequality stats, need to include only those with pretax income
% above a certain lower bound and up to the 99.999999 percentile  
% in 2016, 2.7% of all hourly workers were paid at or below the
% federal minimum wage. 58.7% of all workers were hourly. This represents 1.58%
% of all workers who are paid at or below the federal minimum. 
% The minimum threshold is some proportion of the minimum federal wage. 
% Wages are analogous to the skill of adults in the model. So dropping
% those who earn below some fraction of the minimum wage is like dropping
% adults with skill below a certain threshold. 
% The model moments for inequality should therefore discard those adults in
% the selected age range whose adult skill is below percentile of the skill
% distribution among all adult workers, taking into account wage growth over
% the life cycle. 
for theta_index = 1:n_theta  
    for age = 1:J
        labor_eff_units = theta_grid(theta_index);
        wage_growth_age = beta1_wagegrowth*(age-1) + beta2_wagegrowth*(age-1)^2 + beta3_wagegrowth*(age-1)^3;
        theta_profile_grid(theta_index,age) = labor_eff_units*(1+wage_growth_age);
    end
end 
parfor type_index = 1:n_types
    for age = 1:J
        theta_index  = type_mat(type_index,1); 
        thetak_index = type_mat(type_index,2);
        cc_a_r_index = type_mat(type_index,3);
        cc_fc_index  = type_mat(type_index,4);     
        wage_dist_levels(type_index,age) = theta_profile_grid(theta_index,age);
    end
end
wage_dist      = []; h_temp = []; y_temp = []; Omega_dist_temp= [];
y_temp = y_opt(:,1:j_r-1); h_temp = h_opt(:,1:j_r-1); logy_temp = log(y_temp(:)); 
wage_temp = wage_dist_levels(:,1:j_r);
Omega_dist_temp_aux = Omega_dist(:,1:j_r-1); Omega_dist_temp_aux = Omega_dist_temp_aux./sum(Omega_dist_temp_aux(:)); Omega_dist_temp = Omega_dist_temp_aux(:);
flag_working = (h_temp(:)>0); 
wage_dist      = [wage_temp((flag_working==1)) Omega_dist_temp((flag_working==1))];
wage_dist      = sortrows(wage_dist,1);
wage_dist(:,3) = cumsum(wage_dist(:,2));
[~,pminthresholdyarg]      = min(abs(wage_dist(:,3)-0.0158));
[~,pmaxthresholdyarg]      = min(abs(wage_dist(:,3)-0.9999)); %0.99999999
thetaminthreshold_GRID = wage_dist(pminthresholdyarg,1);
thetamaxthreshold_GRID = wage_dist(pmaxthresholdyarg,1);

% % Pretax income inequality stats - to match GRID moments 25-55 
% income_dist      = []; y_temp = []; Omega_dist_temp= [];
% y_temp = y_opt(:,2:7); logy_temp = log(y_temp(:));  
% h_temp = h_opt(:,2:7); 
% wage_temp = wage_dist_levels(:,2:7);
% flag_working_and_in_wagerange = (h_temp(:)>0).*(wage_temp(:)>thetaminthreshold_GRID).*(wage_temp(:)<thetamaxthreshold_GRID); 
% Omega_dist_temp_aux = Omega_dist(:,2:7); Omega_dist_temp_aux = Omega_dist_temp_aux./sum(Omega_dist_temp_aux(:)); Omega_dist_temp = Omega_dist_temp_aux(:);
% income_dist      = [logy_temp((flag_working_and_in_wagerange==1)) Omega_dist_temp((flag_working_and_in_wagerange==1))./sum(Omega_dist_temp((flag_working_and_in_wagerange==1)))];
% income_dist      = sortrows(income_dist,1);
% income_dist(:,3) = cumsum(income_dist(:,2));
% [~,p1yarg]      = min(abs(income_dist(:,3)-0.05));
% [~,p90yarg]      = min(abs(income_dist(:,3)-0.9));
% [~,p75yarg]      = min(abs(income_dist(:,3)-0.75));    
% [~,p50yarg]      = min(abs(income_dist(:,3)-0.5));
% [~,p10yarg]      = min(abs(income_dist(:,3)-0.1));
% p90_yGRID            = income_dist(p90yarg,1);
% p75_yGRID            = income_dist(p75yarg,1);
% p50_yGRID            = income_dist(p50yarg,1);
% p10_yGRID            = income_dist(p10yarg,1);
% p01_yGRID            = income_dist(p1yarg,1);
%  
% Pretax income inequality stats - to match GRID moments 25-34 
income_dist      = []; y_temp = []; Omega_dist_temp= [];
y_temp = y_opt(:,2:3); logy_temp = log(y_temp(:));  
h_temp = h_opt(:,2:3); 
wage_temp = wage_dist_levels(:,2:3);
flag_working_and_in_wagerange = (h_temp(:)>0).*(wage_temp(:)>thetaminthreshold_GRID).*(wage_temp(:)<thetamaxthreshold_GRID); 
Omega_dist_temp_aux = Omega_dist(:,2:3); Omega_dist_temp_aux = Omega_dist_temp_aux./sum(Omega_dist_temp_aux(:)); Omega_dist_temp = Omega_dist_temp_aux(:);
income_dist      = [logy_temp((flag_working_and_in_wagerange==1)) Omega_dist_temp((flag_working_and_in_wagerange==1))./sum(Omega_dist_temp((flag_working_and_in_wagerange==1)))];
income_dist      = sortrows(income_dist,1);
income_dist(:,3) = cumsum(income_dist(:,2));
[~,p95yarg]      = min(abs(income_dist(:,end)-0.95));
[~,p91yarg]      = min(abs(income_dist(:,end)-0.91));
[~,p90yarg]      = min(abs(income_dist(:,end)-0.9));
[~,p89yarg]      = min(abs(income_dist(:,end)-0.89));
[~,p85yarg]      = min(abs(income_dist(:,end)-0.85));
[~,p75yarg]      = min(abs(income_dist(:,end)-0.75));    
[~,p50yarg]      = min(abs(income_dist(:,end)-0.5));
[~,p10yarg]      = min(abs(income_dist(:,end)-0.1));

p90_yparGRID            = income_dist(p90yarg,1);
p75_yparGRID            = income_dist(p75yarg,1);
p50_yparGRID            = income_dist(p50yarg,1);
p10_yparGRID            = income_dist(p10yarg,1);

p95_yparGRID            = income_dist(p95yarg,1);
p91_yparGRID            = income_dist(p91yarg,1);
p89_yparGRID            = income_dist(p89yarg,1);
p85_yparGRID            = income_dist(p85yarg,1); 

% Structural objects from baseline
theta_grid_policy_mat(:,Policy_vec_index) = theta_grid;
thetak_dist_policy_mat(:,:,Policy_vec_index) = thetak_dist;
thetan_policy_mat(:,:,Policy_vec_index)   = thetan;
pn_ratio_adjusted_policy_mat(Policy_vec_index) = pn_ratio_adjusted;
chi_c_policy_mat(Policy_vec_index) = chi_c;

% Policy loop output and welfare changes versus baseline 
V1_realized_policy_mat(:,Policy_vec_index)   = V_opt_realized(:,1);
V1_policy_mat(:,Policy_vec_index)            = V_opt(:,1);
Vkid_policy_mat(:,Policy_vec_index)          = Vkid';
skill_dist_policy_mat(:,Policy_vec_index)    = skill_dist'; 
thetaa_policy_mat(:,:,Policy_vec_index)        = thetaa_opt;
Omega_dist_policy_mat(:,:,Policy_vec_index)  = Omega_dist; 
V_opt_policy_mat(:,:,Policy_vec_index)       = V_opt;
V_opt_realized_policy_mat(:,:,Policy_vec_index) = V_opt_realized;
theta_opt_policy_mat(:,:,Policy_vec_index)   = theta_opt; 
n_opt_policy_mat(:,:,Policy_vec_index)       = n_opt;
q_opt_policy_mat(:,:,Policy_vec_index)       = q_opt;
h_opt_policy_mat(:,:,Policy_vec_index)       = h_opt;
c_opt_policy_mat(:,:,Policy_vec_index)       = c_opt;
y_opt_policy_mat(:,:,Policy_vec_index)       = y_opt;
yd_opt_policy_mat(:,:,Policy_vec_index)      = yd_opt;
ccdf_app_opt_policy_mat(:,:,Policy_vec_index) = ccdf_app_opt;
ccdf_fc_opt_policy_mat(:,:,Policy_vec_index) = ccdf_fc_opt;
EITC_opt_policy_mat(:,:,Policy_vec_index) = EITC_policy_mat;
CTC_opt_policy_mat(:,:,Policy_vec_index)  = CTC_policy_mat;
TANF_opt_policy_mat(:,:,Policy_vec_index) = TANF_policy_mat;
CCDF_opt_policy_mat(:,:,Policy_vec_index) = CCDF_policy_mat; 

EITC_received_opt_policy_mat(:,:,Policy_vec_index)       = EITC_received_opt;
CTC_received_opt_policy_mat(:,:,Policy_vec_index)        = CTC_received_opt;
TANF_received_opt_policy_mat(:,:,Policy_vec_index)       = TANF_received_opt;
CCDF_received_opt_policy_mat(:,:,Policy_vec_index)       = gov_cc_expense_opt;
gov_cc_expense_opt_policy_mat(:,:,Policy_vec_index)      = gov_cc_expense_opt;
tax_credits_transf_opt_policy_mat(:,:,Policy_vec_index)  = tax_credits_transf_opt;
taxes_paid_opt_policy_mat(:,:,Policy_vec_index)          = taxes_paid_opt;
ave_fc_pct_yp50_policy_mat(Policy_vec_index)             = ave_fc_pct_yp50;

% Use total government spending, not just spending on CTC and CCDF
target_pct_Y_CTC_CCDF_policy_mat(Policy_vec_index) = 100*sum((gov_cc_expense_opt(:)+CTC_received_opt(:)).*Omega_dist(:))/GDP;
target_pct_Y_G_policy_mat(Policy_vec_index) = 100*sum((gov_cc_expense_opt(:)+tax_credits_transf_opt(:)+ThetaG*GDP).*Omega_dist(:))/GDP; 
Policy_pars_mat_outputs(Policy_vec_index,:) = [subsidy_chic, rationing_rate, yp_cutoff, subsidy_b0, subsidy_b1, transfer_proportion1, transfer_proportion2, refund_threshold, phaseout_threshold] ;

GE_objects_policy_mat(:,Policy_vec_index)    = [GDP pn thetan yp50 lambda_y cutoffpctiley]'; 
pension_lvl_policy_mat(:,Policy_vec_index)   = pension_lvl;
GE_quantities_policy_mat(:,Policy_vec_index) = [n_hours q_hours h_hours rho_thetay rho_rry]';
Exp_G_policy_mat(:,Policy_vec_index)         = 100*[sum(tax_credits_transf_opt(:).*Omega_dist(:))/GDP ,sum(gov_cc_expense_opt(:).*Omega_dist(:))/GDP, sum((tax_credits_transf_opt(:) + gov_cc_expense_opt(:)).*Omega_dist(:))/GDP];
Recipients_G_policy_mat(:,Policy_vec_index)  = 100*[sum((tax_credits_transf_opt(:,1:j_a)>0).*Omega_dist(:,1:j_a)/sum(Omega_dist(:,1:j_a))) ,sum((gov_cc_expense_opt(:,1)>0).*Omega_dist(:,1)/sum(Omega_dist(:,1)))];

tot_G_spending_SS_policy_mat_aftx(Policy_vec_index)        = 100*sum(yd_opt_policy_mat(:,j_r:J,Policy_vec_index).*Omega_dist_policy_mat(:,j_r:J,Policy_vec_index),'all')/GE_objects_policy_mat(1,Policy_vec_index);
tot_G_spending_SS_policy_mat_pretax(Policy_vec_index)      = 100*sum(repmat(pension_lvl_policy_mat(:,Policy_vec_index),[1 J-j_r+1]).*Omega_dist_policy_mat(:,j_r:J,Policy_vec_index),'all')/GE_objects_policy_mat(1,Policy_vec_index);
tot_G_spending_family_policy_mat(Policy_vec_index)         = 100*sum((CCDF_received_opt_policy_mat(:,:,Policy_vec_index) + EITC_received_opt_policy_mat(:,:,Policy_vec_index) + CTC_received_opt_policy_mat(:,:,Policy_vec_index) + TANF_received_opt_policy_mat(:,:,Policy_vec_index)).*Omega_dist_policy_mat(:,:,Policy_vec_index),'all')/GE_objects_policy_mat(1,Policy_vec_index);
 
res_vec_policy_mat(:,Policy_vec_index) = res_vec;
res_policy_equiv_policy_mat(Policy_vec_index) = res_policy_equiv;
value_policy_equiv_par_policy_mat(Policy_vec_index) = value_policy_equiv_par;

% Welfare changes - Make sure to adjust for appropriate utility function...
% denomW = 0; % for welfare change calculations
% for age = 1:J
%     denomW = denomW + beta^(age-1);
% end
% Welfare_change_theta(:,Policy_vec_index)     = exp((V1_realized_policy_mat(:,Policy_vec_index) - V1_realized_policy_mat(:,1))/(denomW));
% Welfare_change_pct1(Policy_vec_index)        = 100*(sum(Omega_dist(:,1).*J.*Welfare_change_theta(:,Policy_vec_index)) - 1);
% Wbsl = sum(Omega_dist_policy_mat(:,1,1).*J.*V1_realized_policy_mat(:,1));
% Wnew = sum(Omega_dist_policy_mat(:,1,Policy_vec_index).*J.*V1_realized_policy_mat(:,Policy_vec_index));
% Welfare_change_pct0(Policy_vec_index)      = 100*(exp((Wnew - Wbsl)/(denomW)) - 1);
% 
% V_check = V_opt_policy_mat(:,1);
% 
% for age = 1:J
%     LS_by_age(age) = sum(h_opt(:,age).*Omega_dist(:,age)*J);
%     LSstd_by_age(age) = std(h_opt(:,age),Omega_dist(:,age)*J);
% end

% Calibration moments and parameter values for Calibration table printing
DataMoment_values_policy_mat(:,Policy_vec_index)  = [Laborsupply_target N_hours_target Corrincskill_target CCDF_receipt_target GRIDparp50p10_target Corrinitialskill_target SS_spending_percentageY 0.000 pn_ratio_observed]';
ModelMoment_values_policy_mat(:,Policy_vec_index) = [h_hours n_hours rho_thetay CCDF_receipt p50_yparGRID - p10_yparGRID rho_initialskill 0.01*tot_G_spending_SS_policy_mat_pretax(Policy_vec_index) 0.000 pn/(sum(par_weights(:).*wage_aftx(:))/sum(par_weights(:).*(1-subsidy_correction(:))))]';
Parameter_values_policy_mat(:,Policy_vec_index)   = [psi lambda_I b/beta chi_c_fraction varlogthetak initial_corr_par pension_rep_rate thetan chi_c pn_ratio_adjusted]';

% Spending share of GDP and share of population(s) receiving
Spending_pctage_of_GDP_policy_mat(:,Policy_vec_index) = [100*sum(gov_cc_expense_opt(:).*Omega_dist(:)) 100*sum(EITC_received_opt(:).*Omega_dist(:)) 100*sum(CTC_received_opt(:).*Omega_dist(:)) 100*sum(TANF_received_opt(:).*Omega_dist(:))]./GDP;
Spending_pctage_of_pop_receiving_policy_mat(:,Policy_vec_index) = [100*sum((gov_cc_expense_opt(:,1)>0).*par_weights) 100*sum((EITC_received_opt(:)>0).*Omega_dist(:)) 100*sum((CTC_received_opt(:)>0).*Omega_dist(:)) 100*sum((TANF_received_opt(:,1)>0).*par_weights(:))];

diary on;
disp('==============================='); 
disp(['Specific policy [EITC CTC TANF CCDF]      = ' num2str(Policy_toggle_vec-1) ]);
disp(['Equilibrium concept vec [μ(Θ) Vk(Θ) λ_y pn yp50 pension]  = ' num2str(GE_toggle_mat(Policy_vec_index,:)) ]);
disp(['Policy_vec inputs   = ' num2str(Policy_pars_mat_inputs(Policy_vec_index,:),' %0.4g ')]);
disp(['Policy_vec outputs  = ' num2str(Policy_pars_mat_outputs(Policy_vec_index,:),' %0.4g ')]);
disp(['CCDF uptake cost χ_c χ_u: ' num2str([chi_c chi_u] , ' %0.4f' )]);
disp(['Time in seconds for policy experiment = ' num2str(toc(tstart_policyloop))] );
disp(['GE Residual vector for policy experiment = ' num2str(res_vec)] );
disp(['GE Iteration Count = ' num2str(GE_iteration_count)] );
% disp(['Cal index = ' num2str(calibration_iter_count)] );
disp('GE outcome: ');
disptext = ['Θ grid = ', '[' num2str(theta_grid,'%0.3f ') ']']; disp(disptext);
disptext = ['μ(Θ)   = ', '[' num2str(skill_dist,'%0.3f ') ']']; disp(disptext);
disptext = ['Vk(Θ)  = ', '[' num2str(Vkid,'%0.3f ') ']']; disp(disptext);
disptext = ['R.C.   = ',   num2str((1-ThetaG)*GDP - sum(Omega_dist(:).*(ccdf_fc_opt(:)  +  c_opt(:) + pn*n_opt(:) )))  ]; disp(disptext); % resource constraint
disptext = ['B.C.s. = ',  num2str((max(Omega_dist(:).*abs(ccdf_fc_opt(:) + c_opt(:)*(1+tau_c) + pn*n_opt(:) - gov_cc_expense_opt(:) - yd_opt(:))))) ]; disp(disptext); % individual budget constraints
% disptext = ['Maximum difference target I and realized I: ' num2str(max(abs(resinv)))]; disp(disptext);
disp('Calibration moments (targeted in baseline): ' );
disp(['Labor supply, ψ               : ' num2str(Laborsupply_target, '%0.4f ')  ' // ' num2str(h_hours, '%0.4f ,') num2str(psi, '%0.4f')]);
disp(['N hours,    λ_I               : ' num2str(N_hours_target, '%0.4f ')  ' // ' num2str(n_hours,'%0.4f ,') num2str(lambda_I, '%0.4f') ]);    
disp(['Pct w/ CCDF,  χ_c/yp50        : ' num2str(CCDF_receipt_target, '%0.4f ')  ' // ' num2str(CCDF_receipt,'%0.4f ,') num2str(chi_c_fraction, '%0.4f')  ]); 
disp(['Corr(Y,Θ*), b/β               : ' num2str(Corrincskill_target, '%0.4f ')  ' // ' num2str(rho_thetay,'%0.4f ,') num2str(b/beta, '%0.4f')  ]); 
disp(['Corr(Θa,Θk), β_ρ              : ' num2str(Corrinitialskill_target, '%0.4f ') ' // ' num2str(rho_initialskill,'%0.4f ,') num2str(initial_corr_par, '%0.4f') ]); 
disp(['ln p50-p10,var(log(Θk))       : ' num2str(GRIDparp50p10_target, '%0.4f ') ' // ' num2str(p50_yparGRID - p10_yparGRID,'%0.4f ,') num2str(varlogthetak, '%0.4f') ]); 
disp(['SS Spending % GDP, φ_SS       : ' num2str(SS_spending_percentageY, '%0.4f ') ' // ' num2str(tot_G_spending_SS_policy_mat_pretax(Policy_vec_index),'%0.4f ,') num2str(pension_rep_rate, '%0.4f') ]); 
disp('Other moments                  : ' );
disp(['Corr(yr_p,yr_k), b/β          : ' num2str(Corr_parentrank_childrank_target ,'% 0.4f ') ' // ' num2str(rho_rry,'% 0.4f ,') num2str(b/beta,'%0.4f')]) ; %
% disp(['ln p75-p50,var(log(Θk))       : ' num2str(GRIDparp75p50_target, '%0.4f ') ' // ' num2str(p75_yparGRID - p50_yparGRID,'%0.4f ,') num2str(varlogthetak, '%0.4f') ]); 
% disp(['Par p95 91 90 89 85 50 10     : ' num2str([p95_yparGRID p91_yparGRID p90_yparGRID p89_yparGRID p85_yparGRID p50_yparGRID p10_yparGRID], '%0.4f ')]); 
% disp(['Par p90-p10,p90-p50,p50-p10   : ' num2str([GRIDparp90p10_target GRIDparp90p50_target GRIDparp50p10_target],'% 0.4f ') ' // ' num2str([p90_yparGRID - p10_yparGRID p90_yparGRID - p50_yparGRID p50_yparGRID - p10_yparGRID],'% 0.4f ') ]);
% disp(['All p90-p10,p90-p50,p50-p10   : ' num2str([GRIDp90p10_target GRIDp90p50_target GRIDp50p10_target],'% 0.4f ') ' // ' num2str([p90_yGRID - p10_yGRID p90_yGRID - p50_yGRID p50_yGRID - p10_yGRID],'% 0.4f ') ]);
% disp(['Corr(Y,Θ*), b/β               : ' num2str(Corrincskill_target, '%0.4f ')  ' // ' num2str(rho_thetay,'%0.4f ,') num2str(b/beta, '%0.4f')  ]); 
% disp(['Labor supply by age           : ' num2str(LS_by_age,'% 0.2f ')]);
% disp(['Std of Labor supply by age    : ' num2str(LSstd_by_age,'% 0.2f ')]);
disp(['Q hours                       : ' num2str(Q_hours_data, '%0.4f ')  ' // ' num2str(q_hours,'%0.4f ')  ]); 
% disp(['Average rlzd Θk               : ' num2str(sum(averaging_mat(:).*exp(logthetak_mat(:)),'all')) ]); % is it close to 1?
% disp(['Average log(Θk): rlzd, thry   : ' num2str(sum(averaging_mat(:).*logthetak_mat(:),'all'),'% 0.4f ,') num2str(log(1) - varlogthetak/2,'% 0.4f') ]);       
disp('Other GE moments: ' );
disp(['Ave realized CCDF FC as % of median income : ' num2str(ave_fc_pct_yp50,'  %0.3f ')]);
% disp(['Range of labor supplies (Frisch)           : ' num2str(unique(h_opt)','  %0.3f '), ' (',num2str(Frisch,'  %0.3f '), ')']); 
% disp(['p90-p10, p90-p50, p50-p10 log pretax GRID  : ' num2str([p90_yGRID-p10_yGRID p90_yGRID-p50_yGRID p50_yGRID - p10_yGRID], '  %0.3f ')]);   
% disp(['Average chosen in equ (n,q) & ratio1 ratio2: ' num2str([n_hours q_hours q_hours/n_hours qn_ratio], '  %0.3f ') ]);
disp(['CCDF recipients as % of families  : ' num2str(100*sum((gov_cc_expense_opt(:,1)>0).*par_weights))]);
disp(['EITC recipients as % of population: ' num2str(100*sum((EITC_received_opt(:)>0).*Omega_dist(:)))]); % Table 3.3 IRS 100*27030382/152903231 = 17.6781
disp(['CTC recipients as % of population : ' num2str(100*sum((CTC_received_opt(:)>0).*Omega_dist(:)))]); % Table 3.3 IRS 100*22075218/152903231 = 14.43 (denom = total number of tax returns)
disp(['TANF recipients as % of families  : ' num2str(100*sum((TANF_received_opt(:,1)>0).*par_weights(:)))]);
disp(['CCDF as % of GDP: ' num2str(100*sum(gov_cc_expense_opt(:).*Omega_dist(:))/GDP)]);  % 
disp(['EITC as % of GDP: ' num2str(100*sum(EITC_received_opt(:).*Omega_dist(:))/GDP)]);   % Fig 4 CRS R43805 and Table 2.5 IRS 17in25ic 100*CPI*66.4/18734 = 0.347 in 2017, CPI 2017 to 2016 is 0.98   GDP 2015-2017 is 18734 is 2016 dollars. 
disp(['CTC as % of GDP : ' num2str(100*sum(CTC_received_opt(:).*Omega_dist(:))/GDP)]);    % Figure 2 CRS R41873, 2015 53.7 billion 100*CPI*53.7/18734 = 0.290 . CPI 2015 to 2016 is 1.01 GDP 2015-2017 is 18734 is 2016 dollars.   
disp(['TANF as % of GDP: ' num2str(100*sum(TANF_received_opt(:).*Omega_dist(:))/GDP)]);  % about 0.022
disp(['CCDF + CTC as % of GDP: ' num2str(100*sum(gov_cc_expense_opt(:).*Omega_dist(:))/GDP + 100*sum((CTC_received_opt(:)).*Omega_dist(:))/GDP)]);  % 
disp(['Total G as % of GDP   : ' num2str(100*sum((gov_cc_expense_opt(:)+tax_credits_transf_opt(:)+ThetaG*GDP).*Omega_dist(:))/GDP)]);  % 
disp(['Equ pn, pnratio, Θn   : ' num2str([pn pn_ratio_adjusted thetan],'  %0.4f ')]);
disp(['CCDF dollar pars      : ' num2str([subsidy_chic,rationing_rate, yp_cutoff, subsidy_b0, subsidy_b1],'  %0.4f ')]);
disp(['CTC dollar pars       : ' num2str([transfer_proportion1, transfer_proportion2, refund_threshold, phaseout_threshold],'  %0.4f ')]);
disp(['Equ GDP, yp50, λ_y, chi_c: ' num2str([GDP yp50 lambda_y chi_c],'  %0.4f ')]);
% disp(['Welfare change relative to baseline equ 0 and 1: ' num2str(Welfare_change_pct0(Policy_vec_index)) ' ' num2str(Welfare_change_pct1(Policy_vec_index))]);
disp(['End output policy index # :' num2str(Policy_vec_index)])
disp(datetime); 
disp('===============================');
diary off;
