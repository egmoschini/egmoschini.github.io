function [EITC_policy_mat] = EITC_policy(mean_inc_norm,j_a,J)

% Take weighted sums across single/head of household value and married
% couples value, where different. 
    EITC_policy_mat = zeros(J,6); 
    CPI_2020_2016 = 0.927; % See "Size_of_programs.xlsx"
    
        for age = 1:j_a
            EITC_policy_mat(age,1) = CPI_2020_2016*(0.21*3584 + 0.79*0.5*5920)*mean_inc_norm; % max credit amount per child
            EITC_policy_mat(age,2) = CPI_2020_2016*(0.21*10540 + 0.79*0.5*14800)*mean_inc_norm; % earned income amount per parent <-- redundant
            EITC_policy_mat(age,3) = CPI_2020_2016*(0.21*19330 + 0.79*0.5*25220)*mean_inc_norm; % phaseout threshold amount
            EITC_policy_mat(age,4) = CPI_2020_2016*(0.21*41756 + 0.79*0.5*53330)*mean_inc_norm; % zero credit threshold amount <-- redundant
            EITC_policy_mat(age,5) = 0.34*0.21 + 0.40*0.79; % credit rate
            EITC_policy_mat(age,6) = 0.1598*0.21 + 0.2106*0.79; % phaseout rate
        end
        
        for age = j_a+1:J
            EITC_policy_mat(age,1) = CPI_2020_2016*(0.21*538 + 0.79*0.5*538)*mean_inc_norm; % max credit amount
            EITC_policy_mat(age,2) = CPI_2020_2016*(0.21*7030 + 0.79*0.5*7030)*mean_inc_norm; % earned income amount per adult <-- redundant
            EITC_policy_mat(age,3) = CPI_2020_2016*(0.21*8790 + 0.79*0.5*14680)*mean_inc_norm; % phaseout threshold amount per adult
            EITC_policy_mat(age,4) = CPI_2020_2016*(0.21*15820 + 0.79*0.5*21710)*mean_inc_norm; % zero credit threshold amount per adult <-- redundant
            EITC_policy_mat(age,5) = 0.0765; % credit rate
            EITC_policy_mat(age,6) = 0.0765; % phaseout rate
        end

        
end