% ================= Replication of figures and tables for "Family Policies and Child Skill Accumulation" by Moschini and Tran-Xuan ================= %
% Instructions: 
% (1) Identify location of replication package on your computer "replication_package_path". Then open matlab and do the following in matlab: 
%   (a) Navigate to replication_package_path and add folders and subfolders to matlab path via right-click. 
%   (b) Modify line 5 in Paths_to_edit_before_running.m to replication_package_path
% (2) Run this file Master_file_main_manuscript_matlab.m to overwrite results
% (3) Run "Moschini_TranXuan_Replication.tex" to generate pdf of results. Compare with manuscript and online appendix.
% ==================================================================================================================================================================
% To save time, only run the section you want to replicate.

% Main manuscript 
run 'Paths_to_edit_before_running.m'; % clears memory and defines paths 
cd(main_manuscript_path);
diary_filename = 'main_manuscript_matlab_diary.txt'; diary(diary_filename); diary off; 
run Main_Calibration_Counterfactuals.m
run Draft_Processing_SteadyState_Output.m

% Online Appendix C.1 - Calibration comparative statics:  
run 'Paths_to_edit_before_running.m'; % clears memory and defines paths
cd(online_appendix_path);
diary_filename = 'online_appendix_matlab_diary_App_C1.txt'; diary(diary_filename); diary off; 
run Main_online_appendix_C1.m
run Draft_Processing_Online_Appendix_C1.m

% Online Appendix C.2 and C.3 except C.3.6: 
run 'Paths_to_edit_before_running.m'; % clears memory and defines paths
cd(online_appendix_path);
diary_filename = 'online_appendix_matlab_diary_App_C2_C3.txt'; diary(diary_filename); diary off; 
run Main_online_appendix_C2_C3.m
run Draft_Processing_Online_Appendix_C2_C3.m

% Online Appendix C.3.6 - Transition path: 
run 'Paths_to_edit_before_running.m'; % clears memory and defines paths
cd(online_appendix_path);
diary_filename = 'online_appendix_matlab_diary_App_C3_6.txt'; diary(diary_filename); diary off; 
run Main_online_appendix_C3_6.m
run Draft_Processing_Online_Appendix_C3_6.m

% Online Appendix C.4
run 'Paths_to_edit_before_running.m'; % clears memory and defines paths
cd(online_appendix_path);
diary_filename = 'online_appendix_matlab_diary_App_C4.txt'; diary(diary_filename); diary off; 
run Main_online_appendix_C4.m
run Draft_Processing_Online_Appendix_C4.m

% Online Appendix C.5.1 and C.5.2 - Recalibration robustness exercises: 
run 'Paths_to_edit_before_running.m'; % clears memory and defines paths
cd(online_appendix_path);
diary_filename  = 'online_appendix_matlab_diary_App_C5_1_and_2.txt'; diary(diary_filename); diary off; 
run Main_online_appendix_C5_1_and_2.m
run Draft_Processing_Online_Appendix_C5_1_and_2.m

% Online Appendix C.5.3 - Utility cost specification:  
run 'Paths_to_edit_before_running.m'; % clears memory and defines paths
cd(online_appendix_path);
diary_filename = 'online_appendix_matlab_diary_App_C5_3.txt'; diary(diary_filename); diary off; 
run Main_online_appendix_C5_3.m
run Draft_Processing_Online_Appendix_C5_3.m
 
% Tables and Figures
run 'Paths_to_edit_before_running.m'; % clears memory and defines paths
cd(fileparts(which(matlab.desktop.editor.getActiveFilename))); 
run Formatting_figures_and_tables.m
run Main_manuscript_tables_and_figures.m
run Online_appendix_tables_and_figures.m % have to run main manuscript as well to fully replicate appendix because some figures are duplicated from main text.

 
