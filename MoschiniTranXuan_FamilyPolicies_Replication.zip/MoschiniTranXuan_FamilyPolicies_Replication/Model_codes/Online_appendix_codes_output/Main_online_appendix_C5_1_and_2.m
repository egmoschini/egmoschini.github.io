% ================================================== CALIBRATION ROBUSTNESS EXERCISES MAIN FILE App. C.5.1 and C.5.2  ==================================================== %
run Parameters_and_Calibration_targets.m 

% Toggles for tasks:    
Run_policy_counterfactuals = 1;  
save_output_flag = 1;

% Convergence criteria, parameter output/input settings: 
res_calibration_cutoff     = 10^-3;
res_GE_cutoff              = 10^-4;
res_exp_size_equiv_cutoff  = 10^-3;  
Cutoff_GE_iteration_count  = 40; 

% ---> Policy pars key:  [subsidy_chic, rationing_rate, yp_cutoff, subsidy_b0, subsidy_b1, transfer_proportion1 (nonrefundable), transfer_proportion2 (refundable), refund_threshold, phaseout_threshold] Note: specific values are from CRS reports weighted with pop. fractions from Moschini (2023) or previous calibration results for the relevant experiment index.
% Note: subsidy_b1 is 0.85*reported beta_N,1 value b/c CCDF_policy.m divides by 0.85 
Policy_pars_mat_inputs = [];
Policy_pars_mat_inputs(1,:)  = [0.0 0.16 0.27 0.957 -0.296 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];    % Higher initial corr
Policy_pars_mat_inputs(2,:)  = [0.0 0.16 0.27 0.957 -0.296 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];    % Final corr target is rank-rank.
Policy_pars_mat_inputs(3,:)  = [0.0 0.16 0.27 0.957 -0.296 2 1.4 (0.21 + 0.79*0.5)*2.5 (0.21*200 + 0.79*0.5*400)]; % CTC Baseline 1  
Policy_pars_mat_inputs(4,:)  = [0.0 0.16 0.27 0.957 -0.296 2 1.4 (0.21 + 0.79*0.5)*2.5 (0.21*200 + 0.79*0.5*400)]; % CTC Baseline 2   
Policy_pars_mat_inputs(5,:)  = [0.3755 0.0 0.27 0.957 -0.296 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];  % Matches 3, Baseline 1
Policy_pars_mat_inputs(6,:)  = [0.5038 0.0 0.27 0.957 -0.296 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];  % Matches 4, Baseline 2 
Policy_pars_mat_inputs(7,:)  = [0.0 0.16 1.00 0.9518 0 1 1.0 (0.21 + 0.79*0.5)*3 (0.21*75 + 0.79*0.5*110)];        % Matches 3, Baseline 1, Traditional expansion 

% Policies [EITC_toggle CTC_toggle TANF_toggle CCDF_toggle] 2 is on, 1 is off. 
Policy_toggle_mat      = 2*ones(size(Policy_pars_mat_inputs,1),4); 

% --- General Equilibrium Objects that Adjust 
% -- GE_toggle_mat key: 1 ==> [skill_dist adjusts, Vkid adjusts, lambda_y adjusts, pn adjusts, yp50_policy_scaling adjusts, pension_lvl adjusts]  
% PE is default
GE_toggle_mat = ones(size(Policy_pars_mat_inputs,1),6); 

% Calibration moments/targets + parameters targets vary in robustness exercises
% DataMoment_values_benchmark_recalibration1 order: [Laborsupply_target N_hours_target Corrincskill_target CCDF_receipt_target GRIDparp50p10_target Corrinitialskill_target SS_spending_percentageY pn_ratio_observed]
% Calib_parvalues_mat order: [psi lambda_I b chi_c_fraction varlogthetak initial_corr_par pension_rep_rate]
DataMoment_values_benchmark_recalibration(:,1) = DataMoment_values_benchmark(:,1);
DataMoment_values_benchmark_recalibration(6,1) = 0.18;
Calib_parvalues_mat(:,1) = [6.7712 4.9611  0.7168*beta .1527 1.0375 0.1948 0.1978]; 
Calib_parvalues_mat(:,3) = Calib_parvalues_mat(:,1);
Calib_parvalues_mat(:,5) = Calib_parvalues_mat(:,1); 
Calib_parvalues_mat(:,7) = Calib_parvalues_mat(:,1); 

DataMoment_values_benchmark_recalibration(:,2) = DataMoment_values_benchmark(:,1);
Calib_parvalues_mat(:,2) = [6.7178 4.8709 0.4413*beta .1419 1.0166 0.0829 0.1975];
Calib_parvalues_mat(:,4) = Calib_parvalues_mat(:,2);
Calib_parvalues_mat(:,6) = Calib_parvalues_mat(:,2); 

% Matrix linking exercises w/ recalibrated baseline eq. 
Benchmark_index_mat([1,3,5,7]) = 1;
Benchmark_index_mat([2,4,6])   = 2; 

% Targets 
Calib_targets_mat = DataMoment_values_benchmark_recalibration;
Calib_targets_mat(:,3) = Calib_targets_mat(:,1);
Calib_targets_mat(:,4) = Calib_targets_mat(:,2); 
Calib_targets_mat(:,5) = Calib_targets_mat(:,1);
Calib_targets_mat(:,6) = Calib_targets_mat(:,2); 
Calib_targets_mat(:,7) = Calib_targets_mat(:,1);

% Flag loops that are calibration loops; it may be that the code set has more than one.
Calibration_loop_flag_mat = zeros(1,size(Policy_toggle_mat,1));
Calibration_loop_flag_mat([1,2]) = 1; 

% Initializing policy loop output (see Descriptive_Statistics_Equilibrium.m for computation of contents): 
V1_policy_mat            = zeros(n_types,size(Policy_toggle_mat,1));
Vkid_policy_mat          = zeros(n_theta,size(Policy_toggle_mat,1));
GE_objects_policy_mat    = zeros(6,size(Policy_toggle_mat,1));
GE_quantities_policy_mat = zeros(5,size(Policy_toggle_mat,1));
Exp_G_policy_mat         = zeros(3,size(Policy_toggle_mat,1));
Recipients_G_policy_mat  = zeros(2,size(Policy_toggle_mat,1));
Welfare_change_theta     = zeros(n_types,size(Policy_toggle_mat,1));
Welfare_change_pct       = zeros(1,size(Policy_toggle_mat,1));
skill_dist_policy_mat    = zeros(n_theta,size(Policy_toggle_mat,1)); 
Omega_dist_policy_mat    = zeros(n_types,J,size(Policy_toggle_mat,1));
V_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1));
V_opt_realized_policy_mat = zeros(n_types,J,size(Policy_toggle_mat,1));
theta_opt_policy_mat     = zeros(n_types,J,size(Policy_toggle_mat,1)); 
n_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
q_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
h_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
c_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
thetaa_policy_mat        = zeros(n_types,J,size(Policy_toggle_mat,1));
y_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1)); 
yd_opt_policy_mat        = zeros(n_types,J,size(Policy_toggle_mat,1)); 
ccdf_app_opt_policy_mat  = zeros(n_types,J,size(Policy_toggle_mat,1)); 
target_pct_Y_G_policy_mat         = zeros(1,size(Policy_toggle_mat,1));  
target_pct_Y_CTC_CCDF_policy_mat  = zeros(1,size(Policy_toggle_mat,1)); 
Policy_pars_mat_outputs           = 0.*Policy_pars_mat_inputs;   
gov_cc_expense_opt_policy_mat     = zeros(n_types,J,size(Policy_toggle_mat,1)); 
tax_credits_transf_opt_policy_mat = zeros(n_types,J,size(Policy_toggle_mat,1)); 
taxes_paid_opt_policy_mat         = zeros(n_types,J,size(Policy_toggle_mat,1));   
ave_fc_pct_yp50_policy_mat        = zeros(1,size(Policy_toggle_mat,1));
res_vec_policy_mat                = zeros(3,size(Policy_toggle_mat,1)); 
value_policy_equiv_par_policy_mat = zeros(1,size(Policy_toggle_mat,1));  
res_policy_equiv_policy_mat       = zeros(1,size(Policy_toggle_mat,1));

% Initialize Iteration indeces and residuals that do not change or get updated sometimes, but get printed
calibration_iter_count = 1; 
policy_iter_count      = 1; 
res_policy_equiv       = 0; 
value_policy_equiv_par = 0; 

%  ---> Begin loop
tstart_main_code = tic; 

for Policy_vec_index = 1:size(Policy_toggle_mat,1)
 
    % Open calibration targets for this Policy vector loop
    Laborsupply_target      = Calib_targets_mat(1,Policy_vec_index);
    N_hours_target          = Calib_targets_mat(2,Policy_vec_index);
    Corrincskill_target     = Calib_targets_mat(3,Policy_vec_index);
    CCDF_receipt_target     = Calib_targets_mat(4,Policy_vec_index);
    GRIDparp50p10_target    = Calib_targets_mat(5,Policy_vec_index);
    Corrinitialskill_target = Calib_targets_mat(6,Policy_vec_index);
    SS_spending_percentageY = Calib_targets_mat(7,Policy_vec_index);
    pn_ratio_observed       = Calib_targets_mat(8,Policy_vec_index);
    % Open parameter initialization for this Policy vector loop
    psi               = Calib_parvalues_mat(1,Policy_vec_index); 
    lambda_I          = Calib_parvalues_mat(2,Policy_vec_index); 
    b                 = Calib_parvalues_mat(3,Policy_vec_index); 
    chi_c_fraction    = Calib_parvalues_mat(4,Policy_vec_index);
    varlogthetak      = Calib_parvalues_mat(5,Policy_vec_index); 
    initial_corr_par  = Calib_parvalues_mat(6,Policy_vec_index); 
    pension_rep_rate  = Calib_parvalues_mat(7,Policy_vec_index); 

    % If it isn't a baseline equilibrium loop, use the aggregate objects from the
    % appropriate baseline. These only get updated in baseline equilibria.
    if  Calibration_loop_flag_mat(Policy_vec_index) == 0
        theta_grid = theta_grid_policy_mat(:,Benchmark_index_mat(Policy_vec_index))';
        thetan     = thetan_policy_mat(1,1,Benchmark_index_mat(Policy_vec_index));
        pn_ratio_adjusted =  pn_ratio_adjusted_policy_mat(Benchmark_index_mat(Policy_vec_index));
        thetak_dist = thetak_dist_policy_mat(:,:,Benchmark_index_mat(Policy_vec_index));
        chi_c = chi_c_fraction*GE_objects_policy_mat(4,Benchmark_index_mat(Policy_vec_index));
    end

    % Print initialization
    tstart_policyloop = tic; diary on; disp(['BEGIN POLICY INDEX #: ' num2str(Policy_vec_index)]); disp('Date and time began loop: '); disp(datetime);  diary off;

    diary on;
    disp('CALIBRATION TARGETS:');
    disp(['      H   ','      N   ','  Corr(Θ,y) ','  CCDF   ','   Ineq   ','Corr(Θa,Θk)   ','SS   ']);
    disp(round(Calib_targets_mat(:,Policy_vec_index),4)');
    disp('PARAMETERIZATION INITIALIZATION:');
    disp(['      ψ   ','      λ_I   ','  χ_c/yp50   ',' b/β   ','   β_ρ   ','var(log(Θk))   ','φ_SS   ']);
    disp(round([psi lambda_I chi_c_fraction b/beta initial_corr_par varlogthetak pension_rep_rate],4));
    diary off;

    % Policy attributes - initialize policy loop:
    Policy_toggle_vec = Policy_toggle_mat(Policy_vec_index,:); %   
    EITC_toggle = Policy_toggle_vec(1); 
    CTC_toggle  = Policy_toggle_vec(2); 
    TANF_toggle = Policy_toggle_vec(3); 
    CCDF_toggle = Policy_toggle_vec(4);  

    subsidy_chic            = Policy_pars_mat_inputs(Policy_vec_index,1);  
    rationing_rate          = Policy_pars_mat_inputs(Policy_vec_index,2);  
    yp_cutoff               = Policy_pars_mat_inputs(Policy_vec_index,3); 
    subsidy_b0              = Policy_pars_mat_inputs(Policy_vec_index,4); 
    subsidy_b1              = Policy_pars_mat_inputs(Policy_vec_index,5); 
    transfer_proportion1    = Policy_pars_mat_inputs(Policy_vec_index,6); 
    transfer_proportion2    = Policy_pars_mat_inputs(Policy_vec_index,7); 
    refund_threshold        = Policy_pars_mat_inputs(Policy_vec_index,8); 
    phaseout_threshold      = Policy_pars_mat_inputs(Policy_vec_index,9); 

    if Calibration_loop_flag_mat(Policy_vec_index) ==1  % --- Calibrated Baselines     

        tstart_EquLoop = tic;  run Solving_Equilibrium_Recalibrations.m;  
        run Descriptive_Statistics_Equilibrium.m

    elseif Calibration_loop_flag_mat(Policy_vec_index) == 0  && Run_policy_counterfactuals == 1 % Exercises with policy expansions/not calibration loops

        if ismember(Policy_vec_index,[3,4])   % --- CTC expansions: Exercises that DO NOT calibrate policy parameters

            tstart_EquLoop = tic;  run Solving_Equilibrium_Recalibrations.m;  
            run Descriptive_Statistics_Equilibrium.m

        else  % --- CCDF expansions: Exercises that DO calibrate policy parameters to hit spending level of target exercise
            % 2017 TCJA CTC expansion gov't spending target 
            if ismember(Policy_vec_index, [5,7])   
                target_index = 3; 
            else  
                target_index = 4;    
            end            
            tstart_EquLoop = tic;  run Solving_Equilibrium_Recalibrations.m;  
            run Descriptive_Statistics_Equilibrium.m    
            res_policy_equiv = abs(target_pct_Y_G_policy_mat(Policy_vec_index) - target_pct_Y_G_policy_mat(target_index));   
            diary on; 
            disp(['Spending-equiv. stats: share of output and output pars: ' num2str([target_pct_Y_G_policy_mat(target_index), target_pct_Y_G_policy_mat(Policy_vec_index), res_policy_equiv, subsidy_chic, rationing_rate, yp_cutoff, subsidy_b0,subsidy_b1, transfer_proportion1, transfer_proportion2, refund_threshold, phaseout_threshold], '%0.2f ,')]); 
            diary off;               
        end % end conditional on policy index  

    end % end baseline equilibrium conditional 

    Policy_pars_mat_outputs(Policy_vec_index,:) = [subsidy_chic, rationing_rate, yp_cutoff, subsidy_b0,subsidy_b1, transfer_proportion1, transfer_proportion2, refund_threshold, phaseout_threshold];

end % end policy loop
  
% Output results
if save_output_flag == 1
    output_filename = [online_appendix_path 'Raw_output_online_appendix\Output_appendix_C5_1_and_2.mat'];
    save(output_filename); 
    output_filename = [online_appendix_path 'Raw_output_online_appendix\Policy_pars_appendix_C5_1_and_2_mat_outputs.mat'];
    save(output_filename,'Policy_pars_mat_outputs'); 
end
diary on; disp(['Time in seconds for this main file = ' num2str(toc(tstart_main_code))] ); diary off;   
disp(['CODE COMPLETED. See diary file: ' get(0,'DiaryFile')]);
