% % Load raw output
% filename_temp = main_manuscript_path + "Raw_output\Output_main_manuscript"; load(filename_temp);

% Set baseline equilibrium index and age cutoff for spending distribution graphs using model output
Baseline_index = 1;
age_cutoff_spending_distribution_graphs     = 1; % use the age where they get both of the transfers/are investing in kids, j = 1. Then, for CTC, explain in the text that after early childhood families continue to get it. Compare how spending for households with kids age 5-16 is distributed versus the data.
age_cutoff_spending_distribution_graphsCCDF = 1;

% Load empirical output in csv form
filename_temp = []; filename_temp = data_path + "share_spending_ccdf.csv"; Tccdf = []; Tccdf = readtable(filename_temp);
filename_temp = []; filename_temp = data_path + "share_spending_eitc.csv"; Teitc = []; Teitc = readtable(filename_temp);
filename_temp = []; filename_temp = data_path + "share_spending_ctc.csv"; Tctc = []; Tctc = readtable(filename_temp);
filename_temp = []; filename_temp = data_path + "share_recipients_ccdf.csv"; Tccdf_receipt = []; Tccdf_receipt = readtable(filename_temp);
filename_temp = []; filename_temp = data_path + "share_receipt_ctc.csv"; Tctc_receipt = []; Tctc_receipt = readtable(filename_temp);
filename_temp = []; filename_temp = data_path + "share_receipt_eitc.csv"; Teitc_receipt = []; Teitc_receipt = readtable(filename_temp);
filename_temp = []; filename_temp = data_path + "stats_yngch_cps_ccdf_recipients.csv"; Tcpsccdf = []; Tcpsccdf = readtable(filename_temp);

% Assign number of spending dist. bins
number_bins = size(Tctc,1); % the CTC has all the bins by construction  

% Create arrays from tables for graphing, spending and receipt distributions
sharespendingeitc  = zeros(number_bins,1); sharespendingeitc = table2array(Teitc(:,2));
sharespendingctc   = zeros(number_bins,1); sharespendingctc = table2array(Tctc(:,2));
sharespendingccdf  = zeros(number_bins,1); sharespendingccdf(1:size(Tccdf,1),1) = table2array(Tccdf(:,2)); % this data object only has values up to the bin represented in admin data

sharereceiptctc   = zeros(number_bins,1); sharereceiptctc(1:size(Tccdf,1),1) = table2array(Tctc_receipt(:,2));  
sharereceipteitc  = zeros(number_bins,1); sharereceipteitc(1:size(Tccdf,1),1) = table2array(Teitc_receipt(:,2));  
sharereceiptccdf  = zeros(number_bins,1); sharereceiptccdf(1:size(Tccdf,1),1) = table2array(Tccdf_receipt(:,2)); % this data object only has values up to the bin represented in admin data

% Create array from table for comparison of model with data CCDF
cpsccdf_comparisonstats = table2array(Tcpsccdf(:,2));

% ======================== LIFE CYCLE SKILL LEVEL AND DENOMINATOR WELFARE CHANGE
theta_profile_grid = zeros(n_types,J);
for type_index = 1:n_types
    theta_index  = type_mat(type_index,1); 
    thetak_index = type_mat(type_index,2);
    cc_a_r_index = type_mat(type_index,3);
    cc_fc_index  = type_mat(type_index,4); 

    for age = 1:J
        labor_eff_units = theta_grid(theta_index);
        wage_growth_age = beta1_wagegrowth*(age-1) + beta2_wagegrowth*(age-1)^2 + beta3_wagegrowth*(age-1)^3;
        theta_profile_grid(type_index,age) = labor_eff_units*(1+wage_growth_age);
    end
end

denomW = zeros(1,J);
for age_initial = 1:J
    denomW_aux = 0;
    for age = age_initial:J
        denomW_aux = denomW_aux + beta^(age-age_initial);
    end 
    denomW(age_initial) = denomW_aux;
end

% ======================== BEGIN INITIALIZATION  
% Binning objects
thetaa_bin_mat = zeros(n_types,J,size(Policy_toggle_mat,1));
thetak_bin_mat = NaN(n_types,J,size(Policy_toggle_mat,1));
fc_bin_mat     = NaN(n_types,J,size(Policy_toggle_mat,1));
thetaka_bin_mat = NaN(n_types,J,size(Policy_toggle_mat,1)); 
y_bin_mat      = NaN(n_types,J,size(Policy_toggle_mat,1)); 

dist_bin = NaN(4,number_bins,J,size(Policy_toggle_mat,1));
share_nilf_bin = NaN(4,number_bins,J,size(Policy_toggle_mat,1));   
n_ave_bin = NaN(4,number_bins,J,size(Policy_toggle_mat,1));  
q_ave_bin = NaN(4,number_bins,J,size(Policy_toggle_mat,1));  
c_ave_bin = NaN(4,number_bins,J,size(Policy_toggle_mat,1));  
h_ave_bin = NaN(4,number_bins,J,size(Policy_toggle_mat,1)); 
mass_ctc_bin   = NaN(4,number_bins,J,size(Policy_toggle_mat,1));  
amt_ctc_bin     = NaN(4,number_bins,J,size(Policy_toggle_mat,1)); 
mass_eitc_bin  = NaN(4,number_bins,J,size(Policy_toggle_mat,1)); 
amt_eitc_bin    = NaN(4,number_bins,J,size(Policy_toggle_mat,1)); 
mass_tanf_bin  = NaN(4,number_bins,J,size(Policy_toggle_mat,1)); 
amt_tanf_bin    = NaN(4,number_bins,J,size(Policy_toggle_mat,1)); 
invlevel_ave_bin = NaN(4,number_bins,J,size(Policy_toggle_mat,1));
ccexp_ave_bin   = NaN(4,number_bins,J,size(Policy_toggle_mat,1)); 
thetaka_ave_bin = NaN(4,number_bins,J,size(Policy_toggle_mat,1)); 
mass_ccdf_bin  = NaN(4,number_bins,J,size(Policy_toggle_mat,1)); 
amt_ccdf_bin    = NaN(4,number_bins,J,size(Policy_toggle_mat,1));

mass_2bin = NaN(4,number_bins,number_bins,size(Policy_toggle_mat,1));       
dist_2bin = NaN(4,number_bins,number_bins,size(Policy_toggle_mat,1));  
share_nilf_2bin = NaN(4,number_bins,number_bins,size(Policy_toggle_mat,1));  
h_ave_2bin = NaN(4,number_bins,number_bins,size(Policy_toggle_mat,1)); 
n_ave_2bin = NaN(4,number_bins,number_bins,size(Policy_toggle_mat,1));   
q_ave_2bin = NaN(4,number_bins,number_bins,size(Policy_toggle_mat,1));   
c_ave_2bin = NaN(4,number_bins,number_bins,size(Policy_toggle_mat,1));  

mass_ctc_2bin = NaN(4,number_bins,number_bins,size(Policy_toggle_mat,1));  
amt_ctc_2bin = NaN(4,number_bins,number_bins,size(Policy_toggle_mat,1));  
mass_eitc_2bin = NaN(4,number_bins,number_bins,size(Policy_toggle_mat,1));  
amt_eitc_2bin = NaN(4,number_bins,number_bins,size(Policy_toggle_mat,1));   
mass_tanf_2bin = NaN(4,number_bins,number_bins,size(Policy_toggle_mat,1));   
amt_tanf_2bin = NaN(4,number_bins,number_bins,size(Policy_toggle_mat,1));   
invlevel_ave_2bin = NaN(4,number_bins,number_bins,size(Policy_toggle_mat,1));   
ccexp_ave_2bin = NaN(4,number_bins,number_bins,size(Policy_toggle_mat,1));  
thetaka_ave_2bin = NaN(4,number_bins,number_bins,size(Policy_toggle_mat,1));  
mass_ccdf_2bin = NaN(4,number_bins,number_bins,size(Policy_toggle_mat,1));  
amt_ccdf_2bin = NaN(4,number_bins,number_bins,size(Policy_toggle_mat,1));  
share_received_ccdf_2bin = NaN(4,number_bins,number_bins,size(Policy_toggle_mat,1));  
share_eligible_ccdf_2bin = NaN(4,number_bins,number_bins,size(Policy_toggle_mat,1));  
uptake_rateccdf_2bin = NaN(4,number_bins,number_bins,size(Policy_toggle_mat,1));  

% How skill distribution changes
dist_theta_bin= zeros(number_bins,J,size(Policy_toggle_mat,1));
dist_thetak_bin= zeros(number_bins,J,size(Policy_toggle_mat,1));
dist_y_bin= zeros(number_bins,J,size(Policy_toggle_mat,1));
cdf_skill_dist_policy_mat = zeros(n_theta,size(Policy_toggle_mat,1));

% Changes in skill outcomes; objects
bin_thetak_only_policy_mat = NaN(n_thetak,size(Policy_toggle_mat,1));
mass_thetak_policy_mat = NaN(n_thetak,size(Policy_toggle_mat,1));
ave_theta_given_thetak_policy_mat = NaN(n_thetak,size(Policy_toggle_mat,1));
bin_thetak_only_baselinedist = NaN(n_thetak,size(Policy_toggle_mat,1));
mass_thetak_baselinedist = NaN(n_thetak,size(Policy_toggle_mat,1));
ave_theta_given_thetak_baselinedist = NaN(n_thetak,size(Policy_toggle_mat,1));
ave_theta_given_thetak_type = NaN(n_types,size(Policy_toggle_mat,1));
ave_theta_given_thetak_type_baselinedist = NaN(n_types,size(Policy_toggle_mat,1));
ave_theta_given_thetak_bin_policy_mat = NaN(number_bins,size(Policy_toggle_mat,1));

% For heat maps of CCDF uptake
share_ccdf_thetaa_thetak_bin = zeros(number_bins,number_bins,size(Policy_toggle_mat,1));
mass_thetaa_thetak_bin       = zeros(number_bins,number_bins,size(Policy_toggle_mat,1));

% Welfare changes: 
EV_newborns = NaN(n_thetak,size(Policy_toggle_mat,1));
weight_thetak_policy_mat = NaN(n_thetak,size(Policy_toggle_mat,1));
W_change_newborns = NaN(n_thetak,size(Policy_toggle_mat,1));
W_change_newborns_ave = NaN(1,size(Policy_toggle_mat,1));
Share_gain_newborns = NaN(1,size(Policy_toggle_mat,1));
Share_lose_newborns = NaN(1,size(Policy_toggle_mat,1));
Share_indiff_newborns = NaN(1,size(Policy_toggle_mat,1));

EV_adults = NaN(n_theta,J,size(Policy_toggle_mat,1));
W_change_adults = NaN(n_theta,J,size(Policy_toggle_mat,1));
W_change_adults_ave = NaN(J,size(Policy_toggle_mat,1));
Share_gain_adults = NaN(J,size(Policy_toggle_mat,1));
Share_lose_adults = NaN(J,size(Policy_toggle_mat,1));
Share_indiff_adults = NaN(J,size(Policy_toggle_mat,1));

% Averages by age: 
y_ave_policy_mat = NaN(J,size(Policy_toggle_mat,1));
yd_ave_policy_mat = NaN(J,size(Policy_toggle_mat,1));
h_ave_policy_mat = NaN(J,size(Policy_toggle_mat,1));
c_ave_policy_mat = NaN(J,size(Policy_toggle_mat,1));
q_ave_policy_mat = NaN(J,size(Policy_toggle_mat,1));
n_ave_policy_mat = NaN(J,size(Policy_toggle_mat,1));
skill_ave_policy_mat = NaN(J,size(Policy_toggle_mat,1));
theta_ave_policy_mat = NaN(J,size(Policy_toggle_mat,1));

% Percent change by age
skill_ave_change_age = NaN(J,size(Policy_toggle_mat,1));
q_ave_change_age = NaN(J,size(Policy_toggle_mat,1));
n_ave_change_age = NaN(J,size(Policy_toggle_mat,1));
h_ave_change_age = NaN(J,size(Policy_toggle_mat,1));
c_ave_change_age = NaN(J,size(Policy_toggle_mat,1));
theta_ave_change_age = NaN(J,size(Policy_toggle_mat,1)); 

% Flags
flag_rccdf = NaN(n_types,J,size(Policy_toggle_mat,1));  
flag_appnorccdf = NaN(n_types,J,size(Policy_toggle_mat,1));  
flag_noappnorccdf =  NaN(n_types,J,size(Policy_toggle_mat,1));  

% Income distribution
std_y_policy_mat = NaN(J,size(Policy_toggle_mat,1)); 
std_yd_policy_mat = NaN(J,size(Policy_toggle_mat,1)); 
std_y_workingpop_policy_mat = NaN(1,size(Policy_toggle_mat,1));
mean_y_workingpop_policy_mat = NaN(1,size(Policy_toggle_mat,1));
cv_y_workingpop_policy_mat = NaN(1,size(Policy_toggle_mat,1));
std_yd_workingpop_policy_mat = NaN(1,size(Policy_toggle_mat,1));
mean_yd_workingpop_policy_mat = NaN(1,size(Policy_toggle_mat,1));
cv_yd_workingpop_policy_mat = NaN(1,size(Policy_toggle_mat,1));
pctile_logypar_policy_mat = NaN(100,size(Policy_toggle_mat,1));

pctile_logskill_policy_mat = NaN(100,size(Policy_toggle_mat,1));
pctile_skill_policy_mat = NaN(100,size(Policy_toggle_mat,1));
pctile_logskill_dist_policy_mat = NaN(3,size(Policy_toggle_mat,1));
smoothed_pctile_logskill_dist_policy_mat = NaN(3,size(Policy_toggle_mat,1));
smoothed_pctile_skill_dist_policy_mat = NaN(3,size(Policy_toggle_mat,1));  

mean_skill_policy_mat = NaN(1,size(Policy_toggle_mat,1));
std_skill_policy_mat = NaN(1,size(Policy_toggle_mat,1));
cv_skill_policy_mat = NaN(1,size(Policy_toggle_mat,1));
var_logskill_policy_mat = NaN(1,size(Policy_toggle_mat,1));
gini_skill_policy_mat = NaN(1,size(Policy_toggle_mat,1));
par_p50p10_policy_mat = NaN(1,size(Policy_toggle_mat,1));
par_ave_p10_policy_mat = NaN(1,size(Policy_toggle_mat,1));
par_ave_p50_policy_mat = NaN(1,size(Policy_toggle_mat,1));

tax_rate_ave_inc = NaN(1,size(Policy_toggle_mat,1));
res_tempG = NaN(1,size(Policy_toggle_mat,1));

% Changes
G_spending_change = NaN(1,size(Policy_toggle_mat,1));  
ave_tax_rate_change = NaN(1,size(Policy_toggle_mat,1));   
q_ave_change = NaN(1,size(Policy_toggle_mat,1));  
n_ave_change = NaN(1,size(Policy_toggle_mat,1));  
skill_ave_change = NaN(1,size(Policy_toggle_mat,1));  
h_ave_change = NaN(1,size(Policy_toggle_mat,1));  
GDP_change = NaN(1,size(Policy_toggle_mat,1));  
c_ave_change = NaN(1,size(Policy_toggle_mat,1));  
std_y_change = NaN(J,size(Policy_toggle_mat,1));  
std_yd_change = NaN(J,size(Policy_toggle_mat,1));  
std_ypop_change = NaN(1,size(Policy_toggle_mat,1)); 
std_ydpop_change = NaN(1,size(Policy_toggle_mat,1)); 
cv_y_workingpop_change = NaN(1,size(Policy_toggle_mat,1)); 
cv_yd_workingpop_change = NaN(1,size(Policy_toggle_mat,1)); 
par_p50p10_change = NaN(1,size(Policy_toggle_mat,1)); 
meanskill_change = NaN(1,size(Policy_toggle_mat,1)); 
p50skill_change = NaN(1,size(Policy_toggle_mat,1)); 
cv_skill_change = NaN(1,size(Policy_toggle_mat,1)); 
std_skill_change = NaN(1,size(Policy_toggle_mat,1)); 
var_logskill_change = NaN(1,size(Policy_toggle_mat,1)); 
gini_skill_change = NaN(1,size(Policy_toggle_mat,1)); 
p50p10_skill_change = NaN(1,size(Policy_toggle_mat,1)); 
p90p50_skill_change = NaN(1,size(Policy_toggle_mat,1)); 
p90p10_skill_change = NaN(1,size(Policy_toggle_mat,1)); 
ave_p50_p10_logskill_change = NaN(1,size(Policy_toggle_mat,1)); 
ave_p90_p50_logskill_change = NaN(1,size(Policy_toggle_mat,1)); 
ave_p90_p10_logskill_change = NaN(1,size(Policy_toggle_mat,1)); 
ave_p50_skill_change = NaN(1,size(Policy_toggle_mat,1)); 
thetaka_ave_thetak_bin_change = NaN(number_bins,size(Policy_toggle_mat,1));   
rho_thetay_change = NaN(1,size(Policy_toggle_mat,1)); 
rho_rry_change = NaN(1,size(Policy_toggle_mat,1)); 

% Output table array
Array_Policy_counterfactuals_C4 = NaN(33,size(Policy_toggle_mat,1));
% ======================== END INITIALIZATION  

% ---> Baseline equilibrium and policy experiment output processing: 
TSTART = tic;
for Policy_vec_index = 1:size(Policy_toggle_mat,1)
    disp(['Policy vec: ' num2str(Policy_vec_index)]);
    for age = 1:J        
        % =========================================== BEGIN ASSIGN AGE-SPECIFIC BINS: theta_a and theta_k and fixed cost and income y quantiles
        if Policy_vec_index == 1
            % ---> Equilibrium-specific weights for Theta_a and theta_k quintiles:             
            % ---> Theta_a quantiles:
            thetaa_dist_temp      = NaN(n_theta,3); 
            for theta_index = 1:n_theta
                thetaa_dist_temp(theta_index,1)      = theta_grid(theta_index);
                thetaa_dist_temp(theta_index,2)      = skill_dist_policy_mat(theta_index,Policy_vec_index);
            end
            thetaa_dist_temp(:,3) = cumsum(thetaa_dist_temp(:,2));
            thetaa_bin_mat_temp(1:n_theta) = 1;
            for index_temp = 1:number_bins-1
                [~,cutoff] = min(abs(thetaa_dist_temp(:,3)-index_temp/number_bins));
                thetaa_bin_mat_temp(min(cutoff+1,end):end) = 1+index_temp;
            end
            % checks
            check_distadult = NaN(1,number_bins);
            for bin_index = 1:number_bins
                check_distadult(bin_index) = sum(skill_dist_policy_mat(:,Policy_vec_index).*(thetaa_bin_mat_temp(:) ==bin_index)) ;
            end
            disp('Thetaa binning check:');
            disp(num2str([unique(thetaa_bin_mat_temp(:))'; round(check_distadult,4)]));    
            % ---> Theta_k quantiles:
            % Construct the probability of being theta_k in the given equilibrium
            weight_temp = NaN(n_theta,n_thetak,n_ccsub_types,n_bins_ccsub_fc);
            for type_index = 1:n_types  
                weight_temp(type_mat(type_index,1),type_mat(type_index,2),type_mat(type_index,3),type_mat(type_index,4)) = J*Omega_dist_policy_mat(type_index,1,Policy_vec_index);
            end  
            thetak_dist_uncond_temp_mat = NaN(n_thetak,3);  % Note: thetak_dist_policy_mat is identical across policy iterations, it idoesn't incorporate anything endogenous from the skill distribution of parents...
            for thetak_index = 1:n_thetak
                thetak_dist_uncond_temp_mat(thetak_index,1)      = thetak_grid(thetak_index);
                thetak_dist_uncond_temp_mat(thetak_index,2)      = sum(squeeze(weight_temp(:,thetak_index,:,:)),'all')/sum(weight_temp(:,:,:,:),'all');
            end 
            thetak_dist_uncond_temp_mat(:,3) = cumsum(thetak_dist_uncond_temp_mat(:,2)); 
            thetak_bin_mat_temp(1:n_thetak) = 1;
            for index_temp = 1:number_bins-1
                [~,cutoff] = min(abs(thetak_dist_uncond_temp_mat(:,3)-index_temp/number_bins));
                thetak_bin_mat_temp(min(cutoff+1,end):end)   = 1+index_temp;
            end 
            % checks
            check_distkid = NaN(1,number_bins);
            for bin_index = 1:number_bins
                check_distkid(bin_index) = sum(thetak_dist_uncond_temp_mat(:,2).*(thetak_bin_mat_temp(:) ==bin_index)) ;
            end
            disp('Thetak binning check:');
            disp(num2str([unique(thetak_bin_mat_temp(:))'; round(check_distkid,4)]));    
            % ---> Fixed cost shock quantiles:
            fc_dist      = NaN(n_bins_ccsub_fc,3); 
            for cc_fc_index = 1:n_bins_ccsub_fc
                fc_dist(cc_fc_index,1)      = chi_c_eps_grid(cc_fc_index);
                fc_dist(cc_fc_index,2)      = chi_c_eps_dist(cc_fc_index);
            end
            fc_dist(:,3) = cumsum(fc_dist(:,2));
            fc_bin_mat_temp(1:n_bins_ccsub_fc) = 1;
            for index_temp = 1:number_bins-1
                [~,cutoff] = min(abs(fc_dist(:,3)-index_temp/number_bins));
                fc_bin_mat_temp(min(cutoff+1,end):end)   = 1+index_temp;
            end 
            % checks
            check_distfc = NaN(1,number_bins);
            for bin_index = 1:number_bins
                check_distfc(bin_index) = sum(fc_dist(:,2).*(fc_bin_mat_temp(:) ==bin_index)) ;
            end
            disp('Fixed cost shock binning check:');
            disp(num2str([unique(fc_bin_mat_temp(:))'; round(check_distfc,4)]));            
           
            % Generate theta,thetak, and fc bins assignement at the hh type level:
            for type_index = 1:n_types
                theta_index  = type_mat(type_index,1); 
                thetak_index = type_mat(type_index,2);
                cc_a_r_index = type_mat(type_index,3);
                cc_fc_index  = type_mat(type_index,4); 
                
                thetaa_bin_mat(type_index,age,Policy_vec_index)  = thetaa_bin_mat_temp(theta_index); 
                thetak_bin_mat(type_index,age,Policy_vec_index)  = thetak_bin_mat_temp(thetak_index); 
                fc_bin_mat(type_index,age,Policy_vec_index)      = fc_bin_mat_temp(cc_fc_index); 
            end
            
            % ---> Child skill outcomes quantiles - assign families, not kids:
            thetaka_dist_mat = NaN(n_types,3);   
            for type_index = 1:n_types
                thetaka_dist_mat(type_index,1) = theta_grid(theta_opt_policy_mat(type_index,1,Policy_vec_index));
                thetaka_dist_mat(type_index,2) = J*Omega_dist_policy_mat(type_index,1,Policy_vec_index);
            end 
            thetaka_dist_mat = sortrows(thetaka_dist_mat,1);
            thetaka_dist_mat(:,3) = cumsum(thetaka_dist_mat(:,2)); 
   
            thetaka_bin_mat(1:n_types,age,Policy_vec_index) = 1; % reset the slide of this matrix current loop updates to 1
            for index_temp = 1:number_bins-1
                [level,cutoff] = min(abs(thetaka_dist_mat(:,3)-index_temp/number_bins));
                flag_temp      = (thetaka_dist_mat(:,1)>=thetaka_dist_mat(cutoff,1));
                thetaka_bin_mat(flag_temp==1,age,Policy_vec_index)   = 1+index_temp;
            end 
            % checks
            check_distthetaka = NaN(1,number_bins);
            for bin_index = 1:number_bins
                check_distthetaka(bin_index) = sum(thetaka_dist_mat(:,2).*(thetaka_bin_mat(:,age,Policy_vec_index) ==bin_index)) ;
            end
            disp('Child skill outcome binning check:');
            disp(num2str([unique(thetaka_bin_mat(:,age,Policy_vec_index))'; round(check_distthetaka(:),4)']));   

            % ---> Income quantiles: 
            disp('Begin Ydist ');
            weight_temp = NaN(n_types,1); % has different dimensions for this loop 
            weight_temp = J*Omega_dist_policy_mat(:,age,Policy_vec_index); 
            y_mat_temp  = NaN(n_types,1);
            if age <j_r % if working, use pretax income level
                y_mat_temp  = y_opt_policy_mat(:,age,Policy_vec_index); % reset the slide of this matrix current loop updates to 1
            else % if retired, use pretax pension level
                y_mat_temp = pension_lvl_policy_mat(:,Policy_vec_index); 
            end
            income_dist = NaN(n_types,3);
            income_dist = [y_mat_temp(:) weight_temp(:)];
            income_dist = sortrows(income_dist,1);
            income_dist(:,3) = cumsum(income_dist(:,2)); 
            y_bin_mat(1:n_types,age,Policy_vec_index) = 1; 
            for index_temp = 1:number_bins-1
                [~,cutoff]     = min(abs(income_dist(:,3)-index_temp/number_bins)) ;
                flag_temp      = (y_mat_temp>=income_dist(cutoff,1));
                y_bin_mat(flag_temp==1,age,Policy_vec_index) = 1+index_temp; % already at type level
            end 
            % - checks
            check_disty = NaN(1,number_bins);
            for bin_index = 1:number_bins
                check_disty(bin_index) =  sum(weight_temp.*(y_bin_mat(:,age,Policy_vec_index) ==bin_index)) ;
            end
            disp('Ydist binning check:');
            disp(num2str([unique(y_bin_mat(:,age,Policy_vec_index))'; round(check_disty,4)]))
            disp('  ');
        end % End assign bins using first policy vec distributions
        % =========================================== END ASSIGN AGE-SPECIFIC BINS
        % =========================================== BEGIN NEWBORN AND ADULT AGE_SPECIFIC WELFARE CHANGES (several measures): 
        % ==> Measure #1: Newborns given theta_k
        if age == 1 % independent of age
            % --> Step 1 of 2: Construct relevant expected values
            EV_temp = NaN(n_theta,n_thetak,n_ccsub_types,n_bins_ccsub_fc);
            weight_temp = NaN(n_theta,n_thetak,n_ccsub_types,n_bins_ccsub_fc);
            for type_index = 1:n_types  
                weight_temp(type_mat(type_index,1),type_mat(type_index,2),type_mat(type_index,3),type_mat(type_index,4)) = J*Omega_dist_policy_mat(type_index,1,Policy_vec_index);
                EV_temp(type_mat(type_index,1),type_mat(type_index,2),type_mat(type_index,3),type_mat(type_index,4))     = Vkid_policy_mat(theta_opt_policy_mat(type_index,1,Policy_vec_index),Policy_vec_index);
            end         
            for thetak_index = 1:n_thetak
                weight_given_thetak = []; 
                weight_given_thetak = squeeze(weight_temp(:,thetak_index,:,:))./sum(weight_temp(:,thetak_index,:,:),'all');
                EV_newborns(thetak_index,Policy_vec_index)              = sum(weight_given_thetak.*squeeze(EV_temp(:,thetak_index,:,:)),'all');
                weight_thetak_policy_mat(thetak_index,Policy_vec_index) = sum(weight_temp(:,thetak_index,:,:),'all');
            end
            % --> Step 2 of 2: Construct welfare change for given type thetak
            W_change_newborns(:,Policy_vec_index) = 100*(exp((EV_newborns(:,Policy_vec_index) - EV_newborns(:,Baseline_index))/(denomW(1)))-1)  ;
            % Average across types of welfare change given type (theta_k)
            W_change_newborns_ave(Policy_vec_index) = sum(weight_thetak_policy_mat(:,Policy_vec_index).*W_change_newborns(:,Policy_vec_index),'all');
            % Share gaining, losing, and indifferent for newborns:
            Share_gain_newborns(Policy_vec_index) = sum(weight_thetak_policy_mat(:,Policy_vec_index).*(W_change_newborns(:,Policy_vec_index)>0),'all'); 
            Share_lose_newborns(Policy_vec_index) = sum(weight_thetak_policy_mat(:,Policy_vec_index).*(W_change_newborns(:,Policy_vec_index)<0),'all'); 
            Share_indiff_newborns(Policy_vec_index) = sum(weight_thetak_policy_mat(:,Policy_vec_index).*(W_change_newborns(:,Policy_vec_index)==0),'all'); 
        end % end age conditional
        % ==> Measure #2: behind the veil of ignorance
        % --> Step 1 of 2: Construct relevant expected values
        EV_temp = []; EV_temp_bsln = [];
        EV_temp = sum(J*Omega_dist_policy_mat(:,age,Policy_vec_index).*V_opt_realized_policy_mat(:,age,Policy_vec_index));
        EV_temp_bsln = sum(J*Omega_dist_policy_mat(:,age,Baseline_index).*V_opt_realized_policy_mat(:,age,Baseline_index));
        % --> Step 2 of 2: Construct welfare change 
        W_change_bvi_ave(age,Policy_vec_index) = 100*(exp((EV_temp - EV_temp_bsln)/(denomW(age)))-1)  ; 
        % ==> Measure #3: Adults given theta_a and age j
        EV_temp =  NaN(n_theta,n_thetak,n_ccsub_types,n_bins_ccsub_fc); 
        ccdf_app_temp = NaN(n_theta,n_thetak,n_bins_ccsub_fc); 
        for type_index = 1:n_types  
            EV_temp(type_mat(type_index,1),type_mat(type_index,2),type_mat(type_index,3),type_mat(type_index,4)) = V_opt_realized_policy_mat(type_index,age,Policy_vec_index);
            ccdf_app_temp(type_mat(type_index,1),type_mat(type_index,2),type_mat(type_index,4)) = ccdf_app_opt_policy_mat(type_index,age,Policy_vec_index);
        end  
        EV_adults_aux = NaN(n_theta,n_thetak,n_bins_ccsub_fc); 
        for theta_index = 1:n_theta
            weight_temp = NaN(n_theta,n_bins_ccsub_fc);
            for thetak_index = 1:n_thetak
                for cc_fc_index = 1:n_bins_ccsub_fc  
                    weight_temp(thetak_index,cc_fc_index) = thetak_dist_policy_mat(theta_index,thetak_index,Policy_vec_index)*chi_c_eps_dist(cc_fc_index);
                    % -- Step 1 of 2: construct relevant EV 
                    if ccdf_app_temp(theta_index,thetak_index,cc_fc_index) == 1 % incorporate application choices into distribution over ccdf application/receipt/no app distribution
                        EV_adults_aux(theta_index,thetak_index,cc_fc_index)      = weight_temp(thetak_index,cc_fc_index)*EV_temp(theta_index,thetak_index,1,cc_fc_index);
                    else 
                        EV_adults_aux(theta_index,thetak_index,cc_fc_index)   = weight_temp(thetak_index,cc_fc_index)*(Policy_pars_mat_inputs(Policy_vec_index,2)*EV_temp(theta_index,thetak_index,2,cc_fc_index)+ (1-Policy_pars_mat_inputs(Policy_vec_index,2))*EV_temp(theta_index,thetak_index,3,cc_fc_index));
                    end
                end
            end
            % --> Step 2 of 2: Construct welfare change type_mat(type_index,1),type_mat(type_index,2),type_mat(type_index,4)
            EV_adults(theta_index,age,Policy_vec_index) = sum(EV_adults_aux(theta_index,:,:),'all');
            W_change_adults(theta_index,age,Policy_vec_index) = 100*(exp((EV_adults(theta_index,age,Policy_vec_index) - EV_adults(theta_index,age,Baseline_index))/denomW(age))-1)  ;
        end 
        % Average across types of welfare change given type (theta_a)
        W_change_adults_ave(age,Policy_vec_index) = sum(skill_dist_policy_mat(:,Policy_vec_index).*W_change_adults(:,age,Policy_vec_index),'all');        
        % Share gaining, losing, and indifferent for adults:
        Share_gain_adults(age,Policy_vec_index) = sum(skill_dist_policy_mat(:,Policy_vec_index).*(W_change_adults(:,age,Policy_vec_index)>0),'all'); 
        Share_lose_adults(age,Policy_vec_index) = sum(skill_dist_policy_mat(:,Policy_vec_index).*(W_change_adults(:,age,Policy_vec_index)<0),'all'); 
        Share_indiff_adults(age,Policy_vec_index) = sum(skill_dist_policy_mat(:,Policy_vec_index).*(W_change_adults(:,age,Policy_vec_index)==0),'all'); 
        % =========================================== END NEWBORN AND ADULT AGE_SPECIFIC WELFARE CHANGES

        % ====================================== BEGIN AGE-SPECIFIC QUANTITITES AND CHANGES       
        % Quantities by age
        y_ave_policy_mat(age,Policy_vec_index) = sum(J*Omega_dist_policy_mat(:,age,Policy_vec_index).*y_opt_policy_mat(:,age,Policy_vec_index));
        yd_ave_policy_mat(age,Policy_vec_index) = sum(J*Omega_dist_policy_mat(:,age,Policy_vec_index).*yd_opt_policy_mat(:,age,Policy_vec_index));
        h_ave_policy_mat(age,Policy_vec_index) = sum(J*Omega_dist_policy_mat(:,age,Policy_vec_index).*h_opt_policy_mat(:,age,Policy_vec_index));
        c_ave_policy_mat(age,Policy_vec_index) = sum(J*Omega_dist_policy_mat(:,age,Policy_vec_index).*c_opt_policy_mat(:,age,Policy_vec_index));
        q_ave_policy_mat(age,Policy_vec_index) = sum(J*Omega_dist_policy_mat(:,age,Policy_vec_index).*q_opt_policy_mat(:,age,Policy_vec_index));
        n_ave_policy_mat(age,Policy_vec_index) = sum(J*Omega_dist_policy_mat(:,age,Policy_vec_index).*n_opt_policy_mat(:,age,Policy_vec_index));
        skill_ave_policy_mat(age,Policy_vec_index) = sum(J*Omega_dist_policy_mat(:,age,Policy_vec_index).*theta_profile_grid(:,age));
        if age == 1
            theta_ave_policy_mat(age,Policy_vec_index) = sum(J*Omega_dist_policy_mat(:,age,Policy_vec_index).*theta_grid(theta_opt_policy_mat(:,age,Policy_vec_index))');
        else
            theta_ave_policy_mat(age,Policy_vec_index) = 0;
        end        
        % Percent change in age-specific averages
        skill_ave_change_age(age,Policy_vec_index) = 100*(skill_ave_policy_mat(age,Policy_vec_index)/skill_ave_policy_mat(age,Baseline_index) - 1);
        q_ave_change_age(age,Policy_vec_index) = 100*(q_ave_policy_mat(age,Policy_vec_index)/q_ave_policy_mat(age,Baseline_index) - 1);
        n_ave_change_age(age,Policy_vec_index) = 100*(n_ave_policy_mat(age,Policy_vec_index)/n_ave_policy_mat(age,Baseline_index) - 1);
        h_ave_change_age(age,Policy_vec_index) = 100*(h_ave_policy_mat(age,Policy_vec_index)/h_ave_policy_mat(age,Baseline_index) - 1);
        c_ave_change_age(age,Policy_vec_index) = 100*(c_ave_policy_mat(age,Policy_vec_index)/c_ave_policy_mat(age,Baseline_index) - 1);
        if age == 1
            theta_ave_change_age(age,Policy_vec_index) = 100*sum(J*Omega_dist_policy_mat(:,age,Policy_vec_index).*(theta_ave_policy_mat(age,Policy_vec_index)./theta_ave_policy_mat(age,1) - 1));
        else
            theta_ave_change_age(age,Policy_vec_index) = 0;
        end        
   
        % Conditional quantities by age, by CCDF application/receipt outcome
        flag_rccdf(:,age,Policy_vec_index)        = (ccdf_app_opt_policy_mat(:,age,Policy_vec_index) ==2).*(type_mat(:,3) == 3);
        flag_appnorccdf(:,age,Policy_vec_index)   = (ccdf_app_opt_policy_mat(:,age,Policy_vec_index) ==2).*(type_mat(:,3) == 2);
        flag_noappnorccdf(:,age,Policy_vec_index) = (ccdf_app_opt_policy_mat(:,age,Policy_vec_index) == 1| type_mat(:,3) == 1);

        % SD of pretax income
        std_y_policy_mat(age,Policy_vec_index)    = std(y_opt_policy_mat(:,age,Policy_vec_index),Omega_dist_policy_mat(:,age,Policy_vec_index));

        % SD of after-tax (disposible) income
        std_yd_policy_mat(age,Policy_vec_index)   = std(yd_opt_policy_mat(:,age,Policy_vec_index),Omega_dist_policy_mat(:,age,Policy_vec_index));

        % Averages by bin, using new equilibrium distribution of households. Order of bins: theta,thetak,fc,y
        for binning_variable_index = 1:5
            if binning_variable_index == 1
                binning_variable_bin_mat = thetaa_bin_mat(:,age,Baseline_index);
            elseif binning_variable_index == 2
                binning_variable_bin_mat = thetak_bin_mat(:,age,Baseline_index);
            elseif binning_variable_index == 3
                binning_variable_bin_mat = fc_bin_mat(:,age,Baseline_index);
            elseif binning_variable_index == 4
                binning_variable_bin_mat = y_bin_mat(:,age,Baseline_index); 
            else
                binning_variable_bin_mat = thetaka_bin_mat(:,age,Baseline_index); 
            end
            for bin_index = 1:number_bins
                w_temp = [];
                w_temp = Omega_dist_policy_mat(:,age,Policy_vec_index).*(binning_variable_bin_mat==bin_index); 
                w_temp = w_temp./sum(w_temp(:));
                % Distribution over thetaa, thetak, and income bins using baseline index binning
                dist_bin(binning_variable_index,bin_index,age,Policy_vec_index) = sum(Omega_dist_policy_mat(:,age,Policy_vec_index).*(binning_variable_bin_mat==bin_index)); 
                % Bin-specific averages using loop's binning variable: 
                share_nilf_bin(binning_variable_index,bin_index,age,Policy_vec_index) = sum(w_temp.*(h_opt_policy_mat(:,age,Policy_vec_index)==0)); 
                h_ave_bin(binning_variable_index,bin_index,age,Policy_vec_index) = sum(w_temp.*h_opt_policy_mat(:,age,Policy_vec_index)); 
                n_ave_bin(binning_variable_index,bin_index,age,Policy_vec_index) = sum(w_temp.*n_opt_policy_mat(:,age,Policy_vec_index)); 
                q_ave_bin(binning_variable_index,bin_index,age,Policy_vec_index) = sum(w_temp.*q_opt_policy_mat(:,age,Policy_vec_index)); 
                c_ave_bin(binning_variable_index,bin_index,age,Policy_vec_index) = sum(w_temp.*c_opt_policy_mat(:,age,Policy_vec_index));  
                
                % Mass of recipients and amount spent within bin using weights that do not condition on being in bin
                mass_ctc_bin(binning_variable_index,bin_index,age,Policy_vec_index)   = sum(Omega_dist_policy_mat(:,age,Policy_vec_index).*(binning_variable_bin_mat==bin_index).*(CTC_received_opt_policy_mat(:,age,Policy_vec_index)>0)); 
                mass_eitc_bin(binning_variable_index,bin_index,age,Policy_vec_index)  = sum(Omega_dist_policy_mat(:,age,Policy_vec_index).*(binning_variable_bin_mat==bin_index).*(EITC_received_opt_policy_mat(:,age,Policy_vec_index)>0)); 
                mass_tanf_bin(binning_variable_index,bin_index,age,Policy_vec_index)  = sum(Omega_dist_policy_mat(:,age,Policy_vec_index).*(binning_variable_bin_mat==bin_index).*(TANF_received_opt_policy_mat(:,age,Policy_vec_index)>0)); 

                amt_ctc_bin(binning_variable_index,bin_index,age,Policy_vec_index)    = sum(Omega_dist_policy_mat(:,age,Policy_vec_index).*(binning_variable_bin_mat==bin_index).*CTC_received_opt_policy_mat(:,age,Policy_vec_index)); 
                amt_eitc_bin(binning_variable_index,bin_index,age,Policy_vec_index)   = sum(Omega_dist_policy_mat(:,age,Policy_vec_index).*(binning_variable_bin_mat==bin_index).*EITC_received_opt_policy_mat(:,age,Policy_vec_index)); 
                amt_tanf_bin(binning_variable_index,bin_index,age,Policy_vec_index)   = sum(Omega_dist_policy_mat(:,age,Policy_vec_index).*(binning_variable_bin_mat==bin_index).*TANF_received_opt_policy_mat(:,age,Policy_vec_index)); 
                
                if age == 1
                    invtemp = []; 
                    invtemp = (((theta_grid(theta_opt_policy_mat(:,1,Policy_vec_index))/lambda_I).^(1-1/chi) - (1-upsilon)*thetak_grid(type_mat(:,2)).^(1-1/chi))/upsilon).^(chi/(chi-1))'; 
                    
                    % Within-bin averages of investment, expenditures on n, and thetaka*
                    invlevel_ave_bin(binning_variable_index,bin_index,age,Policy_vec_index) = sum(w_temp.*invtemp); 
                    ccexp_ave_bin(binning_variable_index,bin_index,age,Policy_vec_index)    = sum(w_temp.*GE_objects_policy_mat(2,Policy_vec_index).*n_opt_policy_mat(:,age,Policy_vec_index)); 
                    thetaka_ave_bin(binning_variable_index,bin_index,age,Policy_vec_index)  = sum(w_temp.*theta_grid(theta_opt_policy_mat(:,age,Policy_vec_index))'); 
                    
                    % CCDF childcare subsidy rate given income level and 85 percent of population median income value
                    tau_arg        = (y_opt_policy_mat(:,1,Policy_vec_index)./CCDF_opt_policy_mat(1,5,Policy_vec_index));
                    tau_aux        = CCDF_opt_policy_mat(1,2,Policy_vec_index) + tau_arg.*CCDF_opt_policy_mat(1,3,Policy_vec_index) + (tau_arg.^(2)).*CCDF_opt_policy_mat(1,4,Policy_vec_index); % second order term is 0 so this is linear
                    tau_CCDF_temp  = (h_opt_policy_mat(:,1,Policy_vec_index)>0).*(y_opt_policy_mat(:,1,Policy_vec_index)<CCDF_opt_policy_mat(1,1,Policy_vec_index)).*max(tau_aux,0);
                    
                    % Dollar value of CCDF subsidy for types who receive it, given price p and choice of n
                    ntau_CCDF_temp = flag_rccdf(:,age,Policy_vec_index).*GE_objects_policy_mat(2,Policy_vec_index).*n_opt_policy_mat(:,1,Policy_vec_index).*tau_CCDF_temp;
                    
                    % Mass recipients fc subsidy and/or CCDF transfer and amount spent within bin using weights that do not condition on being in bin
                    mass_ccdf_bin(binning_variable_index,bin_index,age,Policy_vec_index)      = sum(Omega_dist_policy_mat(:,age,Policy_vec_index).*(binning_variable_bin_mat==bin_index).*(ntau_CCDF_temp>0)); % only ccdf subsidy spending
                    mass_ccdf_wfc_bin(binning_variable_index,bin_index,age,Policy_vec_index)  = sum(Omega_dist_policy_mat(:,age,Policy_vec_index).*(binning_variable_bin_mat==bin_index).*(gov_cc_expense_opt_policy_mat(:,age,Policy_vec_index)>0));  % includes gov't fixed cost subsidy so don't flag with receipt type
                    
                    amt_ccdf_bin(binning_variable_index,bin_index,age,Policy_vec_index)       = sum(Omega_dist_policy_mat(:,age,Policy_vec_index).*(binning_variable_bin_mat==bin_index).*ntau_CCDF_temp); 
                    amt_ccdf_wfc_bin(binning_variable_index,bin_index,age,Policy_vec_index)   = sum(Omega_dist_policy_mat(:,age,Policy_vec_index).*(binning_variable_bin_mat==bin_index).*gov_cc_expense_opt_policy_mat(:,age,Policy_vec_index));  % includes gov't fixed cost subsidy so don't flag with receipt type
                end  % end age = 1 condition
            end % end bin index loop
        end % end binning variable index loop 

      % Averages by bin, using BASELINE equilibrium distribution of households. Order of bins: theta,thetak,fc,y
        for binning_variable_index = 1:5
            if binning_variable_index == 1
                binning_variable_bin_mat = thetaa_bin_mat(:,age,Baseline_index);
            elseif binning_variable_index == 2
                binning_variable_bin_mat = thetak_bin_mat(:,age,Baseline_index);
            elseif binning_variable_index == 3
                binning_variable_bin_mat = fc_bin_mat(:,age,Baseline_index);
            elseif binning_variable_index == 4
                binning_variable_bin_mat = y_bin_mat(:,age,Baseline_index);
            else
                binning_variable_bin_mat = thetaka_bin_mat(:,age,Baseline_index); 
            end
            for bin_index = 1:number_bins
                w_temp = [];
                w_temp = Omega_dist_policy_mat(:,age,Baseline_index).*(binning_variable_bin_mat==bin_index); 
                w_temp = w_temp./sum(w_temp(:));
                % Distribution over thetaa, thetak, and income bins using baseline index binning
                BSLN_dist_bin(binning_variable_index,bin_index,age,Policy_vec_index) = sum(Omega_dist_policy_mat(:,age,Baseline_index).*(binning_variable_bin_mat==bin_index)); 
                % Bin-specific averages using loop's binning variable: 
                BSLN_share_nilf_bin(binning_variable_index,bin_index,age,Policy_vec_index) = sum(w_temp.*(h_opt_policy_mat(:,age,Policy_vec_index)==0)); 
                BSLN_h_ave_bin(binning_variable_index,bin_index,age,Policy_vec_index) = sum(w_temp.*h_opt_policy_mat(:,age,Policy_vec_index)); 
                BSLN_n_ave_bin(binning_variable_index,bin_index,age,Policy_vec_index) = sum(w_temp.*n_opt_policy_mat(:,age,Policy_vec_index)); 
                BSLN_q_ave_bin(binning_variable_index,bin_index,age,Policy_vec_index) = sum(w_temp.*q_opt_policy_mat(:,age,Policy_vec_index)); 
                BSLN_c_ave_bin(binning_variable_index,bin_index,age,Policy_vec_index) = sum(w_temp.*c_opt_policy_mat(:,age,Policy_vec_index));  
                
                % Mass of recipients and amount spent within bin using weights that do not condition on being in bin
                BSLN_mass_ctc_bin(binning_variable_index,bin_index,age,Policy_vec_index)   = sum(Omega_dist_policy_mat(:,age,Baseline_index).*(binning_variable_bin_mat==bin_index).*(CTC_received_opt_policy_mat(:,age,Policy_vec_index)>0)); 
                BSLN_mass_eitc_bin(binning_variable_index,bin_index,age,Policy_vec_index)  = sum(Omega_dist_policy_mat(:,age,Baseline_index).*(binning_variable_bin_mat==bin_index).*(EITC_received_opt_policy_mat(:,age,Policy_vec_index)>0)); 
                BSLN_mass_tanf_bin(binning_variable_index,bin_index,age,Policy_vec_index)  = sum(Omega_dist_policy_mat(:,age,Baseline_index).*(binning_variable_bin_mat==bin_index).*(TANF_received_opt_policy_mat(:,age,Policy_vec_index)>0)); 

                BSLN_amt_ctc_bin(binning_variable_index,bin_index,age,Policy_vec_index)    = sum(Omega_dist_policy_mat(:,age,Baseline_index).*(binning_variable_bin_mat==bin_index).*CTC_received_opt_policy_mat(:,age,Policy_vec_index)); 
                BSLN_amt_eitc_bin(binning_variable_index,bin_index,age,Policy_vec_index)   = sum(Omega_dist_policy_mat(:,age,Baseline_index).*(binning_variable_bin_mat==bin_index).*EITC_received_opt_policy_mat(:,age,Policy_vec_index)); 
                BSLN_amt_tanf_bin(binning_variable_index,bin_index,age,Policy_vec_index)   = sum(Omega_dist_policy_mat(:,age,Baseline_index).*(binning_variable_bin_mat==bin_index).*TANF_received_opt_policy_mat(:,age,Policy_vec_index)); 
                
                if age == 1
                    invtemp = []; 
                    invtemp = (((theta_grid(theta_opt_policy_mat(:,1,Policy_vec_index))/lambda_I).^(1-1/chi) - (1-upsilon)*thetak_grid(type_mat(:,2)).^(1-1/chi))/upsilon).^(chi/(chi-1))'; 
                    
                    % Within-bin averages of investment, expenditures on n, and thetaka*
                    BSLN_invlevel_ave_bin(binning_variable_index,bin_index,age,Policy_vec_index) = sum(w_temp.*invtemp); 
                    BSLN_ccexp_ave_bin(binning_variable_index,bin_index,age,Policy_vec_index)    = sum(w_temp.*GE_objects_policy_mat(2,Policy_vec_index).*n_opt_policy_mat(:,age,Policy_vec_index)); 
                    BSLN_thetaka_ave_bin(binning_variable_index,bin_index,age,Policy_vec_index)  = sum(w_temp.*theta_grid(theta_opt_policy_mat(:,age,Policy_vec_index))'); 
                    
                    % CCDF childcare subsidy rate given income level and 85 percent of population median income value
                    BSLN_tau_arg        = (y_opt_policy_mat(:,1,Policy_vec_index)./CCDF_opt_policy_mat(1,5,Policy_vec_index));
                    BSLN_tau_aux        = CCDF_opt_policy_mat(1,2,Policy_vec_index) + tau_arg.*CCDF_opt_policy_mat(1,3,Policy_vec_index) + (tau_arg.^(2)).*CCDF_opt_policy_mat(1,4,Policy_vec_index); % second order term is 0 so this is linear
                    BSLN_tau_CCDF_temp  = (h_opt_policy_mat(:,1,Policy_vec_index)>0).*(y_opt_policy_mat(:,1,Policy_vec_index)<CCDF_opt_policy_mat(1,1,Policy_vec_index)).*max(tau_aux,0);
                    
                    % Dollar value of CCDF subsidy for types who receive it, given price p and choice of n
                    BSLN_ntau_CCDF_temp = flag_rccdf(:,age,Policy_vec_index).*GE_objects_policy_mat(2,Policy_vec_index).*n_opt_policy_mat(:,1,Policy_vec_index).*tau_CCDF_temp;
                    
                    % Mass recipients fc subsidy and/or CCDF transfer and amount spent within bin using weights that do not condition on being in bin
                    BSLN_mass_ccdf_bin(binning_variable_index,bin_index,age,Policy_vec_index)      = sum(Omega_dist_policy_mat(:,age,Baseline_index).*(binning_variable_bin_mat==bin_index).*(ntau_CCDF_temp>0)); % only ccdf subsidy spending
                    BSLN_mass_ccdf_wfc_bin(binning_variable_index,bin_index,age,Policy_vec_index)  = sum(Omega_dist_policy_mat(:,age,Baseline_index).*(binning_variable_bin_mat==bin_index).*(gov_cc_expense_opt_policy_mat(:,age,Policy_vec_index)>0));  % includes gov't fixed cost subsidy so don't flag with receipt type
                    
                    BSLN_amt_ccdf_bin(binning_variable_index,bin_index,age,Policy_vec_index)       = sum(Omega_dist_policy_mat(:,age,Baseline_index).*(binning_variable_bin_mat==bin_index).*ntau_CCDF_temp); 
                    BSLN_amt_ccdf_wfc_bin(binning_variable_index,bin_index,age,Policy_vec_index)   = sum(Omega_dist_policy_mat(:,age,Baseline_index).*(binning_variable_bin_mat==bin_index).*gov_cc_expense_opt_policy_mat(:,age,Policy_vec_index));  % includes gov't fixed cost subsidy so don't flag with receipt type
                end  % end age = 1 condition
            end % end bin index loop
        end % end binning variable index loop     
    end % end age loop
    % ====================================== END AGE-SPECIFIC QUANTITITES

    % ====================================== BEGIN AGE-1 QUANTITIES AND AVE BIN VALUES
    % Reset age: 
    age = 1;
    % Just age 1; 2 bins combinations
    for binning_variable_index = 1:5               
        for bin_index1 = 1:number_bins
            for bin_index2 = 1:number_bins
                w_temp = [];
                if binning_variable_index == 1 % binning_variable_index = 1: Bin1 = Thetaa , Bin2 = thetak
                    w_temp = Omega_dist_policy_mat(:,age,Policy_vec_index).*(thetaa_bin_mat(:,age,Baseline_index)==bin_index1).*(thetak_bin_mat(:,age,Baseline_index)==bin_index2); 
                elseif binning_variable_index == 2 % binning_variable_index = 2:  Bin1 = y , Bin2 = thetak
                    w_temp = Omega_dist_policy_mat(:,age,Policy_vec_index).*(y_bin_mat(:,age,Baseline_index)==bin_index1).*(thetak_bin_mat(:,age,Baseline_index)==bin_index2); 
                elseif binning_variable_index == 3  % binning_variable_index = 3: Bin1 = thetaa , Bin2 = fc
                    w_temp = Omega_dist_policy_mat(:,age,Policy_vec_index).*(thetaa_bin_mat(:,age,Baseline_index)==bin_index1).*(fc_bin_mat(:,age,Baseline_index)==bin_index2); 
                elseif binning_variable_index == 4  % binning_variable_index = 4: Bin1 = y , Bin2 = fc
                    w_temp = Omega_dist_policy_mat(:,age,Policy_vec_index).*(y_bin_mat(:,age,Baseline_index)==bin_index1).*(fc_bin_mat(:,age,Baseline_index)==bin_index2); 
                else % binning_variable_index = 5: Bin1 = thetaka* , Bin2 = thetak
                    w_temp = Omega_dist_policy_mat(:,age,Policy_vec_index).*(thetaka_bin_mat(:,age,Baseline_index)==bin_index1).*(thetak_bin_mat(:,age,Baseline_index)==bin_index2); 
                end
                flag_bin = (w_temp>0);
                mass_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index) = sum(w_temp(:)); % Population mass       
                % Distribution over thetaa, thetak, and income bins using baseline index binning
                dist_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index) = sum(w_temp(:));
                % Normalization of weights
                w_temp = w_temp./sum(w_temp(:)); 
                % Bin-specific averages using loop's binning variable: 
                share_nilf_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index) = sum(w_temp.*(h_opt_policy_mat(:,age,Policy_vec_index)==0)); 
                h_ave_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index) = sum(w_temp.*h_opt_policy_mat(:,age,Policy_vec_index)); 
                n_ave_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index) = sum(w_temp.*n_opt_policy_mat(:,age,Policy_vec_index)); 
                q_ave_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index) = sum(w_temp.*q_opt_policy_mat(:,age,Policy_vec_index)); 
                c_ave_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index) = sum(w_temp.*c_opt_policy_mat(:,age,Policy_vec_index)); 
                
                % Mass of recipients and amount spent within bin using weights that do not condition on being in bin
                mass_ctc_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index)   = sum(Omega_dist_policy_mat(:,age,Policy_vec_index).*flag_bin.*(CTC_received_opt_policy_mat(:,age,Policy_vec_index)>0)); % overall mass, not within-bin average
                mass_eitc_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index)  = sum(Omega_dist_policy_mat(:,age,Policy_vec_index).*flag_bin.*(EITC_received_opt_policy_mat(:,age,Policy_vec_index)>0)); 
                mass_tanf_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index)  = sum(Omega_dist_policy_mat(:,age,Policy_vec_index).*flag_bin.*(TANF_received_opt_policy_mat(:,age,Policy_vec_index)>0)); 
                
                amt_ctc_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index)    = sum(Omega_dist_policy_mat(:,age,Policy_vec_index).*flag_bin.*CTC_received_opt_policy_mat(:,age,Policy_vec_index)); 
                amt_eitc_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index)   = sum(Omega_dist_policy_mat(:,age,Policy_vec_index).*flag_bin.*EITC_received_opt_policy_mat(:,age,Policy_vec_index)); 
                amt_tanf_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index)   = sum(Omega_dist_policy_mat(:,age,Policy_vec_index).*flag_bin.*TANF_received_opt_policy_mat(:,age,Policy_vec_index)); 
                
                % Within-bin averages of investment, expenditures on n, and thetaka*
                invtemp = []; 
                invtemp = (((theta_grid(theta_opt_policy_mat(:,1,Policy_vec_index))/lambda_I).^(1-1/chi) - (1-upsilon)*thetak_grid(type_mat(:,2)).^(1-1/chi))/upsilon).^(chi/(chi-1))'; 
                invlevel_ave_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index) = sum(w_temp.*invtemp); 
                ccexp_ave_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index)    = sum(w_temp.*GE_objects_policy_mat(2,Policy_vec_index).*n_opt_policy_mat(:,age,Policy_vec_index)); 
                thetaka_ave_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index)  = sum(w_temp.*theta_grid(theta_opt_policy_mat(:,age,Policy_vec_index))'); 
                
                % CCDF childcare subsidy rate given income level and 85 percent of population median income value
                tau_arg = (y_opt_policy_mat(:,1,Policy_vec_index)./CCDF_opt_policy_mat(1,5,Policy_vec_index));
                tau_aux = CCDF_opt_policy_mat(1,2,Policy_vec_index) + tau_arg.*CCDF_opt_policy_mat(1,3,Policy_vec_index) + (tau_arg.^(2)).*CCDF_opt_policy_mat(1,4,Policy_vec_index);
                tau_CCDF_temp     = (h_opt_policy_mat(:,1,Policy_vec_index)>0).*(y_opt_policy_mat(:,1,Policy_vec_index)<CCDF_opt_policy_mat(1,1,Policy_vec_index)).*max(tau_aux,0);  
               
                % Define eligibility using counterfactual income if worked part-time like Guzman (2019)
                cntrfctl_inc = theta_grid(type_mat(:,1))'.*h_grid(3);
                tau_arg = (cntrfctl_inc./CCDF_opt_policy_mat(1,5,Policy_vec_index));
                tau_aux = CCDF_opt_policy_mat(1,2,Policy_vec_index) + tau_arg.*CCDF_opt_policy_mat(1,3,Policy_vec_index) + (tau_arg.^(2)).*CCDF_opt_policy_mat(1,4,Policy_vec_index);
                tau_CCDF_temp_el  = (cntrfctl_inc<CCDF_opt_policy_mat(1,1,Policy_vec_index)).*max(tau_aux,0);  
                
                % Dollar value of CCDF subsidy for types who receive it, given price p and choice of n
                ntau_CCDF_temp = flag_rccdf(:,age,Policy_vec_index).*GE_objects_policy_mat(2,Policy_vec_index).*n_opt_policy_mat(:,1,Policy_vec_index).*tau_CCDF_temp;  
                
                % Mass within bin using weights that do not condition on being in bin
                mass_ccdf_wfc_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index) = sum(Omega_dist_policy_mat(:,age,Policy_vec_index).*flag_bin.*(gov_cc_expense_opt_policy_mat(:,age,Policy_vec_index)>0)); % these also get zero tau_CCDF; once you draw thetak it may not be worth it to restrict labor supply/qualify
                mass_ccdf_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index)     = sum(Omega_dist_policy_mat(:,age,Policy_vec_index).*flag_bin.*(ntau_CCDF_temp>0)); 
                
                amt_ccdf_wfc_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index)  = sum(Omega_dist_policy_mat(:,age,Policy_vec_index).*flag_bin.*gov_cc_expense_opt_policy_mat(:,age,Policy_vec_index)); 
                amt_ccdf_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index)      = sum(Omega_dist_policy_mat(:,age,Policy_vec_index).*flag_bin.*ntau_CCDF_temp); 
                
                % Conditional share within bin combo who apply for CCDF                                             
                share_apply_ccdf_wfc_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index) = sum(w_temp.*(ccdf_app_opt_policy_mat(:,1,Policy_vec_index)==2)); 

                % Conditional share within bin combo who are eligible for tau_cc or fixed cost subsidy and who receive ccdf (2 def). Uptake rate is only for CCDF subsidy not FC subsidy.                                            
                share_received_ccdf_wfc_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index) = sum(w_temp.*(gov_cc_expense_opt_policy_mat(:,1,Policy_vec_index)>0)); 
                share_eligible_ccdf_wfc_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index) = sum(w_temp.*(CCDF_policy_mat(7)>0)); % anyone is eligible for the FC subsidy if fc subsidy is nonzero
                
                % Conditional share within bin combo who are eligible for CCDF subsidy is those who meet work and income requirements, not those who apply
                share_eligible_ccdf_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index)     = sum(w_temp.*(tau_CCDF_temp_el(:)>0)); % using part-time income
                share_eligible_y_ccdf_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index)    = sum(w_temp.*(tau_CCDF_temp(:)>0));  % using realized income

                % Conditional share within bin combo who are recipients that apply, receive CCDF after lottery, and get a positive dollar amount for CCDF childcare subsidy
                share_received_ccdf_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index)     = sum(w_temp.*(ntau_CCDF_temp>0)); 
                uptake_rateccdf_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index)         = share_received_ccdf_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index)/share_eligible_ccdf_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index); % NaN if no eligible
                uptake_rate_y_ccdf_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index)      = share_received_ccdf_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index)/share_eligible_y_ccdf_2bin(binning_variable_index,bin_index1,bin_index2,Policy_vec_index); % NaN if no eligible
            end % end bin_index2
        end % end bin_index1                   
    end % end binning_variable_index 

    % --> Begin CCDF vs j=1 POP STATS

        % CCDF childcare subsidy rate given income level and 85 percent of population median income value
        tau_arg = (y_opt_policy_mat(:,1,Policy_vec_index)./CCDF_opt_policy_mat(1,5,Policy_vec_index));
        tau_aux = CCDF_opt_policy_mat(1,2,Policy_vec_index) + tau_arg.*CCDF_opt_policy_mat(1,3,Policy_vec_index) + (tau_arg.^(2)).*CCDF_opt_policy_mat(1,4,Policy_vec_index);
        tau_CCDF_temp     = (h_opt_policy_mat(:,1,Policy_vec_index)>0).*(y_opt_policy_mat(:,1,Policy_vec_index)<CCDF_opt_policy_mat(1,1,Policy_vec_index)).*max(tau_aux,0);  

        % Define eligibility using counterfactual income if worked part-time like Guzman (2019)
        cntrfctl_inc = theta_grid(type_mat(:,1))'.*h_grid(3);
        tau_arg = (cntrfctl_inc./CCDF_opt_policy_mat(1,5,Policy_vec_index));
        tau_aux = CCDF_opt_policy_mat(1,2,Policy_vec_index) + tau_arg.*CCDF_opt_policy_mat(1,3,Policy_vec_index) + (tau_arg.^(2)).*CCDF_opt_policy_mat(1,4,Policy_vec_index);
        tau_CCDF_temp_el  = (cntrfctl_inc<CCDF_opt_policy_mat(1,1,Policy_vec_index)).*max(tau_aux,0);  
         
        % Conditional share within bin combo who are eligible for CCDF subsidy is those who meet work and income requirements, not those who apply
        share_eligible_ccdf_policy_mat(Policy_vec_index)   = sum(J*Omega_dist_policy_mat(:,1,Policy_vec_index).*(tau_CCDF_temp_el(:)>0)); % using part-time income
        share_eligible_y_ccdf_policy_mat(Policy_vec_index) = sum(J*Omega_dist_policy_mat(:,1,Policy_vec_index).*(tau_CCDF_temp(:)>0)); % using part-time income

        % Conditional share within bin combo who are recipients that apply, receive CCDF after lottery, and get a positive dollar amount for CCDF childcare subsidy
        share_applied_ccdf_policy_mat(Policy_vec_index) = sum(J*Omega_dist_policy_mat(:,1,Policy_vec_index).*(ccdf_app_opt_policy_mat(:,1,Policy_vec_index)==2));   
        share_received_ccdf_policy_mat(Policy_vec_index) = sum(J*Omega_dist_policy_mat(:,1,Policy_vec_index).*(tau_CCDF_temp(:)>0).*(gov_cc_expense_opt_policy_mat(:,1,Policy_vec_index)>0));   

        % CCDF subsidy rate at realized income level - if positive, consumer is CCDF-eligible
        tau_arg = []; tau_arg = (y_opt_policy_mat(:,1,Policy_vec_index)./CCDF_opt_policy_mat(1,5,Policy_vec_index));
        tau_aux = []; tau_aux = CCDF_opt_policy_mat(1,2,Policy_vec_index) + tau_arg.*CCDF_opt_policy_mat(1,3,Policy_vec_index) + (tau_arg.^(2)).*CCDF_opt_policy_mat(1,4,Policy_vec_index); 
        tau_CCDF_temp  = (h_opt_policy_mat(:,1,Policy_vec_index)>0).*(y_opt_policy_mat(:,1,Policy_vec_index)<CCDF_opt_policy_mat(1,1,Policy_vec_index)).*max(tau_aux,0); 
        % Conditional means given CCDF receipt and share of parents receiving
        weight_temp = []; 
        weight_temp = Omega_dist_policy_mat(:,1,Policy_vec_index).*(tau_CCDF_temp(:)>0).*flag_rccdf(:,1,Policy_vec_index).*(gov_cc_expense_opt_policy_mat(:,1,Policy_vec_index)>0);  
        weight_temp = weight_temp./sum(weight_temp(:));
        ave_tau_ccdf_recipient(Policy_vec_index)        = sum(weight_temp(:).*tau_CCDF_temp(:)); 
        ave_amt_ngov_ccdf_recipient(Policy_vec_index)   = sum(weight_temp(:).*GE_objects_policy_mat(2,Policy_vec_index).*n_opt_policy_mat(:,1,Policy_vec_index).*tau_CCDF_temp(:)); 
        ave_amt_nfam_ccdf_recipient(Policy_vec_index)   = sum(weight_temp(:).*GE_objects_policy_mat(2,Policy_vec_index).*n_opt_policy_mat(:,1,Policy_vec_index).*(1-tau_CCDF_temp(:))); 
        ave_n_ccdf_recipient(Policy_vec_index)          = sum(weight_temp(:).*n_opt_policy_mat(:,1,Policy_vec_index)); 
        ave_y_ccdf_recipient(Policy_vec_index)          = sum(weight_temp(:).*y_opt_policy_mat(:,1,Policy_vec_index)); 
        ave_yd_ccdf_recipient(Policy_vec_index)         = sum(weight_temp(:).*yd_opt_policy_mat(:,1,Policy_vec_index));    
        share_par_ccdf_recipient(Policy_vec_index)      = sum(J*Omega_dist_policy_mat(:,1,Policy_vec_index).*flag_rccdf(:,1,Policy_vec_index).*(tau_CCDF_temp(:)>0),'all'); 
        % Conditional means given TANF receipt and share of parents receiving    
        weight_temp = (TANF_received_opt_policy_mat(:,1,1)>0).*Omega_dist_policy_mat(:,1,1);
        weight_temp = weight_temp./sum(weight_temp(:));
        ave_amt_tanf_recipient(Policy_vec_index)   = sum(weight_temp.*TANF_received_opt_policy_mat(:,1,Policy_vec_index),'all');       
        share_par_tanf_recipient(Policy_vec_index) = sum(J*Omega_dist_policy_mat(:,1,Policy_vec_index).*(TANF_received_opt_policy_mat(:,1,Policy_vec_index)>0),'all'); 
        % Conditional mean given parent of child under 5
        ave_amt_nfam_new_adults(Policy_vec_index)       = sum(J*Omega_dist_policy_mat(:,1,Policy_vec_index).*GE_objects_policy_mat(2,Policy_vec_index).*n_opt_policy_mat(:,1,Policy_vec_index));     
        ave_n_new_adults(Policy_vec_index)              = sum(J*Omega_dist_policy_mat(:,1,Policy_vec_index).*n_opt_policy_mat(:,1,Policy_vec_index)); 
        ave_y_new_adults(Policy_vec_index)              = sum(J*Omega_dist_policy_mat(:,1,Policy_vec_index).*y_opt_policy_mat(:,1,Policy_vec_index)); 
        ave_yd_new_adults(Policy_vec_index)             = sum(J*Omega_dist_policy_mat(:,1,Policy_vec_index).*yd_opt_policy_mat(:,1,Policy_vec_index)); 
        % Conditional means given CTC receipt and mass receiving
        weight_temp = [];
        weight_temp = (CTC_received_opt_policy_mat(:,:,1)>0).*Omega_dist_policy_mat(:,:,1);
        weight_temp = weight_temp./sum(weight_temp(:));
        ave_amt_ctc_recipient(Policy_vec_index) = sum(weight_temp.*CTC_received_opt_policy_mat(:,:,Policy_vec_index),'all'); 
        mass_ctc_recipient(Policy_vec_index)    = sum(Omega_dist_policy_mat(:,:,Policy_vec_index).*(CTC_received_opt_policy_mat(:,:,Policy_vec_index)>0),'all'); 
        % Conditional means given EITC receipt and mass receiving overall and mass receiving with kids
        for age = 1:J
            flag_ages(:,age) = (age<=4)*ones(n_types,1);
        end
        weight_temp = [];
        weight_temp = (EITC_received_opt_policy_mat(:,:,1)>0).*Omega_dist_policy_mat(:,:,1);
        weight_temp = weight_temp./sum(weight_temp(:));
        ave_amt_eitc_recipient(Policy_vec_index) = sum(weight_temp.*EITC_received_opt_policy_mat(:,:,Policy_vec_index),'all');       
        ave_amt_eitc_wkids_recipient(Policy_vec_index) = sum(flag_ages.*weight_temp.*(EITC_received_opt_policy_mat(:,:,Policy_vec_index)),'all'); 
        mass_eitc_wkids_recipient(Policy_vec_index) = sum(flag_ages.*Omega_dist_policy_mat(:,:,Policy_vec_index).*(EITC_received_opt_policy_mat(:,:,Policy_vec_index)>0),'all'); 
        mass_eitc_recipient(Policy_vec_index)       = sum(Omega_dist_policy_mat(:,:,Policy_vec_index).*(EITC_received_opt_policy_mat(:,:,Policy_vec_index)>0),'all'); 
    % --> End CCDF vs j=1 POP STATS
    % ====================================== END AGE-1 QUANTITIES AND AVE BIN VALUES

    % ====================================== BEGIN POPULATION-LEVEL STATS
    % Tax rate at average income in baseline equilibrium average income for working-age adults
    weight_temp = [];  
    weight_temp = Omega_dist_policy_mat(:,1:j_r-1,Baseline_index); weight_temp = weight_temp./sum(weight_temp(:));
    y_temp = [];
    y_temp = sum(weight_temp.*y_opt_policy_mat(:,1:j_r-1,Baseline_index),'all');
    tax_rate_ave_inc(Policy_vec_index) = 100*(1-(GE_objects_policy_mat(5,Policy_vec_index)*y_temp^(1-tau_y))/y_temp);
   
    % Government spending target - residual in **percentage points** with respect to target equilibrium for calibrated experiments
    if ismember(Policy_vec_index,[4 5])   
        target_index = 2; % 2018 CTC expansion
        res_tempG(Policy_vec_index) = target_pct_Y_G_policy_mat(Policy_vec_index) - target_pct_Y_G_policy_mat(target_index); 
    elseif ismember(Policy_vec_index,[6 7 8])    
        target_index = 3; % eliminating CCDF rationing
        res_tempG(Policy_vec_index) = target_pct_Y_G_policy_mat(Policy_vec_index) - target_pct_Y_G_policy_mat(target_index); 
    else
        res_tempG(Policy_vec_index) = 0;
    end

    % Population SD, Mean, CV of pretax income working age population
    ytemp = []; ytemp = y_opt_policy_mat(:,1:j_r-1,Policy_vec_index); 
    wtemp = []; wtemp = Omega_dist_policy_mat(:,1:j_r-1,Policy_vec_index); wtemp = wtemp./sum(wtemp(:));
    var_logy_workingpop_policy_mat(Policy_vec_index)  = var(log(ytemp(:)),wtemp(:));
    std_y_workingpop_policy_mat(Policy_vec_index)  = std(ytemp(:),wtemp(:));
    mean_y_workingpop_policy_mat(Policy_vec_index) = sum(ytemp(:).*wtemp(:));
    cv_y_workingpop_policy_mat(Policy_vec_index)   = std_y_workingpop_policy_mat(Policy_vec_index)/mean_y_workingpop_policy_mat(Policy_vec_index);

    % Population SD, Mean, CV of after-tax (disposible) income working age population
    ytemp = []; ytemp = yd_opt_policy_mat(:,1:j_r-1,Policy_vec_index); 
    wtemp = []; wtemp = Omega_dist_policy_mat(:,1:j_r-1,Policy_vec_index); wtemp = wtemp./sum(wtemp(:));
    var_logyd_workingpop_policy_mat(Policy_vec_index)  = var(log(ytemp(:)),wtemp(:));
    std_yd_workingpop_policy_mat(Policy_vec_index)  = std(ytemp(:),wtemp(:));
    mean_yd_workingpop_policy_mat(Policy_vec_index) = sum(ytemp(:).*wtemp(:));
    cv_yd_workingpop_policy_mat(Policy_vec_index)   = std_yd_workingpop_policy_mat(Policy_vec_index)/mean_yd_workingpop_policy_mat(Policy_vec_index) ;

    % CDF of all adults skill 
    for type_index = 1:n_types
        for age = 1:J
            skill_lifecycle_level(type_index,age) = theta_profile_grid(type_index,age);
            weight_lifecycle_temp(type_index,age) = Omega_dist_policy_mat(type_index,age,Policy_vec_index);
        end
    end
    skill_dist_all_mat(:,1) = skill_lifecycle_level(:);
    skill_dist_all_mat(:,2) = weight_lifecycle_temp(:)./sum(weight_lifecycle_temp(:));
    skill_dist_all_mat = sortrows(skill_dist_all_mat,1);
    skill_dist_all_mat(:,3) = cumsum(skill_dist_all_mat(:,2));

    % Percentiles of all adults log skill distribution
    cutoff_grid = linspace(0.01,0.999,100);
    for loop_index = 1:100    
        [~,arg] = min(abs(skill_dist_all_mat(:,3)-cutoff_grid(loop_index)));
        pctile_logskill_all_policy_mat(loop_index,Policy_vec_index) = log(skill_dist_all_mat(arg,1));
    end
    pctile_logskill_dist_allpolicy_mat(1,Policy_vec_index) = pctile_logskill_all_policy_mat(10,Policy_vec_index);
    pctile_logskill_dist_allpolicy_mat(2,Policy_vec_index) = pctile_logskill_all_policy_mat(50,Policy_vec_index);
    pctile_logskill_dist_allpolicy_mat(3,Policy_vec_index) = pctile_logskill_all_policy_mat(90,Policy_vec_index);

    temp= []; temp = pctile_logskill_all_policy_mat(88:92,Policy_vec_index);
    ave_p90_smoothed = sum(temp/size(temp,1),1);
    temp= []; temp = pctile_logskill_all_policy_mat(48:52,Policy_vec_index);
    ave_p50_smoothed = sum(temp/size(temp,1),1);
    temp= []; temp = pctile_logskill_all_policy_mat(8:12,Policy_vec_index);
    ave_p10_smoothed = sum(temp/size(temp,1),1);
    smoothed_pctile_logskill_alldist_policy_mat(1,Policy_vec_index) = ave_p10_smoothed;
    smoothed_pctile_logskill_alldist_policy_mat(2,Policy_vec_index) = ave_p50_smoothed;
    smoothed_pctile_logskill_alldist_policy_mat(3,Policy_vec_index) = ave_p90_smoothed;

    % Mean and inequality measures of all adult skill distribution
    mean_allskill_policy_mat(Policy_vec_index)       = sum(skill_lifecycle_level(:).*weight_lifecycle_temp(:));
    std_allskill_policy_mat(Policy_vec_index)        = std(skill_lifecycle_level(:),weight_lifecycle_temp(:));
    cv_allskill_policy_mat(Policy_vec_index)         = std_allskill_policy_mat(Policy_vec_index)/mean_allskill_policy_mat(Policy_vec_index);
    [gini_allskill_policy_mat(Policy_vec_index),mu]  = gini(theta_grid(:),skill_dist_policy_mat(:,Policy_vec_index)./sum(skill_dist_policy_mat(:,Policy_vec_index)));
    var_logskill_allpolicy_mat(Policy_vec_index)     = var(log(skill_lifecycle_level(:)),weight_lifecycle_temp(:));

    % CDF of new adult skill 
    cdf_skill_dist_policy_mat(:,Policy_vec_index) = cumsum(skill_dist_policy_mat(:,Policy_vec_index));
    cdf_skill_dist_policy_mat(:,Policy_vec_index) = cdf_skill_dist_policy_mat(:,Policy_vec_index)./cdf_skill_dist_policy_mat(end,Policy_vec_index); % Normalizing

    % Percentiles of new adult log skill distribution
    cutoff_grid = linspace(0.01,1,100);
    for loop_index = 1:100    
        [~,arg] = min(abs(cdf_skill_dist_policy_mat(:,Policy_vec_index)-cutoff_grid(loop_index)));
        pctile_logskill_policy_mat(loop_index,Policy_vec_index) = log(theta_grid(arg));
    end
    pctile_logskill_dist_policy_mat(1,Policy_vec_index) = pctile_logskill_policy_mat(10,Policy_vec_index);
    pctile_logskill_dist_policy_mat(2,Policy_vec_index) = pctile_logskill_policy_mat(50,Policy_vec_index);
    pctile_logskill_dist_policy_mat(3,Policy_vec_index) = pctile_logskill_policy_mat(90,Policy_vec_index);

    temp= []; temp = pctile_logskill_policy_mat(88:92,Policy_vec_index);
    ave_p90_smoothed = sum(temp/size(temp,1),1);
    temp= []; temp = pctile_logskill_policy_mat(48:52,Policy_vec_index);
    ave_p50_smoothed = sum(temp/size(temp,1),1);
    temp= []; temp = pctile_logskill_policy_mat(8:12,Policy_vec_index);
    ave_p10_smoothed = sum(temp/size(temp,1),1);
    smoothed_pctile_logskill_dist_policy_mat(1,Policy_vec_index) = ave_p10_smoothed;
    smoothed_pctile_logskill_dist_policy_mat(2,Policy_vec_index) = ave_p50_smoothed;
    smoothed_pctile_logskill_dist_policy_mat(3,Policy_vec_index) = ave_p90_smoothed;
    
    % Percentiles of adult levels skill distribution
    cutoff_grid = linspace(0.01,1,100);
    for loop_index = 1:100    
        [~,arg] = min(abs(cdf_skill_dist_policy_mat(:,Policy_vec_index)-cutoff_grid(loop_index)));
        pctile_skill_policy_mat(loop_index,Policy_vec_index) = theta_grid(arg);
    end
    temp= []; temp = pctile_skill_policy_mat(88:92,Policy_vec_index);
    ave_p90_smoothed = sum(temp/size(temp,1),1);
    temp= []; temp = pctile_skill_policy_mat(48:52,Policy_vec_index);
    ave_p50_smoothed = sum(temp/size(temp,1),1);
    temp= []; temp = pctile_skill_policy_mat(8:12,Policy_vec_index);
    ave_p10_smoothed = sum(temp/size(temp,1),1);
    smoothed_pctile_skill_dist_policy_mat(1,Policy_vec_index) = ave_p10_smoothed;
    smoothed_pctile_skill_dist_policy_mat(2,Policy_vec_index) = ave_p50_smoothed;
    smoothed_pctile_skill_dist_policy_mat(3,Policy_vec_index) = ave_p90_smoothed;

    % Decile averages - "decile dispersion"
    lower_bound = [];
    upper_bound = [];
    for decile_index = 1:10
        lower_bound(decile_index,Policy_vec_index) = 10*(decile_index-1)+1;
        upper_bound(decile_index,Policy_vec_index) = 10*decile_index;    
        pctile_logskill_deciles(decile_index,Policy_vec_index) = sum(pctile_logskill_all_policy_mat(10*(decile_index-1)+1:10*decile_index,Policy_vec_index))/(10*decile_index - 10*(decile_index-1)+1);
    end
    deciles_logskill(1,Policy_vec_index) = pctile_logskill_deciles(1,Policy_vec_index);
    deciles_logskill(2,Policy_vec_index) = pctile_logskill_deciles(5,Policy_vec_index);
    deciles_logskill(3,Policy_vec_index) = pctile_logskill_deciles(10,Policy_vec_index);

    % Mean and inequality measures of new adult skill distribution
    mean_skill_policy_mat(Policy_vec_index)       = sum(skill_dist_policy_mat(:,Policy_vec_index).*theta_grid(:));
    std_skill_policy_mat(Policy_vec_index)        = std(theta_grid(:),skill_dist_policy_mat(:,Policy_vec_index));
    cv_skill_policy_mat(Policy_vec_index)         = std_skill_policy_mat(Policy_vec_index)/mean_skill_policy_mat(Policy_vec_index);
    [gini_skill_policy_mat(Policy_vec_index),mu]  = gini(theta_grid(:),skill_dist_policy_mat(:,Policy_vec_index)./sum(skill_dist_policy_mat(:,Policy_vec_index)));
    var_logskill_policy_mat(Policy_vec_index)     = var(log(theta_grid(:)),skill_dist_policy_mat(:,Policy_vec_index));
    
    % Pretax logged income inequality stats - to match GRID moments 25-34 
    income_dist = []; y_temp = []; Omega_dist_temp= [];
    y_temp = y_opt_policy_mat(:,2:3,Policy_vec_index); 
    logy_temp = log(y_temp(:));  
    h_temp = h_opt_policy_mat(:,2:3,Policy_vec_index); 
    wage_temp = wage_dist_levels(:,2:3);
    flag_working_and_in_wagerange = (h_temp(:)>0).*(wage_temp(:)>thetaminthreshold_GRID).*(wage_temp(:)<thetamaxthreshold_GRID); 
    Omega_dist_temp_aux = Omega_dist_policy_mat(:,2:3,Policy_vec_index); Omega_dist_temp_aux = Omega_dist_temp_aux./sum(Omega_dist_temp_aux(:)); 
    Omega_dist_temp  = Omega_dist_temp_aux(:);
    income_dist      = [logy_temp((flag_working_and_in_wagerange==1)) Omega_dist_temp((flag_working_and_in_wagerange==1))./sum(Omega_dist_temp((flag_working_and_in_wagerange==1)))];
    income_dist      = sortrows(income_dist,1);
    income_dist(:,3) = cumsum(income_dist(:,2));  
    [~,p50yarg]      = min(abs(income_dist(:,end)-0.5));
    [~,p10yarg]      = min(abs(income_dist(:,end)-0.1));  
    par_p50p10_policy_mat(Policy_vec_index) = income_dist(p50yarg,1) - income_dist(p10yarg,1);

    cutoff_grid = linspace(0.01,1,100);
    for loop_index = 1:100    
        [~,arg] = min(abs(income_dist(:,end)-cutoff_grid(loop_index)));
        pctile_logypar_policy_mat(loop_index,Policy_vec_index) = income_dist(arg,1);
    end    
    temp = pctile_logypar_policy_mat(48:52,Policy_vec_index);
    ave_ypar_p48_p52 = sum(temp/size(temp,1),1);
    temp = pctile_logypar_policy_mat(8:12,Policy_vec_index);
    ave_ypar_p8_p12 = sum(temp/size(temp,1),1);
    par_ave_p10_policy_mat(Policy_vec_index) = ave_ypar_p8_p12;
    par_ave_p50_policy_mat(Policy_vec_index) = ave_ypar_p48_p52;
    % ====================================== END POPULATION-LEVEL STATS

    % ====================================== BEGIN OUTPUT TABLE OBJECTS
    % Table of quantity changes needs to have:
    % Panel A: Pctage point change in (that is, spending overall by components by % GDP, tax rate)
    % Panel B: Pct change in (that is, Q,N,Average skill,H,Output,Consumption)
    % Panel C: Welfare changes in levels 
    % Panel D: Welfare changes: share gains, loses, indifferent 
    % Spending and taxation - percentage point changes
    G_spending_change(Policy_vec_index)   = target_pct_Y_G_policy_mat(Policy_vec_index)- target_pct_Y_G_policy_mat(Baseline_index);
    ave_tax_rate_change(Policy_vec_index) = tax_rate_ave_inc(Policy_vec_index) - tax_rate_ave_inc(Baseline_index);
    % Aggregate quantities  - percent changes
    q_ave_change(Policy_vec_index)     = 100*(sum(q_ave_policy_mat(1,Policy_vec_index))/sum(q_ave_policy_mat(1,Baseline_index)) - 1);
    n_ave_change(Policy_vec_index)     = 100*(sum(n_ave_policy_mat(1,Policy_vec_index))/sum(n_ave_policy_mat(1,Baseline_index)) - 1);
    skill_ave_change(Policy_vec_index) = 100*(sum(skill_ave_policy_mat(1,Policy_vec_index))/sum(skill_ave_policy_mat(1,Baseline_index)) - 1);
    h_ave_change(Policy_vec_index)     = 100*(sum(h_ave_policy_mat(1:j_r-1,Policy_vec_index))/sum(h_ave_policy_mat(1:j_r-1,Baseline_index)) - 1); % This is 25-55 in the calibration target, but here we include more ages
    GDP_change(Policy_vec_index)       = 100*(GE_objects_policy_mat(1,Policy_vec_index)/GE_objects_policy_mat(1,Baseline_index) - 1);
    c_ave_change(Policy_vec_index)     = 100*(sum(c_ave_policy_mat(:,Policy_vec_index))/sum(c_ave_policy_mat(:,Baseline_index)) - 1);
    % Skill outcomes of newborns - percent change
    thetaka_ave_thetak_bin_change(bin_index,Policy_vec_index) = 100*(ave_theta_given_thetak_bin_policy_mat(bin_index,Policy_vec_index)./ave_theta_given_thetak_bin_policy_mat(bin_index,Baseline_index) - 1);  
    % Mean and median skill of adults - percent change
    meanskill_change(Policy_vec_index)     =  100*(mean_skill_policy_mat(Policy_vec_index)/mean_skill_policy_mat(Baseline_index)  -1);
    p50skill_change(Policy_vec_index)      =  100*(pctile_skill_policy_mat(2,Policy_vec_index)/pctile_skill_policy_mat(2,Baseline_index)  -1);
    ave_p50_skill_change(Policy_vec_index) = smoothed_pctile_skill_dist_policy_mat(2,Policy_vec_index) - smoothed_pctile_skill_dist_policy_mat(2,Baseline_index);
    % Inequality in income - changes in levels
    std_y_change(:,Policy_vec_index)          = std_y_policy_mat(:,Policy_vec_index) - std_y_policy_mat(:,Baseline_index);
    std_yd_change(:,Policy_vec_index)         = std_yd_policy_mat(:,Policy_vec_index) - std_yd_policy_mat(:,Baseline_index);
    std_ypop_change(Policy_vec_index)         = std_y_workingpop_policy_mat(Policy_vec_index) - std_y_workingpop_policy_mat(Baseline_index) ;
    std_ydpop_change(Policy_vec_index)        = std_yd_workingpop_policy_mat(Policy_vec_index) - std_yd_workingpop_policy_mat(Baseline_index);
    cv_y_workingpop_change(Policy_vec_index)  = cv_y_workingpop_policy_mat(Policy_vec_index) - cv_y_workingpop_policy_mat(Baseline_index);
    cv_yd_workingpop_change(Policy_vec_index) = cv_yd_workingpop_policy_mat(Policy_vec_index) - cv_yd_workingpop_policy_mat(Baseline_index);
    par_p50p10_change(Policy_vec_index)       = par_p50p10_policy_mat(Policy_vec_index) - par_p50p10_policy_mat(Baseline_index);
    % Overall inequality in skill - changes in levels
    cv_skill_change(Policy_vec_index)     =  cv_skill_policy_mat(Policy_vec_index) - cv_skill_policy_mat(Baseline_index);
    std_skill_change(Policy_vec_index)    =  std_skill_policy_mat(Policy_vec_index) - std_skill_policy_mat(Baseline_index);
    gini_skill_change(Policy_vec_index)   =  gini_skill_policy_mat(Policy_vec_index) - gini_skill_policy_mat(Baseline_index);
    var_logskill_change(Policy_vec_index) =  var_logskill_policy_mat(Policy_vec_index) - var_logskill_policy_mat(Baseline_index);
    % Inequality in log skill - changes in levels for percentile differents
    ave_p50_p10_logskill_change(Policy_vec_index) = smoothed_pctile_logskill_dist_policy_mat(2,Policy_vec_index) - smoothed_pctile_logskill_dist_policy_mat(1,Policy_vec_index) - (smoothed_pctile_logskill_dist_policy_mat(2,Baseline_index) - smoothed_pctile_logskill_dist_policy_mat(1,Baseline_index));
    ave_p90_p50_logskill_change(Policy_vec_index) = smoothed_pctile_logskill_dist_policy_mat(3,Policy_vec_index) - smoothed_pctile_logskill_dist_policy_mat(2,Policy_vec_index) - (smoothed_pctile_logskill_dist_policy_mat(3,Baseline_index) - smoothed_pctile_logskill_dist_policy_mat(2,Baseline_index));
    ave_p90_p10_logskill_change(Policy_vec_index) = smoothed_pctile_logskill_dist_policy_mat(3,Policy_vec_index) - smoothed_pctile_logskill_dist_policy_mat(1,Policy_vec_index) - (smoothed_pctile_logskill_dist_policy_mat(3,Baseline_index) - smoothed_pctile_logskill_dist_policy_mat(1,Baseline_index));
    % Inequality in log skill - changes in decile differences
    ave_decile5_decile1_logskill_change(Policy_vec_index)  = deciles_logskill(2,Policy_vec_index) - deciles_logskill(1,Policy_vec_index) - (deciles_logskill(2,Baseline_index) - deciles_logskill(1,Baseline_index));
    ave_decile10_decile5_logskill_change(Policy_vec_index) = deciles_logskill(3,Policy_vec_index) - deciles_logskill(2,Policy_vec_index) - (deciles_logskill(3,Baseline_index) - deciles_logskill(2,Baseline_index));
    ave_decile10_decile1_logskill_change(Policy_vec_index) = deciles_logskill(3,Policy_vec_index) - deciles_logskill(1,Policy_vec_index) - (deciles_logskill(3,Baseline_index) - deciles_logskill(1,Baseline_index));
    
    % Correlations - income mobility measures
    rho_thetay_change(Policy_vec_index) = GE_quantities_policy_mat(4,Policy_vec_index) - GE_quantities_policy_mat(4,Baseline_index);
    rho_rry_change(Policy_vec_index)    = GE_quantities_policy_mat(5,Policy_vec_index) - GE_quantities_policy_mat(5,Baseline_index);
    % ====================================== END OUTPUT TABLE OBJECTS
end % end Policy_vec_index loop

% Output table: 
for Policy_vec_index = 1:size(Policy_toggle_mat,1)
    if Policy_vec_index~=Baseline_index  % changes
        Array_Policy_counterfactuals_C4(1,Policy_vec_index) = G_spending_change(Policy_vec_index); % Government spending
        Array_Policy_counterfactuals_C4(2,Policy_vec_index) = ave_tax_rate_change(Policy_vec_index); % ave tax rate at average income of working-age adult in baseline economy
        Array_Policy_counterfactuals_C4(3,Policy_vec_index) = q_ave_change(Policy_vec_index); % Q ave parents age 1
        Array_Policy_counterfactuals_C4(4,Policy_vec_index) = n_ave_change(Policy_vec_index); % N ave parents age 1
        Array_Policy_counterfactuals_C4(5,Policy_vec_index) = skill_ave_change(Policy_vec_index); % Adult skill ave age = 1
        Array_Policy_counterfactuals_C4(6,Policy_vec_index) = h_ave_change(Policy_vec_index); % H ave working-age adults
        Array_Policy_counterfactuals_C4(7,Policy_vec_index) = GDP_change(Policy_vec_index); % GDP 
        Array_Policy_counterfactuals_C4(8,Policy_vec_index) = c_ave_change(Policy_vec_index); % C ave
        Array_Policy_counterfactuals_C4(9,Policy_vec_index) = par_p50p10_change(Policy_vec_index); % Change in inequality among parents
        Array_Policy_counterfactuals_C4(10,Policy_vec_index) = ave_decile10_decile1_logskill_change(Policy_vec_index);
        Array_Policy_counterfactuals_C4(11,Policy_vec_index) = ave_decile10_decile5_logskill_change(Policy_vec_index); 
        Array_Policy_counterfactuals_C4(12,Policy_vec_index) = ave_decile5_decile1_logskill_change(Policy_vec_index);
        Array_Policy_counterfactuals_C4(13,Policy_vec_index) = meanskill_change(Policy_vec_index);  % new adults skill mean
        Array_Policy_counterfactuals_C4(14,Policy_vec_index) = ave_p50_skill_change(Policy_vec_index);  % new adults skill median
        Array_Policy_counterfactuals_C4(15,Policy_vec_index) = var_logskill_change(Policy_vec_index); % Change in var log skill new adults
        Array_Policy_counterfactuals_C4(16,Policy_vec_index) = gini_skill_change(Policy_vec_index); % Change in gini skill new adults
        Array_Policy_counterfactuals_C4(17,Policy_vec_index) = cv_skill_change(Policy_vec_index);  % change in cv skill new adults
        Array_Policy_counterfactuals_C4(18,Policy_vec_index) = cv_y_workingpop_change(Policy_vec_index);  % change in coefficient of variation income population
        Array_Policy_counterfactuals_C4(19,Policy_vec_index) = rho_thetay_change(Policy_vec_index); % Change in rho_thetay
        Array_Policy_counterfactuals_C4(20,Policy_vec_index) = rho_rry_change(Policy_vec_index); % Change in rho_rry 
        Array_Policy_counterfactuals_C4(21,Policy_vec_index) = W_change_bvi_ave(1,Policy_vec_index); % Newborns
        Array_Policy_counterfactuals_C4(22,Policy_vec_index) = W_change_adults_ave(1,Policy_vec_index); % New adults given (theta_a,j=1)
        Array_Policy_counterfactuals_C4(23,Policy_vec_index) = sum(W_change_adults_ave(:,Policy_vec_index)/J); % Ave all adults given (theta_a,j)
        Array_Policy_counterfactuals_C4(24,Policy_vec_index) = sum(Share_gain_newborns(Policy_vec_index));
        Array_Policy_counterfactuals_C4(25,Policy_vec_index) = sum(Share_lose_newborns(Policy_vec_index));
        Array_Policy_counterfactuals_C4(26,Policy_vec_index) = sum(Share_indiff_newborns(Policy_vec_index));        
        Array_Policy_counterfactuals_C4(27,Policy_vec_index) = Share_gain_adults(1,Policy_vec_index);
        Array_Policy_counterfactuals_C4(28,Policy_vec_index) = Share_lose_adults(1,Policy_vec_index);
        Array_Policy_counterfactuals_C4(29,Policy_vec_index) = Share_indiff_adults(1,Policy_vec_index);
        Array_Policy_counterfactuals_C4(30,Policy_vec_index) = sum(Share_gain_adults(:,Policy_vec_index)/J);
        Array_Policy_counterfactuals_C4(31,Policy_vec_index) = sum(Share_lose_adults(:,Policy_vec_index)/J);
        Array_Policy_counterfactuals_C4(32,Policy_vec_index) = sum(Share_indiff_adults(:,Policy_vec_index)/J);        
        Array_Policy_counterfactuals_C4(33,Policy_vec_index) = max(abs(res_vec_policy_mat(:,Policy_vec_index)));
    else % Baseline equilibrium levels
        Array_Policy_counterfactuals_C4(1,Policy_vec_index) = target_pct_Y_G_policy_mat(Baseline_index);
        Array_Policy_counterfactuals_C4(2,Policy_vec_index) = tax_rate_ave_inc(Baseline_index);
        Array_Policy_counterfactuals_C4(3,Policy_vec_index) = sum(q_ave_policy_mat(1,Baseline_index));
        Array_Policy_counterfactuals_C4(4,Policy_vec_index) = sum(n_ave_policy_mat(1,Baseline_index));
        Array_Policy_counterfactuals_C4(5,Policy_vec_index) = sum(skill_ave_policy_mat(1,Baseline_index));
        Array_Policy_counterfactuals_C4(6,Policy_vec_index) = sum((1/(j_r-1))*h_ave_policy_mat(1:j_r-1,Baseline_index)); 
        Array_Policy_counterfactuals_C4(7,Policy_vec_index) = GE_objects_policy_mat(1,Baseline_index);
        Array_Policy_counterfactuals_C4(8,Policy_vec_index) = sum((1/J)*c_ave_policy_mat(:,Baseline_index));
        Array_Policy_counterfactuals_C4(9,Policy_vec_index) = par_p50p10_policy_mat(Baseline_index);
        Array_Policy_counterfactuals_C4(10,Policy_vec_index) = deciles_logskill(3,Policy_vec_index) - deciles_logskill(1,Policy_vec_index);
        Array_Policy_counterfactuals_C4(11,Policy_vec_index) = deciles_logskill(3,Policy_vec_index) - deciles_logskill(2,Policy_vec_index) ;
        Array_Policy_counterfactuals_C4(12,Policy_vec_index) = deciles_logskill(2,Policy_vec_index) - deciles_logskill(1,Policy_vec_index);
        Array_Policy_counterfactuals_C4(13,Policy_vec_index) = mean_skill_policy_mat(Policy_vec_index);  % new adults skill mean
        Array_Policy_counterfactuals_C4(14,Policy_vec_index) = smoothed_pctile_skill_dist_policy_mat(2,Policy_vec_index); 
        Array_Policy_counterfactuals_C4(15,Policy_vec_index) = var_logskill_policy_mat(Baseline_index);
        Array_Policy_counterfactuals_C4(16,Policy_vec_index) = gini_skill_policy_mat(Baseline_index);
        Array_Policy_counterfactuals_C4(17,Policy_vec_index) = cv_skill_policy_mat(Baseline_index);
        Array_Policy_counterfactuals_C4(18,Policy_vec_index) = cv_y_workingpop_policy_mat(Baseline_index);
        Array_Policy_counterfactuals_C4(19,Policy_vec_index) = GE_quantities_policy_mat(4,Baseline_index);
        Array_Policy_counterfactuals_C4(20,Policy_vec_index) = GE_quantities_policy_mat(5,Baseline_index);
        Array_Policy_counterfactuals_C4(21:end-1,Policy_vec_index) = zeros(12,1);
        Array_Policy_counterfactuals_C4(end,Policy_vec_index) = max(abs(res_vec_policy_mat(:,Baseline_index)));
    end
end
toc(TSTART) 

% For plotting gradual expansions
target_pct_Y_G_policy_mat_C4 = target_pct_Y_G_policy_mat;
share_eligible_ccdf_2bin_C4  = share_eligible_ccdf_2bin;
share_apply_ccdf_wfc_2bin_C4 = share_apply_ccdf_wfc_2bin;
share_received_ccdf_2bin_C4 = share_received_ccdf_2bin;

% Saving output for figures/tabulations
filename_temp = []; filename_temp = online_appendix_path + "Processed_output_online_appendix\Array_Policy_counterfactuals_C4.mat"; save(filename_temp,'Array_Policy_counterfactuals_C4',...
    'target_pct_Y_G_policy_mat_C4','share_eligible_ccdf_2bin_C4','share_apply_ccdf_wfc_2bin_C4','share_received_ccdf_2bin_C4');
 