Paper title: Family Policies and Child Skill Accumulation
Authors: Emily G. Moschini (corresponding author) and Monica Tran-Xuan
Editor: Mariacristina De Nardi
Manuscript number: RED-D-23-00184.R2 

Directions for replication  
* Copy MoschiniTranXuan_FamilyPolicies_Replication.zip to your computer and extract its contents. Memory requirement when fully implemented: 1.6 GB of space.  
* Open Replication_outline.xlsx. For each Figure, Table, etc. this file maps to a file in the replication package; open indicated file and follow directions.

Raw data   
* 2 public datasets need to be downloaded to run full set of Stata codes. 
* If this is necessary to download them to replicate the desired output, directions will be in the file indicated by Replication_outline.xlsx. 

MATLAB   
* Software: MATLAB 2022b with Parallel computing toolbox, using 64 workers 
* Processor: Desktop PC Intel Xeon Gold 6130 CPU @ 2.10GHz (2 processors) 
* Operating system: 64-bit Windows 10 Enterprise OS build 19043.1348   
* Runtime: main text exercises take 45 mins, with more details in tab "Guide to Model_codes folder" of Replication_outline.xlsx. Runtimes may vary across computers    

Stata   
* Software: Stata 18 SE
* Processor: Intel(R) Core(TM) Ultra 7 165U @ 1.70 GHz
* Operating system: 64-bit Windows 11 Pro build 22631.4602   
* Runtime: about 2 minutes for longest-running set of Stata file    